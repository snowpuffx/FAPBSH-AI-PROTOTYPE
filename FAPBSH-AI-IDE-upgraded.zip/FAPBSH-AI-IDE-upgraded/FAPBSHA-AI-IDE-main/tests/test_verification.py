from pathlib import Path

from fapbsh.analysis import analyze_source
from fapbsh.explain import recommend
from fapbsh.verification import CheckResult, Verifier, compute_verdict
from fapbsh.verification import checks
from fapbsh.verification.checks import CHECK_NAMES

SAMPLES = Path(__file__).resolve().parent / "samples"


def _results(*statuses):
    return [CheckResult(name, status) for name, status in zip(CHECK_NAMES, statuses)]


def test_verdict_rules():
    P, F, U = "Passed", "Failed", "Unavailable"
    assert compute_verdict(_results(P, P, P, P, P))[0] == "Resolved"
    assert compute_verdict(_results(P, P, U, P, U))[0] == "Resolved"
    assert compute_verdict(_results(F, U, U, U, U))[0] == "Not resolved"
    assert compute_verdict(_results(P, F, P, P, P))[0] == "Not resolved"
    assert compute_verdict(_results(P, P, P, F, P))[0] == "Not resolved"
    assert compute_verdict(_results(P, P, F, P, P))[0] == "Partially resolved"
    assert compute_verdict(_results(P, P, P, P, F))[0] == "Partially resolved"
    assert compute_verdict(_results(P, P, U, U, P))[0] == "Inconclusive"


def _first(sample):
    code = (SAMPLES / sample).read_text()
    finding = analyze_source(code, str(SAMPLES / sample)).findings[0]
    return code, finding


def test_generated_fix_is_resolved_with_five_checks():
    code, finding = _first("cwe89_vulnerable.py")
    rec = recommend(finding, code)
    seen = []
    report = Verifier(None).run(code, rec.corrected, finding,
                                progress=lambda i, r: seen.append((i, r.status)))
    assert [c.name for c in report.checks] == CHECK_NAMES
    assert ("Running" in [s for _, s in seen])
    statuses = {c.name: c.status for c in report.checks}
    assert statuses["Syntax validation"] == "Passed"
    assert statuses["Data-flow re-check"] == "Passed"
    assert statuses["Security test cases"] == "Passed"
    assert report.verdict in ("Resolved", "Inconclusive")
    if statuses["Bandit and Semgrep CE scan"] == "Passed":
        assert report.verdict == "Resolved"


def test_unchanged_code_is_not_resolved():
    code, finding = _first("cwe78_vulnerable.py")
    report = Verifier(None).run(code, code, finding)
    statuses = {c.name: c.status for c in report.checks}
    assert statuses["Data-flow re-check"] == "Failed"
    assert statuses["Security test cases"] == "Failed"
    assert report.verdict == "Not resolved"


def test_broken_fix_fails_syntax_and_skips_rest():
    code, finding = _first("cwe22_vulnerable.py")
    report = Verifier(None).run(code, code + "\ndef (:\n", finding)
    assert report.checks[0].status == "Failed"
    assert all(c.status == "Unavailable" for c in report.checks[1:])
    assert report.verdict == "Not resolved"


def test_missing_tools_are_unavailable_never_passed(monkeypatch, tmp_path):
    monkeypatch.setattr(checks, "_tool", lambda name: None)
    code, finding = _first("cwe79_vulnerable.py")
    rec = recommend(finding, code)
    result = checks.check_tools(code, rec.corrected, finding, str(tmp_path))
    assert result.status == "Unavailable"
    assert "not installed" in result.detail

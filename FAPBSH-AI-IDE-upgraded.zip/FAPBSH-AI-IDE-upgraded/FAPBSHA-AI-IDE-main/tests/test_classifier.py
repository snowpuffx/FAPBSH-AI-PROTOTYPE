from fapbsh.analysis import analyze_source
from fapbsh.classification import Classification, Classifier, RuleBasedClassifier

CODE = 'import os\nos.system("ping " + input())\n'


def test_rule_based_classifier_assigns_cwe_severity_confidence():
    finding = analyze_source(CODE).findings[0]
    assert finding.cwe == "CWE-78"
    assert finding.severity == "Critical"
    assert 0.5 < finding.confidence <= 0.99
    assert finding.classifier == RuleBasedClassifier.name
    assert finding.rationale


def test_classifier_is_pluggable_without_ui_changes():
    class FixedClassifier(Classifier):
        name = "stub"

        def classify(self, evidence):
            return Classification("CWE-78", "OS Command Injection", "Low", 0.42, ["stub"])

    finding = analyze_source(CODE, classifier=FixedClassifier()).findings[0]
    assert (finding.severity, finding.confidence, finding.classifier) == ("Low", 0.42, "stub")


def test_classifier_may_drop_evidence():
    class DropAll(Classifier):
        def classify(self, evidence):
            return None

    assert analyze_source(CODE, classifier=DropAll()).findings == []

import ast
from pathlib import Path

import pytest

from fapbsh.analysis import analyze_source
from fapbsh.explain import explain, recommend

SAMPLES = Path(__file__).resolve().parent / "samples"
VULNERABLE = sorted(SAMPLES.glob("*_vulnerable.py"))


def _cases():
    for path in VULNERABLE:
        code = path.read_text(encoding="utf-8")
        for finding in analyze_source(code, str(path)).findings:
            yield pytest.param(code, finding, id=f"{path.stem}:{finding.line}")


@pytest.mark.parametrize("code,finding", list(_cases()))
def test_fix_compiles_and_removes_the_finding(code, finding):
    rec = recommend(finding, code)
    assert rec.applicable, rec.note
    ast.parse(rec.corrected)
    assert rec.diff.startswith("--- a/")
    assert rec.removed_lines or rec.added_lines
    before = [f for f in analyze_source(code).findings if f.cwe == finding.cwe]
    after = [f for f in analyze_source(rec.corrected).findings if f.cwe == finding.cwe]
    assert len(after) == len(before) - 1


def test_sql_fix_is_parameterized():
    code = (SAMPLES / "cwe89_vulnerable.py").read_text()
    rec = recommend(analyze_source(code).findings[0], code)
    assert 'query = "SELECT id, email FROM users WHERE name = ?"' in rec.corrected
    assert "cursor.execute(query, (username,))" in rec.corrected


def test_command_fix_uses_list_args_when_possible():
    code = 'import os\nhost = input()\ncmd = f"ping -c 1 {host}"\nos.system(cmd)\n'
    rec = recommend(analyze_source(code).findings[0], code)
    assert 'cmd = ["ping", "-c", "1", host]' in rec.corrected
    assert "subprocess.run(cmd, shell=False, check=False)" in rec.corrected


def test_explanation_names_variable_and_path():
    code = (SAMPLES / "cwe22_vulnerable.py").read_text()
    finding = analyze_source(code).findings[0]
    text = explain(finding, code).as_text()
    assert "'path'" in text
    assert "line 12" in text and "line 14" in text
    assert "Security implication" in text

"""Ping a host typed by the user (fixed)."""
import shlex
import subprocess


def ping_host():
    host = input("Host to ping: ")
    subprocess.run(["ping", "-c", "1", host], shell=False, check=False)


def lookup(domain):
    cmd = "nslookup " + shlex.quote(domain)
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    return result.stdout


if __name__ == "__main__":
    ping_host()

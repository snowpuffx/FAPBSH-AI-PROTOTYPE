"""Demo Flask service with several vulnerabilities (for the IDE demo)."""
import os
import sqlite3
import subprocess

from flask import Flask, request

app = Flask(__name__)
API_TOKEN = "tok_9fA2kLm81QzX7vB3"


@app.route("/ping")
def ping():
    host = request.args.get("host", "")
    count = 1

    # build the diagnostic command
    command = "ping -c {} {}".format(count, host)

    app.logger.info("running diagnostics")
    output = subprocess.check_output(command, shell=True, text=True)
    return output


@app.route("/user")
def user():
    name = request.args.get("name", "")
    conn = sqlite3.connect("users.db")
    rows = conn.execute(f"SELECT email FROM users WHERE name = '{name}'").fetchall()
    return f"<p>{name}: {rows}</p>"


@app.route("/file")
def read_file():
    path = os.path.join("static", request.args["f"])
    with open(path) as handle:
        return handle.read()

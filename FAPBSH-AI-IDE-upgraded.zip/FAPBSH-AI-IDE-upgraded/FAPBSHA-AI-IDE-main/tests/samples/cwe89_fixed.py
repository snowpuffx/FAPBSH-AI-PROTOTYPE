"""Look up a user by name (fixed: parameterized query)."""
import sqlite3
import sys


def find_user(conn, username):
    cursor = conn.cursor()
    query = "SELECT id, email FROM users WHERE name = ?"
    cursor.execute(query, (username,))
    return cursor.fetchall()


def find_by_id(conn, raw_id):
    user_id = int(raw_id)
    return conn.execute(f"SELECT * FROM users WHERE id = {user_id}").fetchall()


def main():
    name = sys.argv[1]
    conn = sqlite3.connect("app.db")
    print(find_user(conn, name))
    print(find_by_id(conn, sys.argv[2]))


if __name__ == "__main__":
    main()

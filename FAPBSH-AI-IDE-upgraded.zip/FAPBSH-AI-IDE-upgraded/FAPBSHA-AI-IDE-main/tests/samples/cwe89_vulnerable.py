"""Look up a user by name (vulnerable: CWE-89)."""
import sqlite3
import sys


def find_user(conn, username):
    cursor = conn.cursor()
    query = "SELECT id, email FROM users WHERE name = '" + username + "'"
    cursor.execute(query)
    return cursor.fetchall()


def main():
    name = sys.argv[1]
    conn = sqlite3.connect("app.db")
    rows = find_user(conn, name)
    print(rows)


if __name__ == "__main__":
    main()

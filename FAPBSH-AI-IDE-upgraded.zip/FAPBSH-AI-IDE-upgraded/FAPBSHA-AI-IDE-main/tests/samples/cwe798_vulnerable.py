"""Connect to the database (vulnerable: CWE-798)."""
import psycopg2

DB_HOST = "db.internal"
DB_PASSWORD = "Pr0d-S3cret!2024"
AWS_KEY = "AKIAIOSFODNN7REALKEY"


def connect():
    return psycopg2.connect(host=DB_HOST, user="app", password=DB_PASSWORD)


def check_admin(entered):
    admin_password = "hunter2xyz"
    return entered == admin_password

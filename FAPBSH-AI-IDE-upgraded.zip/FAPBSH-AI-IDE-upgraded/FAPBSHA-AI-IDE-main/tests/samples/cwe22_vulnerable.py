"""Serve a file from the uploads folder (vulnerable: CWE-22)."""
import os

from flask import Flask, request

app = Flask(__name__)
UPLOAD_DIR = "/srv/app/uploads"


@app.route("/download")
def download():
    filename = request.args.get("file")
    path = os.path.join(UPLOAD_DIR, filename)
    with open(path) as handle:
        return handle.read()

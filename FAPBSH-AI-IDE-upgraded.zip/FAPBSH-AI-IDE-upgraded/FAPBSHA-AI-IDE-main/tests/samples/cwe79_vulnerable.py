"""Greet a visitor (vulnerable: CWE-79)."""
from flask import Flask, make_response, request

app = Flask(__name__)


@app.route("/hello")
def hello():
    name = request.args.get("name", "")
    greeting = f"<h1>Hello, {name}!</h1>"
    return greeting


@app.route("/search")
def search():
    term = request.form["q"]
    body = "<p>Results for " + term + "</p>"
    return make_response(body)

"""Connect to the database (fixed: secrets from the environment)."""
import os

import psycopg2

DB_HOST = "db.internal"
DB_PASSWORD = os.environ.get("DB_PASSWORD", "")
API_KEY = "YOUR_API_KEY"          # placeholder, not a real secret
SECRET_TOKEN = "changeme"         # placeholder
test_password = "abc12345"        # test-named variable
empty_secret = ""


def connect():
    return psycopg2.connect(host=DB_HOST, user="app", password=DB_PASSWORD)

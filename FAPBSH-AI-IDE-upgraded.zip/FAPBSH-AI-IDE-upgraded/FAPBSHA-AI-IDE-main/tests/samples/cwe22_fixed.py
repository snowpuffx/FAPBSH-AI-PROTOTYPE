"""Serve a file from the uploads folder (fixed: containment check)."""
import os

from flask import Flask, abort, request

app = Flask(__name__)
UPLOAD_DIR = "/srv/app/uploads"


@app.route("/download")
def download():
    filename = request.args.get("file")
    base = os.path.realpath(UPLOAD_DIR)
    path = os.path.realpath(os.path.join(base, filename))
    if os.path.commonpath([base, path]) != base:
        abort(403)
    with open(path) as handle:
        return handle.read()

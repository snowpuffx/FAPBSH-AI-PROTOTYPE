"""Ping a host typed by the user (vulnerable: CWE-78)."""
import os
import subprocess


def build_command(host):
    return f"ping -c 1 {host}"


def ping_host():
    host = input("Host to ping: ")
    command = build_command(host)
    os.system(command)


def lookup(domain):
    cmd = "nslookup " + domain
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    return result.stdout


if __name__ == "__main__":
    ping_host()

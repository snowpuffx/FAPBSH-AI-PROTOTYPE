"""Greet a visitor (fixed: output escaping)."""
import html

from flask import Flask, make_response, request
from markupsafe import escape

app = Flask(__name__)


@app.route("/hello")
def hello():
    name = request.args.get("name", "")
    greeting = f"<h1>Hello, {html.escape(name)}!</h1>"
    return greeting


@app.route("/search")
def search():
    term = escape(request.form["q"])
    body = "<p>Results for " + term + "</p>"
    return make_response(body)

"""Engine tests: vulnerable samples produce the expected CWE with a correct
source -> sink trace; fixed samples produce no findings."""

from pathlib import Path

import pytest

from fapbsh.analysis import analyze_file, analyze_source

SAMPLES = Path(__file__).resolve().parent / "samples"

# cwe, file stem, expected (source line, sink line) pairs
EXPECTED = {
    "CWE-78": ("cwe78", [(11, 13)]),
    "CWE-89": ("cwe89", [(14, 9)]),
    "CWE-22": ("cwe22", [(12, 14)]),
    "CWE-79": ("cwe79", [(9, 11), (16, 18)]),
    "CWE-798": ("cwe798", [(5, 10), (6, 6), (14, 15)]),
}


@pytest.mark.parametrize("cwe", sorted(EXPECTED))
def test_vulnerable_sample_is_detected_with_trace(cwe):
    stem, pairs = EXPECTED[cwe]
    result = analyze_file(SAMPLES / f"{stem}_vulnerable.py")
    assert result.ok
    findings = [f for f in result.findings if f.cwe == cwe]
    assert findings, f"no {cwe} finding"
    got = sorted((f.source_line, f.sink_line) for f in findings)
    assert got == sorted(pairs)
    for finding in findings:
        roles = [role for _, role in finding.trace_tuples]
        assert roles[0] == "source"
        assert roles[-1] == "sink"
        assert all(r in ("source", "propagation", "sink") for r in roles)
        # Taint findings are located at the sink; CWE-798 at the literal.
        anchor = roles.index("source") if cwe == "CWE-798" else -1
        assert finding.trace_tuples[anchor][0] == finding.line


@pytest.mark.parametrize("cwe", sorted(EXPECTED))
def test_fixed_sample_has_no_findings(cwe):
    stem, _ = EXPECTED[cwe]
    result = analyze_file(SAMPLES / f"{stem}_fixed.py")
    assert result.ok
    assert result.findings == []


def test_only_the_expected_cwe_in_each_vulnerable_sample():
    for cwe, (stem, _) in EXPECTED.items():
        result = analyze_file(SAMPLES / f"{stem}_vulnerable.py")
        assert {f.cwe for f in result.findings} == {cwe}


def test_finding_carries_required_fields():
    result = analyze_file(SAMPLES / "cwe78_vulnerable.py")
    finding = result.findings[0]
    for name in ("id", "cwe", "name", "severity", "file", "line", "column",
                 "snippet", "confidence", "trace"):
        assert getattr(finding, name) not in (None, ""), name
    assert 0 < finding.confidence <= 1
    assert finding.snippet == "os.system(command)"
    # propagation through function argument and return value
    assert finding.trace_tuples == [
        (11, "source"), (7, "propagation"), (12, "propagation"), (13, "sink")
    ]


def test_placeholders_are_suppressed_not_reported():
    result = analyze_file(SAMPLES / "cwe798_fixed.py")
    reasons = " ".join(s.reason for s in result.suppressed)
    assert "YOUR_API_KEY" in reasons
    assert "changeme" in reasons
    assert "test-named" in reasons
    assert "empty" in reasons


@pytest.mark.parametrize("code", [
    'import os, shlex\nos.system("ls " + shlex.quote(input()))\n',
    'import subprocess\nsubprocess.run(["ls", input()], shell=False)\n',
    'import sqlite3, sys\nsqlite3.connect("x").execute("SELECT ?", (sys.argv[1],))\n',
    'import html\nfrom flask import Flask, request, make_response\napp = Flask(__name__)\n'
    '@app.route("/")\ndef i():\n    return make_response("<b>" + html.escape(request.args["q"]) + "</b>")\n',
    'import os\nname = os.path.basename(input())\nopen(os.path.join("/data", name))\n',
])
def test_sanitizers_break_the_taint_path(code):
    assert analyze_source(code).findings == []


@pytest.mark.parametrize("code,cwe", [
    ('import os\nx = input()\ncmd = "echo %s" % x\nos.system(cmd)\n', "CWE-78"),
    ('import os\nx = input()\ncmd = "echo {}".format(x)\nos.popen(cmd).read()\n', "CWE-78"),
    ('import sqlite3\nq = input()\nsqlite3.connect("a").execute(f"SELECT * FROM t WHERE a={q}")\n', "CWE-89"),
    ('import sys\nopen(sys.argv[1]).read()\n', "CWE-22"),
    ('import os\nopen(os.environ["UPLOAD"])\n', "CWE-22"),
])
def test_propagation_forms(code, cwe):
    assert [f.cwe for f in analyze_source(code).findings] == [cwe]


def test_html_shell_sanitizer_does_not_protect_other_category():
    code = 'import os, html\nos.system("echo " + html.escape(input()))\n'
    assert [f.cwe for f in analyze_source(code).findings] == ["CWE-78"]


def test_syntax_error_is_reported_not_raised():
    result = analyze_source("def broken(:\n")
    assert not result.ok
    assert "SyntaxError" in result.errors[0]


import sys
from pathlib import Path

from PySide6.QtCore import Qt, QDir, QProcess
from PySide6.QtGui import QAction, QKeySequence, QTextCursor
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout,
    QHBoxLayout, QLabel, QPushButton,
    QTreeView, QFileSystemModel,
    QTabWidget, QTextEdit, QSplitter,
    QFileDialog, QMessageBox, QStatusBar,
    QInputDialog, QLineEdit, QToolBar,
    QApplication
)

from ui.welcome_widget import WelcomeWidget
from ui.editor.code_editor import CodeEditor
from ui.editor.find_replace import FindReplaceDialog
from ui.execution.python_runner import PythonRunner
from ui.terminal.terminal_widget import TerminalWidget
from ui.analysis.findings_panel import AnalysisPanel
from ui.analysis.problems_list import ProblemsList
from ui.analysis.workers import AnalysisWorker, WorkerPool

class MainWindow(QMainWindow):

    def __init__(self):
        super().__init__()

        self.setWindowTitle("FAPBSH AI IDE")
        self.resize(1250, 780)
        self.setMinimumSize(900, 600)
        self.showMaximized()

        self.project_path = None

        # Stores editor information for each tab
        self.documents = {}

        # Security analysis state
        self.workers = WorkerPool(self)
        self.analysis_token = 0
        self.analysis_editor = None
        self.analysis_code = ""
        self.findings = []
        self.ignored_findings = set()
        self._keep_verification = False

        # Python execution manager
        self.python_runner = PythonRunner(self)
        self.python_runner.output_received.connect(
            self.display_program_output
        )
        self.python_runner.error_received.connect(
            self.display_program_error
        )
        self.python_runner.process_started.connect(
            self.on_python_started
        )
        self.python_runner.process_finished.connect(
            self.on_python_finished
        )
        self.python_runner.process_error.connect(
            self.on_python_error
        )

        self.setup_menu()
        self.setup_toolbar()
        self.setup_interface()
        self.setup_statusbar()

    # =================================
    # MENU BAR
    # =================================

    def setup_menu(self):

        menubar = self.menuBar()

        file_menu = menubar.addMenu("File")

        self.add_action(
            file_menu, "New File",
            "Ctrl+N", self.new_file
        )

        self.add_action(
            file_menu, "Open File",
            "Ctrl+O", self.open_file
        )

        self.add_action(
            file_menu, "Open Folder",
            "Ctrl+Shift+O", self.open_folder
        )

        file_menu.addSeparator()

        self.add_action(
            file_menu, "Save",
            "Ctrl+S", self.save_file
        )

        self.add_action(
            file_menu, "Save As",
            "Ctrl+Shift+S", self.save_file_as
        )

        file_menu.addSeparator()

        self.add_action(
            file_menu, "New Project",
            None, self.new_project
        )

        file_menu.addSeparator()

        self.add_action(
            file_menu, "Exit",
            "Alt+F4", self.close
        )

        edit_menu = menubar.addMenu("Edit")

        self.add_action(
            edit_menu, "Undo",
            "Ctrl+Z", self.editor_command,
            "undo"
        )

        self.add_action(
            edit_menu, "Redo",
            "Ctrl+Y", self.editor_command,
            "redo"
        )

        edit_menu.addSeparator()

        self.add_action(
            edit_menu, "Cut",
            "Ctrl+X", self.editor_command,
            "cut"
        )

        self.add_action(
            edit_menu, "Copy",
            "Ctrl+C", self.editor_command,
            "copy"
        )

        self.add_action(
            edit_menu, "Paste",
            "Ctrl+V", self.editor_command,
            "paste"
        )

        edit_menu.addSeparator()

        self.add_action(
            edit_menu, "Find and Replace",
            "Ctrl+F", self.find_replace
        )

        view_menu = menubar.addMenu("View")

        self.add_action(
            view_menu, "Toggle Explorer",
            None, self.toggle_sidebar
        )

        self.add_action(
            view_menu, "Toggle Bottom Panel",
            None, self.toggle_bottom_panel
        )

        run_menu = menubar.addMenu("Run")

        self.run_action = self.add_action(
            run_menu, "Run Python File",
            "F5", self.run_python_file
        )

        self.stop_action = self.add_action(
            run_menu, "Stop",
            "Shift+F5", self.stop_python_file
        )
        self.stop_action.setEnabled(False)

        run_menu.addSeparator()

        self.analyze_action = self.add_action(
            run_menu, "Analyze Security",
            "Ctrl+Shift+A", self.analyze_current_file
        )

        help_menu = menubar.addMenu("Help")

        self.add_action(
            help_menu, "About FAPBSH AI IDE",
            None, self.show_about
        )

    def add_action(
        self, menu, title, shortcut,
        callback, *args
    ):

        action = QAction(title, self)

        if shortcut:
            action.setShortcut(
                QKeySequence(shortcut)
            )

        action.triggered.connect(
            lambda checked=False:
            callback(*args)
        )

        menu.addAction(action)

        return action

    # =================================
    # PYTHON EXECUTION TOOLBAR
    # =================================

    def setup_toolbar(self):

        # Analyze (primary) and Run (secondary) sit at the right end of
        # the menu bar, as in the wireframe. The former separate toolbar
        # row was removed; Run/Stop live in the Run menu (F5 / Shift+F5).
        # Keep a reference: PySide6 does not take ownership here.
        self.corner_widget = corner = QWidget(self.menuBar())
        corner_layout = QHBoxLayout(corner)
        corner_layout.setContentsMargins(0, 2, 10, 2)
        corner_layout.setSpacing(12)

        self.analyze_button = QPushButton("Analyze")
        self.analyze_button.setObjectName("primaryButton")
        self.analyze_button.setToolTip(
            "Scan the current file for CWE-79, 798, 78, 22 and 89 "
            "(Ctrl+Shift+A)"
        )
        self.analyze_button.clicked.connect(
            self.analyze_action.trigger
        )

        self.run_button = QPushButton("Run")
        self.run_button.setObjectName("secondaryButton")
        self.run_button.setToolTip("Run the current Python file (F5)")
        self.run_button.clicked.connect(self.run_action.trigger)
        self.run_action.changed.connect(
            lambda: self.run_button.setEnabled(
                self.run_action.isEnabled()
            )
        )

        corner_layout.addWidget(self.analyze_button)
        corner_layout.addWidget(self.run_button)

        self.menuBar().setCornerWidget(
            corner, Qt.Corner.TopRightCorner
        )

    # =================================
    # PYTHON EXECUTION
    # =================================

    def append_console(self, text):

        self.terminal.moveCursor(
            QTextCursor.MoveOperation.End
        )
        self.terminal.insertPlainText(text)
        self.terminal.ensureCursorVisible()

    def run_python_file(self):

        editor = self.current_editor()

        if not editor:
            QMessageBox.information(
                self,
                "Run Python",
                "Please open a Python file first."
            )
            return

        path = self.documents.get(editor)

        if not path:
            self.save_file_as()
            path = self.documents.get(editor)

            if not path:
                return

        # Save modified content before execution.
        if editor.document().isModified():
            self.write_file(editor, path)

            if editor.document().isModified():
                return

        file_path = Path(path).resolve()

        if not file_path.is_file():
            QMessageBox.warning(
                self,
                "File Not Found",
                "The selected file does not exist."
            )
            return

        if file_path.suffix.lower() != ".py":
            QMessageBox.warning(
                self,
                "Invalid File",
                "Only Python (.py) files can be executed."
            )
            return

        if (
            self.python_runner.process.state()
            != QProcess.ProcessState.NotRunning
        ):
            QMessageBox.warning(
                self,
                "Program Running",
                "Stop the current program first."
            )
            return

        self.terminal.clear()
        self.bottom_panel.setCurrentWidget(
            self.terminal_container
        )
        self.bottom_panel.setVisible(True)

        self.append_console(
            f"Running: {file_path.name}\n"
            f"Interpreter: {sys.executable}\n\n"
        )

        self.status_message.setText(
            "Starting Python program..."
        )

        try:
            self.python_runner.run(str(file_path))

        except (OSError, RuntimeError) as error:
            self.append_console(
                f"\n[ERROR] {error}\n"
            )
            self.status_message.setText(
                "Unable to execute Python program"
            )

    def stop_python_file(self):

        if (
            self.python_runner.process.state()
            != QProcess.ProcessState.NotRunning
        ):
            self.append_console(
                "\n[STOP] Stopping Python program...\n"
            )
            self.python_runner.stop()

    def send_terminal_input(self):

        text = self.terminal_input.text()

        if (
            self.python_runner.process.state()
            != QProcess.ProcessState.Running
        ):
            return

        self.append_console(text + "\n")
        self.python_runner.send_input(text + "\n")
        self.terminal_input.clear()

    def display_program_output(self, text):
        self.append_console(text)

    def display_program_error(self, text):
        self.append_console(text)

    def on_python_started(self):

        self.terminal_input.setEnabled(True)
        self.run_action.setEnabled(False)
        self.stop_action.setEnabled(True)

        self.status_message.setText(
            "Python program is running..."
        )

        self.terminal_input.setFocus()

    def on_python_finished(self, exit_code, status):

        self.terminal_input.setEnabled(False)
        self.run_action.setEnabled(True)
        self.stop_action.setEnabled(False)

        self.append_console(
            f"\n\nProcess finished with exit code "
            f"{exit_code} ({status}).\n"
        )

        self.status_message.setText(
            f"Execution finished: exit code {exit_code}"
        )

    def on_python_error(self, message):

        self.terminal_input.setEnabled(False)
        self.run_action.setEnabled(True)
        self.stop_action.setEnabled(False)

        self.append_console(
            f"\n[EXECUTION ERROR] {message}\n"
        )

        self.status_message.setText(
            "Python execution error"
        )

    # =================================
    # MAIN INTERFACE
    # =================================

    def setup_interface(self):

        central = QWidget()
        self.setCentralWidget(central)

        main_layout = QVBoxLayout(central)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # Header
        header = QWidget()
        header.setFixedHeight(38)
        header.setStyleSheet(
            "background-color: #323233;"
        )

        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(12, 0, 12, 0)

        logo = QLabel("FAPBSH AI IDE")
        logo.setStyleSheet(
            "font-weight: bold; color: #007acc;"
        )

        header_layout.addWidget(logo)
        header_layout.addSpacing(20)
        header_layout.addWidget(
            QLabel("Python Development Environment")
        )
        header_layout.addStretch()

        main_layout.addWidget(header)

        # The wireframe has no custom header row; the window title
        # already shows "FAPBSH AI IDE".
        header.setVisible(False)

        # Body
        body = QWidget()
        body_layout = QHBoxLayout(body)
        body_layout.setContentsMargins(0, 0, 0, 0)
        body_layout.setSpacing(0)

        # Activity bar
        self.activity_bar = QWidget()
        self.activity_bar.setFixedWidth(50)
        self.activity_bar.setStyleSheet(
            "background-color: #8c8c8c;"
        )

        activity_layout = QVBoxLayout(self.activity_bar)
        activity_layout.setContentsMargins(0, 10, 0, 10)

        self.activity_buttons = []

        activities = [
            ("▤", "Explorer"),
            ("⌕", "Search"),
            ("◇", "Extensions"),
            ("⚙", "Settings")
        ]

        for symbol, name in activities:

            button = QPushButton(symbol)
            button.setCheckable(True)
            button.setToolTip(name)
            button.setFixedSize(50, 45)

            button.clicked.connect(
                lambda checked, n=name:
                self.activity_selected(n)
            )

            activity_layout.addWidget(button)
            self.activity_buttons.append(button)

        self.activity_buttons[0].setChecked(True)
        activity_layout.addStretch()

        # Sidebar
        self.sidebar = QWidget()
        self.sidebar.setFixedWidth(240)
        self.sidebar.setStyleSheet(
            "background-color: #f0f0f0;"
            "border-right: 1px solid #9a9a9a;"
        )

        sidebar_layout = QVBoxLayout(self.sidebar)
        sidebar_layout.setContentsMargins(0, 10, 0, 0)

        self.sidebar_title = QLabel("  EXPLORER")
        self.sidebar_title.setStyleSheet(
            "font-weight: bold; font-size: 11pt; padding: 4px 6px;"
        )
        sidebar_layout.addWidget(self.sidebar_title)

        self.project_label = QLabel(
            "  NO FOLDER OPENED"
        )

        self.project_label.setStyleSheet(
            "color: #5c5c5c; padding: 10px;"
        )

        sidebar_layout.addWidget(self.project_label)

        self.file_model = QFileSystemModel()

        self.file_model.setFilter(
            QDir.Filter.AllEntries |
            QDir.Filter.NoDotAndDotDot
        )

        self.file_tree = QTreeView()
        self.file_tree.setModel(self.file_model)
        self.file_tree.setHeaderHidden(True)

        for column in range(1, 4):
            self.file_tree.hideColumn(column)

        self.file_tree.doubleClicked.connect(
            self.open_selected_file
        )

        sidebar_layout.addWidget(self.file_tree)

        # Workspace
        self.workspace = QWidget()
        workspace_layout = QVBoxLayout(self.workspace)
        workspace_layout.setContentsMargins(0, 0, 0, 0)
        workspace_layout.setSpacing(0)

        self.splitter = QSplitter(
            Qt.Orientation.Vertical
        )

        # Editor tabs
        self.editor_tabs = QTabWidget()
        self.editor_tabs.setTabsClosable(True)
        self.editor_tabs.setMovable(True)
        self.editor_tabs.currentChanged.connect(
            self.update_editor_status
        )

        self.editor_tabs.tabCloseRequested.connect(
            self.close_tab
        )

        self.editor_tabs.setDocumentMode(True)

        self.welcome = WelcomeWidget()

        self.welcome.open_folder_btn.clicked.connect(
            self.open_folder
        )

        self.welcome.new_project_btn.clicked.connect(
            self.new_project
        )

        self.editor_tabs.addTab(
            self.welcome, "Welcome"
        )

        self.splitter.addWidget(self.editor_tabs)

        # Bottom panel
        self.bottom_panel = QTabWidget()
        self.bottom_panel.setMinimumHeight(100)
        self.bottom_panel.setMaximumHeight(250)

        # Problems: one clickable row per finding
        self.problems = ProblemsList()
        self.problems.finding_activated.connect(
            self.select_finding
        )

        # Python execution terminal
        self.terminal_container = QWidget()
        terminal_layout = QVBoxLayout(self.terminal_container)
        terminal_layout.setContentsMargins(5, 5, 5, 5)
        terminal_layout.setSpacing(5)

        self.terminal = QTextEdit()
        self.terminal.setReadOnly(True)
        self.terminal.setPlaceholderText(
            "Python execution output will appear here."
        )
        self.terminal.setStyleSheet("""
            QTextEdit {
                background-color: #ffffff;
                color: #1a1a1a;
                border: 1px solid #c8c8c8;
                font-family: Consolas, monospace;
                font-size: 10pt;
            }
        """)

        self.terminal_input = QLineEdit()

        self.terminal_input.setPlaceholderText(
            "Type your input here and press Enter..."
        )

        self.terminal_input.setFixedHeight(35)

        self.terminal_input.setStyleSheet("""
            QLineEdit {
                background-color: #ffffff;
                color: #1a1a1a;
                border: 1px solid #3a3a3a;
                padding: 5px;
                font-family: Consolas, monospace;
                font-size: 10pt;
            }

            QLineEdit:disabled {
                background-color: #e6e6e6;
                color: #8a8a8a;
                border: 1px solid #c8c8c8;
            }
        """)

        self.terminal_input.setEnabled(False)

        self.terminal_input.returnPressed.connect(
            self.send_terminal_input
        )

        terminal_layout.addWidget(self.terminal)
        terminal_layout.addWidget(self.terminal_input)

        self.bottom_panel.addTab(
            self.problems, "Problems"
        )

        # The run console (with its stdin line) is the Output tab.
        self.bottom_panel.addTab(
            self.terminal_container, "Output"
        )

        self.system_terminal = TerminalWidget(
            self,
            working_directory=self.project_path or Path.cwd()
        )

        self.bottom_panel.addTab(
            self.system_terminal, "Terminal"
        )

        self.splitter.addWidget(self.bottom_panel)
        self.splitter.setSizes([550, 180])

        workspace_layout.addWidget(self.splitter)

        # Right panel: Findings / Explanation / Recommendation / Verification
        self.analysis_panel = AnalysisPanel(self.workers)
        self.analysis_panel.setMinimumWidth(360)
        self.analysis_panel.finding_selected.connect(
            self.show_finding_trace
        )
        self.analysis_panel.apply_requested.connect(
            self.apply_recommendation
        )
        self.analysis_panel.copy_requested.connect(
            self.copy_recommendation
        )
        self.analysis_panel.ignore_requested.connect(
            self.ignore_finding
        )

        self.main_splitter = QSplitter(Qt.Orientation.Horizontal)
        self.main_splitter.addWidget(self.workspace)
        self.main_splitter.addWidget(self.analysis_panel)
        self.main_splitter.setStretchFactor(0, 3)
        self.main_splitter.setStretchFactor(1, 2)
        self.main_splitter.setSizes([760, 520])

        body_layout.addWidget(self.activity_bar)
        body_layout.addWidget(self.sidebar)
        body_layout.addWidget(self.main_splitter)

        main_layout.addWidget(body)


    # =================================
    # STATUS BAR
    # =================================

    def setup_statusbar(self):

        status = QStatusBar()
        self.setStatusBar(status)

        self.status_message = QLabel("Ready")
        self.cursor_status = QLabel("Ln 1, Col 1")
        self.findings_status = QLabel("0 findings")

        status.addWidget(self.status_message)
        status.addPermanentWidget(self.cursor_status)
        status.addPermanentWidget(self.findings_status)
        status.addPermanentWidget(QLabel("Python"))
        status.addPermanentWidget(QLabel("UTF-8"))

    def update_editor_status(self, index):

        editor = self.current_editor()

        if editor:
            cursor = editor.textCursor()

            self.cursor_status.setText(
                f"Ln {cursor.blockNumber() + 1}, "
                f"Col {cursor.positionInBlock() + 1}"
            )

    # =================================
    # EDITOR HELPERS
    # =================================

    def current_editor(self):

        widget = self.editor_tabs.currentWidget()

        if isinstance(widget, CodeEditor):
            return widget

        return None

    def current_path(self):

        editor = self.current_editor()

        if editor:
            return self.documents.get(editor)

        return None

    def create_editor(self, path=None, content=""):

        # Remove welcome tab when creating first editor
        welcome_index = self.editor_tabs.indexOf(
            self.welcome
        )

        if welcome_index != -1:
            self.editor_tabs.removeTab(welcome_index)

        editor = CodeEditor()

        editor.setPlainText(content)

        if path:
            editor.document().setModified(False)

        editor.cursorPositionChanged.connect(
            lambda: self.update_editor_status(
                self.editor_tabs.indexOf(editor)
            )
        )

        editor.textChanged.connect(
            lambda: self.update_tab_title(editor)
        )

        editor.textChanged.connect(
            lambda: self.on_editor_text_changed(editor)
        )

        self.documents[editor] = path

        name = Path(path).name if path else "Untitled"

        index = self.editor_tabs.addTab(
            editor, name
        )

        self.editor_tabs.setCurrentIndex(index)

        self.update_tab_title(editor)

        return editor

    def update_tab_title(self, editor):

        index = self.editor_tabs.indexOf(editor)

        if index == -1:
            return

        path = self.documents.get(editor)

        name = Path(path).name if path else "Untitled"

        if editor.document().isModified():
            name = "*" + name

        self.editor_tabs.setTabText(index, name)

    # =================================
    # NEW FILE
    # =================================

    def new_file(self):

        self.create_editor()

        self.status_message.setText(
            "New file created"
        )

    # =================================
    # OPEN FILE
    # =================================

    def open_file(self):

        path, _ = QFileDialog.getOpenFileName(
            self,
            "Open Python File",
            str(Path.home()),
            "Python Files (*.py);;All Files (*.*)"
        )

        if path:
            self.load_file(path)

    def load_file(self, path):

        path = str(Path(path).resolve())

        # Check whether file is already open
        for editor, existing_path in self.documents.items():

            if existing_path == path:
                self.editor_tabs.setCurrentWidget(editor)
                return

        try:
            content = Path(path).read_text(
                encoding="utf-8"
            )

            self.create_editor(path, content)

            self.status_message.setText(
                f"Opened: {path}"
            )

        except (OSError, UnicodeError) as error:

            QMessageBox.critical(
                self,
                "Open Error",
                str(error)
            )

    # =================================
    # SAVE FILE
    # =================================

    def save_file(self):

        editor = self.current_editor()

        if not editor:
            return

        path = self.documents.get(editor)

        if not path:
            self.save_file_as()
            return

        self.write_file(editor, path)

    def save_file_as(self):

        editor = self.current_editor()

        if not editor:
            return

        path, _ = QFileDialog.getSaveFileName(
            self,
            "Save Python File",
            str(Path.home() / "untitled.py"),
            "Python Files (*.py);;All Files (*.*)"
        )

        if not path:
            return

        if not Path(path).suffix:
            path += ".py"

        # Prevent overwriting another open document
        resolved_path = str(Path(path).resolve())

        for other_editor, other_path in self.documents.items():

            if other_editor is not editor and other_path == resolved_path:

                QMessageBox.warning(
                    self,
                    "File Already Open",
                    "This file is already open in another tab."
                )

                self.editor_tabs.setCurrentWidget(other_editor)
                return

        self.documents[editor] = resolved_path

        self.write_file(editor, resolved_path)

    def write_file(self, editor, path):

        try:
            Path(path).write_text(
                editor.toPlainText(),
                encoding="utf-8"
            )

            editor.document().setModified(False)

            self.update_tab_title(editor)

            self.status_message.setText(
                f"Saved: {path}"
            )

        except OSError as error:

            QMessageBox.critical(
                self,
                "Save Error",
                str(error)
            )

    # =================================
    # CLOSE TAB
    # =================================

    def close_tab(self, index):

        widget = self.editor_tabs.widget(index)

        if widget == self.welcome:
            return

        if isinstance(widget, CodeEditor):

            if widget.document().isModified():

                name = self.editor_tabs.tabText(index)

                answer = QMessageBox.question(
                    self,
                    "Unsaved Changes",
                    f"Save changes to {name}?",
                    QMessageBox.StandardButton.Save |
                    QMessageBox.StandardButton.Discard |
                    QMessageBox.StandardButton.Cancel
                )

                if answer == QMessageBox.StandardButton.Cancel:
                    return

                if answer == QMessageBox.StandardButton.Save:

                    self.editor_tabs.setCurrentIndex(index)

                    if not self.documents.get(widget):
                        self.save_file_as()
                    else:
                        self.save_file()

                    if widget.document().isModified():
                        return

            self.documents.pop(widget, None)

            if widget is self.analysis_editor:
                self.analysis_editor = None
                self.set_findings_count(0)
                self.problems.set_message(
                    "No problems to display. Click Analyze to scan the current file."
                )
                self.analysis_panel.clear_results(
                    "Click Analyze to scan the current file."
                )

        self.editor_tabs.removeTab(index)
        widget.deleteLater()

        if self.editor_tabs.count() == 0:
            self.show_welcome()

    def show_welcome(self):

        if self.editor_tabs.count() == 0:

            self.editor_tabs.addTab(
                self.welcome, "Welcome"
            )

    # =================================
    # FILE EXPLORER
    # =================================

    def open_selected_file(self, index):

        path = self.file_model.filePath(index)

        if Path(path).is_file():
            self.load_file(path)

    def open_folder(self):

        folder = QFileDialog.getExistingDirectory(
            self,
            "Open Project Folder",
            str(Path.home())
        )

        if folder:
            self.load_project(folder)


    def load_project(self, folder):

        folder = str(Path(folder).resolve())

        if not Path(folder).is_dir():
            QMessageBox.warning(
                self,
                "Invalid Project",
                "The selected project folder does not exist."
            )
            return

        # Store the currently opened project
        self.project_path = folder

        # Update integrated terminal directory
        if hasattr(self, "system_terminal"):
            self.system_terminal.set_working_directory(folder)

        root_index = self.file_model.setRootPath(folder)

        self.file_tree.setRootIndex(root_index)

        self.project_label.setText(
            "  " + Path(folder).name.upper()
        )

        self.status_message.setText(
            f"Project opened: {folder}"
        )

        self.activity_selected("Explorer")

    def new_project(self):

        folder = QFileDialog.getExistingDirectory(
            self,
            "Choose Project Location",
            str(Path.home())
        )

        if not folder:
            return

        name, accepted = QInputDialog.getText(
            self,
            "New Project",
            "Enter project name:"
        )

        if not accepted or not name.strip():
            return

        if name in (".", "..") or Path(name).name != name:
            QMessageBox.warning(
                self,
                "Invalid Name",
                "Enter a valid project folder name."
            )
            return

        project = Path(folder) / name

        try:
            project.mkdir(
                parents=True,
                exist_ok=False
            )

            main_file = project / "main.py"

            main_file.write_text(
                'print("Hello from FAPBSH AI IDE!")\n',
                encoding="utf-8"
            )

            self.load_project(str(project))
            self.load_file(str(main_file))

        except FileExistsError:

            QMessageBox.warning(
                self,
                "Project Exists",
                "A folder with that name already exists."
            )

        except OSError as error:

            QMessageBox.critical(
                self,
                "Project Error",
                str(error)
            )

    # =================================
    # FIND AND REPLACE
    # =================================

    def find_replace(self):

        editor = self.current_editor()

        if not editor:
            return

        dialog = FindReplaceDialog(
            editor, self
        )

        dialog.show()
        dialog.raise_()
        dialog.activateWindow()

    # =================================
    # EDIT COMMANDS
    # =================================

    def editor_command(self, command):

        editor = self.current_editor()

        if editor:
            getattr(editor, command)()

    # =================================
    # ACTIVITY BAR
    # =================================

    def activity_selected(self, name):

        for button in self.activity_buttons:

            button.setChecked(
                button.toolTip() == name
            )

        self.sidebar.setVisible(True)

        self.sidebar_title.setText(
            "  " + name.upper()
        )

        if name == "Explorer":

            self.project_label.setText(
                "  " + (
                    Path(self.project_path).name.upper()
                    if self.project_path
                    else "NO FOLDER OPENED"
                )
            )

        else:

            self.project_label.setText(
                "  " + name.upper() + " COMING SOON"
            )

    # =================================
    # SECURITY ANALYSIS
    # =================================

    def analyze_current_file(self):

        editor = self.current_editor()

        if not editor:
            QMessageBox.information(
                self,
                "Analyze",
                "Please open a Python file first."
            )
            return

        path = self.documents.get(editor) or "untitled.py"
        code = editor.toPlainText()

        self.analysis_token += 1
        self.analysis_editor = editor
        self.analysis_code = code
        self.analyze_button.setEnabled(False)
        self.analyze_action.setEnabled(False)
        self.status_message.setText(
            f"Analyzing {Path(path).name}..."
        )

        worker = AnalysisWorker(code, path, self.analysis_token)
        worker.finished.connect(self.on_analysis_finished)
        worker.failed.connect(self.on_analysis_failed)
        self.workers.start(worker)

    def on_analysis_finished(self, result, token):

        if token != self.analysis_token:
            return

        self._analysis_done()
        editor = self.analysis_editor

        if editor is None:
            return

        editor.clear_trace()

        if result.errors:
            self.findings = []
            self.set_findings_count(0)
            self.problems.set_message(
                "Analysis stopped: " + "; ".join(result.errors)
            )
            self.analysis_panel.clear_results(
                "The file could not be parsed: "
                + "; ".join(result.errors)
            )
            self.status_message.setText("Analysis failed: syntax error")
            return

        findings = [
            f for f in result.findings
            if f.key() not in self.ignored_findings
        ]
        self.findings = findings

        self.set_findings_count(len(findings))
        self.problems.set_findings(findings)

        select_first = not getattr(self, "_keep_verification", False)
        self._keep_verification = False

        self.analysis_panel.set_results(
            findings,
            self.analysis_code,
            project_dir=self.analysis_project_dir(),
            select_first=select_first,
        )

        hidden = len(result.findings) - len(findings)
        message = (
            f"Analysis complete: {len(findings)} "
            f"finding{'s' if len(findings) != 1 else ''}"
        )
        if hidden:
            message += f" ({hidden} ignored)"
        self.status_message.setText(message)

        if findings and select_first:
            self.bottom_panel.setCurrentWidget(self.problems)

    def on_analysis_failed(self, message, token):

        if token != self.analysis_token:
            return

        self._analysis_done()
        self.status_message.setText("Analysis error")
        self.problems.set_message("Analysis error: " + message)

    def _analysis_done(self):

        self.analyze_button.setEnabled(True)
        self.analyze_action.setEnabled(True)

    def analysis_project_dir(self):

        if self.project_path:
            return self.project_path

        path = self.documents.get(self.analysis_editor)

        return str(Path(path).parent) if path else None

    def set_findings_count(self, count):

        self.findings_status.setText(
            f"{count} finding{'s' if count != 1 else ''}"
        )

    def select_finding(self, finding_id):

        self.analysis_panel.setCurrentIndex(
            self.analysis_panel.FINDINGS
        )
        self.analysis_panel.select(finding_id)

    def show_finding_trace(self, finding):

        editor = self.analysis_editor

        if editor is None:
            return

        if self.editor_tabs.indexOf(editor) != -1:
            self.editor_tabs.setCurrentWidget(editor)

        self.problems.select_finding(finding.id)

        if editor.toPlainText() != self.analysis_code:
            self.status_message.setText(
                "The file changed since analysis. Run Analyze again."
            )
            return

        # ast columns are UTF-8 byte offsets; the editor needs characters.
        lines = self.analysis_code.splitlines()

        def char_col(line, byte_col):
            if 1 <= line <= len(lines):
                raw = lines[line - 1].encode("utf-8")[:max(0, byte_col)]
                return len(raw.decode("utf-8", "ignore"))
            return byte_col

        end_line = finding.end_line or finding.line
        editor.set_trace(
            finding.trace_tuples,
            (
                finding.line,
                char_col(finding.line, finding.column - 1),
                end_line,
                char_col(end_line, (finding.end_column or finding.column) - 1),
            ),
        )
        editor.go_to_line(finding.line, finding.column)

    def on_editor_text_changed(self, editor):

        if (
            editor is self.analysis_editor
            and editor.trace_steps
            and editor.toPlainText() != self.analysis_code
        ):
            editor.clear_trace()

    def apply_recommendation(self, finding, recommendation):

        editor = self.analysis_editor

        if editor is None or self.editor_tabs.indexOf(editor) == -1:
            QMessageBox.information(
                self, "Apply", "The analyzed file is no longer open."
            )
            return

        if editor.toPlainText() != recommendation.original:
            QMessageBox.warning(
                self,
                "Apply",
                "The file changed since it was analyzed. "
                "Run Analyze again before applying a fix."
            )
            return

        original = editor.toPlainText()
        editor.apply_text(recommendation.corrected)
        self.editor_tabs.setCurrentWidget(editor)
        self.status_message.setText(
            f"Applied fix for {finding.cwe} (Ctrl+Z to undo). "
            "Verifying..."
        )

        # Verify the applied fix, then refresh findings without losing
        # the verification view.
        self.analysis_panel.verify_applied(
            finding, recommendation, original
        )
        self._keep_verification = True
        self.analyze_current_file()

    def copy_recommendation(self, recommendation):

        QApplication.clipboard().setText(recommendation.corrected)
        self.status_message.setText(
            "Corrected code copied to the clipboard"
        )

    def ignore_finding(self, finding):

        self.ignored_findings.add(finding.key())
        remaining = [f for f in self.findings if f.id != finding.id]
        self.findings = remaining

        if self.analysis_editor is not None:
            self.analysis_editor.clear_trace()

        self.set_findings_count(len(remaining))
        self.problems.set_findings(remaining)
        self.analysis_panel.set_results(
            remaining,
            self.analysis_code,
            project_dir=self.analysis_project_dir(),
            select_first=True,
        )
        self.analysis_panel.setCurrentIndex(
            self.analysis_panel.FINDINGS
        )
        self.status_message.setText(
            f"Ignored {finding.cwe} at line {finding.line} "
            "for this session"
        )

    # =================================
    # VIEW
    # =================================

    def toggle_sidebar(self):

        self.sidebar.setVisible(
            not self.sidebar.isVisible()
        )

    def toggle_bottom_panel(self):

        self.bottom_panel.setVisible(
            not self.bottom_panel.isVisible()
        )

    # =================================
    # ABOUT
    # =================================

    def show_about(self):

        QMessageBox.about(
            self,
            "About FAPBSH AI IDE",
            """
            <h2>FAPBSH AI IDE</h2>
            <p>Custom Python Integrated Development Environment.</p>
            <p>Version 1.0</p>
            <p>Developed using Python and PySide6.</p>
            """
        )

    # =================================
    # APPLICATION CLOSE
    # =================================

    def closeEvent(self, event):

        for index in range(self.editor_tabs.count()):

            widget = self.editor_tabs.widget(index)

            if not isinstance(widget, CodeEditor):
                continue

            if widget.document().isModified():

                self.editor_tabs.setCurrentWidget(widget)

                name = self.editor_tabs.tabText(
                    self.editor_tabs.currentIndex()
                )

                answer = QMessageBox.question(
                    self,
                    "Unsaved Changes",
                    f"Save changes to {name} before exiting?",
                    QMessageBox.StandardButton.Save |
                    QMessageBox.StandardButton.Discard |
                    QMessageBox.StandardButton.Cancel
                )

                if answer == QMessageBox.StandardButton.Cancel:
                    event.ignore()
                    return

                if answer == QMessageBox.StandardButton.Save:

                    if not self.documents.get(widget):
                        self.save_file_as()
                    else:
                        self.save_file()

                    if widget.document().isModified():
                        event.ignore()
                        return

        if (
            self.python_runner.process.state()
            != QProcess.ProcessState.NotRunning
        ):
            self.python_runner.stop()

        if hasattr(self, "system_terminal"):
            self.system_terminal.stop()

        # Let analysis/verification threads finish before Qt objects die.
        self.workers.shutdown()

        event.accept()

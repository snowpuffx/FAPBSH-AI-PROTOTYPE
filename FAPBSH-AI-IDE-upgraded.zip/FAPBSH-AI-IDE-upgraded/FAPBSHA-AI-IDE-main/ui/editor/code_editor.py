
import difflib
import re

from PySide6.QtCore import QPointF, QRect, QRectF, QSize, Qt
from PySide6.QtGui import (
    QColor,
    QFont,
    QPainter,
    QPainterPath,
    QPen,
    QPolygonF,
    QTextCursor,
    QTextFormat,
    QSyntaxHighlighter,
    QTextCharFormat,
)
from PySide6.QtWidgets import (
    QPlainTextEdit,
    QTextEdit,
    QWidget,
)

from ui.theme import EDITOR_COLORS

# Distance of the trace badges from the right edge of the editor.
TRACE_BADGE_INSET = 18


class PythonHighlighter(QSyntaxHighlighter):

    def __init__(self, document):
        super().__init__(document)

        self.rules = []

        def add_rule(pattern, color, bold=False, italic=False):
            fmt = QTextCharFormat()
            fmt.setForeground(QColor(color))

            if bold:
                fmt.setFontWeight(QFont.Weight.Bold)

            if italic:
                fmt.setFontItalic(True)

            self.rules.append((re.compile(pattern), fmt))

        # Python keywords
        keywords = (
            "False None True and as assert async await break "
            "class continue def del elif else except finally "
            "for from global if import in is lambda nonlocal "
            "not or pass raise return try while with yield"
        ).split()

        for keyword in keywords:
            add_rule(rf"\b{keyword}\b", EDITOR_COLORS["keyword"], bold=True)

        # Built-in functions
        builtins = (
            "print len range str int float list dict set "
            "tuple bool type super open input enumerate zip "
            "map filter sorted sum min max abs round isinstance "
            "hasattr getattr setattr property"
        ).split()

        for name in builtins:
            add_rule(rf"\b{name}\b", EDITOR_COLORS["builtin"])

        # Strings
        add_rule(
            r"'([^'\\]|\\.)*'|\"([^\"\\]|\\.)*\"",
            EDITOR_COLORS["string"]
        )

        # Numbers
        add_rule(
            r"\b\d+(\.\d+)?\b",
            EDITOR_COLORS["number"]
        )

        # Function calls
        add_rule(
            r"\b[A-Za-z_]\w*(?=\s*\()",
            EDITOR_COLORS["function"]
        )

        # Comments
        add_rule(
            r"#[^\n]*",
            EDITOR_COLORS["comment"],
            italic=True
        )

        # Decorators
        add_rule(
            r"@[A-Za-z_]\w*",
            EDITOR_COLORS["decorator"],
            italic=True
        )

    def highlightBlock(self, text):
        for pattern, fmt in self.rules:
            for match in pattern.finditer(text):
                self.setFormat(
                    match.start(),
                    match.end() - match.start(),
                    fmt
                )


class LineNumberArea(QWidget):

    def __init__(self, editor):
        super().__init__(editor)
        self.editor = editor

    def sizeHint(self):
        return QSize(self.editor.line_number_width(), 0)

    def paintEvent(self, event):
        self.editor.paint_line_numbers(event)


class CodeEditor(QPlainTextEdit):

    def __init__(self, parent=None):
        super().__init__(parent)

        self.line_number_area = LineNumberArea(self)

        font = QFont("Consolas", 11)
        font.setStyleHint(QFont.StyleHint.Monospace)
        self.setFont(font)

        # Data-flow trace overlay: [(line, role)], sink range, selections
        self.trace_steps = []
        self.trace_sink = None
        self.trace_sink_positions = None
        self.trace_selections = []

        self.setTabStopDistance(
            self.fontMetrics().horizontalAdvance(" ") * 4
        )

        self.setStyleSheet(f"""
            QPlainTextEdit {{
                background-color: {EDITOR_COLORS["background"]};
                color: {EDITOR_COLORS["text"]};
                border: none;
                selection-background-color: {EDITOR_COLORS["selection"]};
                selection-color: #000000;
                padding: 5px;
            }}
        """)

        self.highlighter = PythonHighlighter(self.document())

        self.blockCountChanged.connect(
            self.update_line_number_width
        )

        self.updateRequest.connect(
            self.update_line_number_area
        )

        self.cursorPositionChanged.connect(
            self.highlight_current_line
        )

        self.update_line_number_width(0)
        self.highlight_current_line()

    # -----------------------------
    # LINE NUMBERS
    # -----------------------------

    def line_number_width(self):
        digits = max(
            2,
            len(str(max(1, self.blockCount())))
        )

        return 12 + self.fontMetrics().horizontalAdvance("9") * digits

    def update_line_number_width(self, _):
        self.setViewportMargins(
            self.line_number_width(), 0, 0, 0
        )

    def update_line_number_area(self, rect, dy):
        if dy:
            self.line_number_area.scroll(0, dy)
        else:
            self.line_number_area.update(
                0,
                rect.y(),
                self.line_number_area.width(),
                rect.height()
            )

        if rect.contains(self.viewport().rect()):
            self.update_line_number_width(0)

    def resizeEvent(self, event):
        super().resizeEvent(event)

        rect = self.contentsRect()

        self.line_number_area.setGeometry(
            QRect(
                rect.left(),
                rect.top(),
                self.line_number_width(),
                rect.height()
            )
        )

    def paint_line_numbers(self, event):
        painter = QPainter(self.line_number_area)

        painter.fillRect(
            event.rect(),
            QColor(EDITOR_COLORS["gutter"])
        )

        block = self.firstVisibleBlock()
        block_number = block.blockNumber()

        top = int(
            self.blockBoundingGeometry(block)
            .translated(self.contentOffset())
            .top()
        )

        bottom = top + int(
            self.blockBoundingRect(block).height()
        )

        while block.isValid() and top <= event.rect().bottom():

            if block.isVisible() and bottom >= event.rect().top():
                number = str(block_number + 1)

                painter.setPen(QColor(EDITOR_COLORS["line_number"]))

                painter.drawText(
                    0,
                    top,
                    self.line_number_area.width() - 8,
                    self.fontMetrics().height(),
                    Qt.AlignmentFlag.AlignRight,
                    number
                )

            block = block.next()
            top = bottom

            if block.isValid():
                bottom = top + int(
                    self.blockBoundingRect(block).height()
                )

            block_number += 1

    # -----------------------------
    # CURRENT LINE HIGHLIGHT
    # -----------------------------

    def highlight_current_line(self):
        extra_selections = []

        if not self.isReadOnly():
            selection = QTextEdit.ExtraSelection()

            selection.format.setBackground(
                QColor(EDITOR_COLORS["current_line"])
            )

            selection.format.setProperty(
                QTextFormat.Property.FullWidthSelection,
                True
            )

            selection.cursor = self.textCursor()
            selection.cursor.clearSelection()

            extra_selections.append(selection)

        # Trace highlights are drawn on top of the current line.
        extra_selections.extend(self.trace_selections)

        self.setExtraSelections(extra_selections)

    # -----------------------------
    # DATA-FLOW TRACE OVERLAY
    # -----------------------------

    def set_trace(self, steps, sink=None):
        """Show a data-flow trace.

        steps: ordered [(line, role)] with 1-based lines.
        sink:  (line, start_col, end_line, end_col), 0-based columns, for
               the wavy underline.
        """
        self.trace_steps = list(steps)
        self.trace_sink = sink
        self.trace_sink_positions = None
        self.trace_selections = []

        line_format_color = QColor(EDITOR_COLORS["trace_line"])
        for line in sorted({line for line, _ in self.trace_steps}):
            block = self.document().findBlockByNumber(line - 1)
            if not block.isValid():
                continue
            selection = QTextEdit.ExtraSelection()
            selection.format.setBackground(line_format_color)
            selection.format.setProperty(
                QTextFormat.Property.FullWidthSelection, True
            )
            selection.cursor = QTextCursor(block)
            self.trace_selections.append(selection)

        if sink is not None:
            line, start_col, end_line, end_col = sink
            block = self.document().findBlockByNumber(line - 1)
            if block.isValid():
                text = block.text()
                if end_line != line or end_col <= start_col:
                    end_col = len(text.rstrip())
                start_col = max(0, min(start_col, len(text)))
                end_col = max(start_col + 1, min(end_col, len(text)))
                cursor = QTextCursor(block)
                cursor.setPosition(block.position() + start_col)
                cursor.setPosition(
                    block.position() + end_col,
                    QTextCursor.MoveMode.KeepAnchor,
                )
                # Character range of the sink; the wavy underline itself is
                # painted in paintEvent so it stays bold and readable.
                self.trace_sink_positions = (
                    block.position() + start_col,
                    block.position() + end_col,
                )

        self.highlight_current_line()
        self.viewport().update()

    def clear_trace(self):
        if not self.trace_steps and not self.trace_selections:
            return
        self.trace_steps = []
        self.trace_sink = None
        self.trace_sink_positions = None
        self.trace_selections = []
        self.highlight_current_line()
        self.viewport().update()

    def go_to_line(self, line, column=1):
        block = self.document().findBlockByNumber(max(0, line - 1))
        if not block.isValid():
            return
        cursor = QTextCursor(block)
        cursor.setPosition(
            block.position() + max(0, min(column - 1, len(block.text())))
        )
        self.setTextCursor(cursor)
        self.centerCursor()
        self.setFocus()

    def paintEvent(self, event):
        super().paintEvent(event)

        if not self.trace_steps:
            return

        painter = QPainter(self.viewport())
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        radius = 8
        x_base = self.viewport().width() - TRACE_BADGE_INSET
        offset = self.contentOffset()

        # Badge centres, numbered in trace order. Several steps on one
        # line are placed side by side.
        centres = []
        per_line = {}
        for number, (line, _role) in enumerate(self.trace_steps, start=1):
            block = self.document().findBlockByNumber(line - 1)
            if not block.isValid():
                centres.append(None)
                continue
            geometry = self.blockBoundingGeometry(block).translated(offset)
            slot = per_line.get(line, 0)
            per_line[line] = slot + 1
            centre = QPointF(
                x_base - slot * (2 * radius + 3),
                geometry.top() + geometry.height() / 2,
            )
            centres.append((number, centre))

        # Arrows between consecutive steps (drawn first, under badges).
        # A straight vertical arrow is used when nothing sits between the
        # two badges; otherwise a curved connector runs to the left so the
        # arrows never hide each other.
        pen = QPen(QColor(EDITOR_COLORS["arrow"]))
        pen.setWidthF(1.6)
        painter.setPen(pen)
        step_lines = [line for line, _ in self.trace_steps]
        for index, (current, following) in enumerate(zip(centres, centres[1:])):
            if current is None or following is None:
                continue
            start = current[1]
            end = following[1]
            if start == end:
                continue
            direction = 1 if end.y() >= start.y() else -1
            line_a, line_b = step_lines[index], step_lines[index + 1]
            low, high = sorted((line_a, line_b))
            blocked = any(low < l < high for l in step_lines)
            straight = (
                not blocked
                and abs(end.x() - start.x()) < 1
                and abs(end.y() - start.y()) >= 2 * radius + 12
            )
            painter.setBrush(Qt.BrushStyle.NoBrush)
            if straight:
                x = start.x()
                y1 = start.y() + direction * (radius + 3)
                y2 = end.y() - direction * (radius + 3)
                painter.drawLine(QPointF(x, y1), QPointF(x, y2))
                tip = QPointF(x, y2)
                head = QPolygonF([
                    tip,
                    QPointF(x - 4.5, y2 - direction * 8),
                    QPointF(x + 4.5, y2 - direction * 8),
                ])
            else:
                lane = radius + 8 + 7 * (index % 3)
                p1 = QPointF(start.x() - radius - 1, start.y())
                p2 = QPointF(end.x() - radius - 3, end.y())
                path = QPainterPath(p1)
                path.cubicTo(
                    QPointF(p1.x() - lane, p1.y()),
                    QPointF(p2.x() - lane, p2.y()),
                    p2,
                )
                painter.drawPath(path)
                head = QPolygonF([
                    QPointF(p2.x() + 2, p2.y()),
                    QPointF(p2.x() - 6, p2.y() - 4),
                    QPointF(p2.x() - 6, p2.y() + 4),
                ])
            painter.setBrush(QColor(EDITOR_COLORS["arrow"]))
            painter.drawPolygon(head)

        # Wavy underline under the sink expression.
        if self.trace_sink_positions is not None:
            start_pos, end_pos = self.trace_sink_positions
            cursor = QTextCursor(self.document())
            cursor.setPosition(start_pos)
            left = self.cursorRect(cursor)
            cursor.setPosition(end_pos)
            right = self.cursorRect(cursor)
            if left.top() == right.top():
                y = left.bottom() - 1
                amplitude, period = 2.2, 6.0
                wave = QPainterPath(QPointF(left.left(), y))
                x = left.left()
                up = True
                while x < right.left():
                    nx = min(x + period / 2, right.left())
                    wave.quadTo(
                        QPointF((x + nx) / 2, y + (-amplitude if up else amplitude)),
                        QPointF(nx, y),
                    )
                    x = nx
                    up = not up
                wave_pen = QPen(QColor(EDITOR_COLORS["wave"]))
                wave_pen.setWidthF(1.4)
                painter.setPen(wave_pen)
                painter.setBrush(Qt.BrushStyle.NoBrush)
                painter.drawPath(wave)

        font = QFont(self.font())
        font.setPointSizeF(max(7.0, font.pointSizeF() - 3))
        font.setBold(True)
        painter.setFont(font)
        for item in centres:
            if item is None:
                continue
            number, centre = item
            painter.setPen(QPen(QColor("#ffffff"), 1.5))
            painter.setBrush(QColor(EDITOR_COLORS["badge"]))
            painter.drawEllipse(centre, radius, radius)
            painter.setPen(QColor(EDITOR_COLORS["badge_text"]))
            painter.drawText(
                QRectF(centre.x() - radius, centre.y() - radius,
                       2 * radius, 2 * radius),
                Qt.AlignmentFlag.AlignCenter,
                str(number),
            )

        painter.end()

    # -----------------------------
    # SINGLE-UNDO REPLACEMENT
    # -----------------------------

    def apply_text(self, new_text):
        """Replace the buffer with new_text as ONE undoable edit.

        Only the changed line ranges are rewritten so the cursor and
        scroll position stay where they were.
        """
        old_text = self.toPlainText()
        if old_text == new_text:
            return False

        old_lines = old_text.splitlines(keepends=True)
        new_lines = new_text.splitlines(keepends=True)

        starts = [0]
        for line in old_lines:
            starts.append(starts[-1] + len(line))

        def qt_pos(index):
            # Qt counts UTF-16 code units
            return len(old_text[:index].encode("utf-16-le")) // 2

        matcher = difflib.SequenceMatcher(
            None, old_lines, new_lines, autojunk=False
        )
        opcodes = [
            op for op in matcher.get_opcodes() if op[0] != "equal"
        ]

        cursor = QTextCursor(self.document())
        cursor.beginEditBlock()
        for _tag, i1, i2, j1, j2 in reversed(opcodes):
            cursor.setPosition(qt_pos(starts[i1]))
            cursor.setPosition(
                qt_pos(starts[i2]), QTextCursor.MoveMode.KeepAnchor
            )
            cursor.insertText("".join(new_lines[j1:j2]))
        cursor.endEditBlock()
        return True

    # -----------------------------
    # AUTOMATIC INDENTATION
    # -----------------------------

    def keyPressEvent(self, event):

        if event.key() in (
            Qt.Key.Key_Return,
            Qt.Key.Key_Enter
        ):
            cursor = self.textCursor()
            current_line = cursor.block().text()

            match = re.match(r"^\s*", current_line)
            indentation = match.group() if match else ""

            extra = ""

            if current_line.rstrip().endswith(":"):
                extra = "    "

            super().keyPressEvent(event)

            self.insertPlainText(indentation + extra)
            return

        # Insert four spaces when Tab is pressed
        if event.key() == Qt.Key.Key_Tab:

            if self.textCursor().hasSelection():
                super().keyPressEvent(event)
            else:
                self.insertPlainText("    ")

            return

        super().keyPressEvent(event)

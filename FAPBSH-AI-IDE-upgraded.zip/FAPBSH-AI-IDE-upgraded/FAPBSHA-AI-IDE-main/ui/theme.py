
DARK_THEME = """
QWidget {
    background-color: #1e1e1e;
    color: #cccccc;
    font-family: 'Segoe UI';
    font-size: 10pt;
}

QMainWindow {
    background-color: #1e1e1e;
}

QMenuBar {
    background-color: #252526;
    color: #cccccc;
    padding: 5px;
}

QMenuBar::item:selected {
    background-color: #37373d;
}

QMenu {
    background-color: #252526;
    color: #cccccc;
    border: 1px solid #454545;
}

QMenu::item:selected {
    background-color: #094771;
}

QPushButton {
    background-color: transparent;
    color: #cccccc;
    border: none;
    padding: 8px;
}

QPushButton:hover {
    background-color: #37373d;
}

QPushButton:checked {
    background-color: #37373d;
    border-left: 2px solid #007acc;
}

QLabel {
    color: #cccccc;
}

QTreeView {
    background-color: #252526;
    border: none;
    outline: none;
}

QTreeView::item {
    padding: 4px;
}

QTreeView::item:selected {
    background-color: #094771;
}

QTabWidget::pane {
    border: none;
    background-color: #1e1e1e;
}

QTabBar::tab {
    background-color: #252526;
    color: #999999;
    padding: 8px 16px;
    border: none;
}

QTabBar::tab:selected {
    background-color: #1e1e1e;
    color: white;
    border-top: 2px solid #007acc;
}

QTabBar::close-button {
    image: none;
}

QLineEdit {
    background-color: #3c3c3c;
    color: #ffffff;
    border: 1px solid #555555;
    padding: 7px;
    selection-background-color: #264f78;
}

QStatusBar {
    background-color: #007acc;
    color: white;
}

QStatusBar QLabel {
    color: white;
    padding: 2px 8px;
}

QSplitter::handle {
    background-color: #333333;
}

QToolTip {
    background-color: #252526;
    color: white;
    border: 1px solid #454545;
}
"""


# =====================================================================
# Light grayscale theme (matches the FAPBSH AI wireframes)
# =====================================================================

GRAY = {
    "window": "#f0f0f0",
    "panel": "#ececec",
    "surface": "#ffffff",
    "border": "#9a9a9a",
    "border_light": "#c8c8c8",
    "text": "#1a1a1a",
    "muted": "#5c5c5c",
    "faint": "#8a8a8a",
    "menubar": "#e0e0e0",
    "activity": "#8c8c8c",
    "dark": "#3a3a3a",
    "darker": "#262626",
    "status": "#5a5a5a",
    "highlight": "#d6d6d6",
    "selection": "#c4c4c4",
}

# Colours used by the code editor and its trace overlay.
EDITOR_COLORS = {
    "background": "#ffffff",
    "text": "#1a1a1a",
    "selection": "#c8c8c8",
    "gutter": "#ffffff",
    "line_number": "#8a8a8a",
    "current_line": "#f2f2f2",
    "trace_line": "#dcdcdc",
    "badge": "#2b2b2b",
    "badge_text": "#ffffff",
    "arrow": "#2b2b2b",
    "wave": "#111111",
    # Syntax highlighting in grayscale: weight and style carry meaning.
    "keyword": "#000000",
    "builtin": "#333333",
    "string": "#6b6b6b",
    "number": "#444444",
    "function": "#1f1f1f",
    "comment": "#9a9a9a",
    "decorator": "#555555",
}

GRAYSCALE_THEME = f"""
QWidget {{
    background-color: {GRAY['window']};
    color: {GRAY['text']};
    font-family: 'Segoe UI', 'DejaVu Sans', sans-serif;
    font-size: 10pt;
}}

QMainWindow {{
    background-color: {GRAY['window']};
}}

QMenuBar {{
    background-color: {GRAY['menubar']};
    color: {GRAY['text']};
    padding: 4px;
    font-size: 11pt;
}}

QMenuBar::item {{
    padding: 4px 14px;
    background: transparent;
}}

QMenuBar::item:selected {{
    background-color: {GRAY['selection']};
}}

QMenu {{
    background-color: {GRAY['surface']};
    color: {GRAY['text']};
    border: 1px solid {GRAY['border']};
}}

QMenu::item:selected {{
    background-color: {GRAY['highlight']};
    color: {GRAY['text']};
}}

QMenu::item:disabled {{
    color: {GRAY['faint']};
}}

QPushButton {{
    background-color: transparent;
    color: {GRAY['text']};
    border: none;
    padding: 8px;
}}

QPushButton:hover {{
    background-color: {GRAY['highlight']};
}}

QPushButton:checked {{
    background-color: {GRAY['highlight']};
    border-left: 3px solid {GRAY['darker']};
}}

QPushButton#primaryButton {{
    background-color: {GRAY['dark']};
    color: #ffffff;
    font-weight: bold;
    font-size: 11pt;
    border: 1px solid {GRAY['darker']};
    padding: 5px 26px;
}}

QPushButton#primaryButton:hover {{
    background-color: {GRAY['darker']};
}}

QPushButton#primaryButton:disabled {{
    background-color: {GRAY['faint']};
}}

QPushButton#secondaryButton {{
    background-color: {GRAY['activity']};
    color: #ffffff;
    font-weight: bold;
    font-size: 11pt;
    border: 1px solid #7a7a7a;
    padding: 5px 26px;
}}

QPushButton#secondaryButton:hover {{
    background-color: #7a7a7a;
}}

QPushButton#secondaryButton:disabled {{
    background-color: #b8b8b8;
}}

QPushButton#outlineButton {{
    background-color: {GRAY['surface']};
    color: {GRAY['text']};
    font-weight: bold;
    font-size: 11pt;
    border: 2px solid {GRAY['dark']};
    padding: 6px 24px;
}}

QPushButton#outlineButton:hover {{
    background-color: {GRAY['highlight']};
}}

QPushButton#outlineButton:disabled, QPushButton#primaryButton:disabled {{
    color: #eeeeee;
    border-color: {GRAY['border_light']};
}}

QLabel {{
    color: {GRAY['text']};
    background: transparent;
}}

QTreeView, QListWidget, QTreeWidget {{
    background-color: {GRAY['window']};
    border: none;
    outline: none;
}}

QTreeView::item {{
    padding: 4px;
}}

QTreeView::item:selected, QTreeWidget::item:selected {{
    background-color: {GRAY['highlight']};
    color: {GRAY['text']};
}}

QHeaderView::section {{
    background-color: {GRAY['menubar']};
    color: {GRAY['muted']};
    border: none;
    border-bottom: 1px solid {GRAY['border_light']};
    padding: 4px 6px;
}}

QTabWidget::pane {{
    border: 1px solid {GRAY['border']};
    background-color: {GRAY['window']};
}}

QTabBar::tab {{
    background-color: {GRAY['menubar']};
    color: {GRAY['text']};
    padding: 7px 18px;
    border: 1px solid {GRAY['border']};
    border-bottom: none;
    margin-right: -1px;
}}

QTabBar::tab:selected {{
    background-color: {GRAY['surface']};
    color: #000000;
    font-weight: bold;
}}

QTabBar::tab:!selected:hover {{
    background-color: {GRAY['highlight']};
}}

QTabBar::close-button {{
    image: none;
}}

QLineEdit, QComboBox {{
    background-color: {GRAY['surface']};
    color: {GRAY['text']};
    border: 1px solid {GRAY['border']};
    padding: 6px;
    selection-background-color: {GRAY['selection']};
}}

QTextEdit, QTextBrowser, QPlainTextEdit {{
    background-color: {GRAY['surface']};
    color: {GRAY['text']};
    selection-background-color: {GRAY['selection']};
    selection-color: #000000;
}}

QStatusBar {{
    background-color: {GRAY['status']};
    color: #ffffff;
}}

QStatusBar QLabel {{
    color: #ffffff;
    padding: 2px 10px;
    font-size: 10.5pt;
}}

QStatusBar::item {{
    border: none;
}}

QSplitter::handle {{
    background-color: {GRAY['border']};
}}

QSplitter::handle:horizontal {{
    width: 1px;
}}

QSplitter::handle:vertical {{
    height: 1px;
}}

QScrollArea {{
    border: none;
}}

QScrollBar:vertical {{
    background: {GRAY['window']};
    width: 12px;
}}

QScrollBar::handle:vertical {{
    background: {GRAY['border_light']};
    min-height: 24px;
}}

QToolTip {{
    background-color: {GRAY['surface']};
    color: {GRAY['text']};
    border: 1px solid {GRAY['border']};
}}
"""

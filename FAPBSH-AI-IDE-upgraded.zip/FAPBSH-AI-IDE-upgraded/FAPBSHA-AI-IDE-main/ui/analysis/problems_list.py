"""Problems tab: one row per finding; activating a row jumps to it."""

from pathlib import Path

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QAbstractItemView,
    QHeaderView,
    QTreeWidget,
    QTreeWidgetItem,
)


class ProblemsList(QTreeWidget):

    finding_activated = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setColumnCount(5)
        self.setHeaderLabels(["Severity", "Problem", "CWE", "File", "Line"])
        self.setRootIsDecorated(False)
        self.setUniformRowHeights(True)
        self.setAlternatingRowColors(False)
        self.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        header = self.header()
        header.setStretchLastSection(False)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        for column, width in ((0, 100), (2, 80), (3, 140), (4, 50)):
            header.setSectionResizeMode(column, QHeaderView.ResizeMode.Interactive)
            self.setColumnWidth(column, width)
        self.itemClicked.connect(self._activate)
        self.itemActivated.connect(self._activate)
        self.set_message("No problems to display. Click Analyze to scan the current file.")

    def set_message(self, text):
        self.clear()
        item = QTreeWidgetItem(["", text, "", "", ""])
        item.setFlags(Qt.ItemFlag.NoItemFlags)
        self.addTopLevelItem(item)

    def set_findings(self, findings):
        self.clear()
        if not findings:
            self.set_message("No problems found in the analyzed file.")
            return
        for finding in findings:
            item = QTreeWidgetItem([
                "● " + finding.severity,
                finding.message,
                finding.cwe,
                Path(finding.file).name,
                str(finding.line),
            ])
            item.setData(0, Qt.ItemDataRole.UserRole, finding.id)
            item.setToolTip(1, finding.snippet)
            self.addTopLevelItem(item)

    def select_finding(self, finding_id):
        for index in range(self.topLevelItemCount()):
            item = self.topLevelItem(index)
            if item.data(0, Qt.ItemDataRole.UserRole) == finding_id:
                self.blockSignals(True)
                self.setCurrentItem(item)
                self.blockSignals(False)
                return

    def _activate(self, item, _column=0):
        finding_id = item.data(0, Qt.ItemDataRole.UserRole)
        if finding_id:
            self.finding_activated.emit(finding_id)

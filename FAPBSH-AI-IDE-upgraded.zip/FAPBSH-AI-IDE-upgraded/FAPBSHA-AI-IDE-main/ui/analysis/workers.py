"""Background workers so analysis and verification never block the UI."""

from PySide6.QtCore import QObject, QThread, Signal, Slot

from fapbsh.analysis import analyze_source
from fapbsh.verification import Verifier


class AnalysisWorker(QObject):

    finished = Signal(object, int)  # AnalysisResult, request token
    failed = Signal(str, int)

    def __init__(self, code, filename, token):
        super().__init__()
        self.code = code
        self.filename = filename
        self.token = token

    @Slot()
    def run(self):
        try:
            result = analyze_source(self.code, self.filename)
        except Exception as error:  # noqa: BLE001 - shown in the UI
            self.failed.emit(f"{type(error).__name__}: {error}", self.token)
            return
        self.finished.emit(result, self.token)


class VerificationWorker(QObject):

    progress = Signal(str, int, object)  # finding id, check index, CheckResult
    finished = Signal(str, object)  # finding id, VerificationReport
    failed = Signal(str, str)

    def __init__(self, original, corrected, finding, project_dir):
        super().__init__()
        self.original = original
        self.corrected = corrected
        self.finding = finding
        self.project_dir = project_dir

    @Slot()
    def run(self):
        try:
            report = Verifier(self.project_dir).run(
                self.original,
                self.corrected,
                self.finding,
                progress=self._progress,
            )
        except Exception as error:  # noqa: BLE001 - shown in the UI
            self.failed.emit(self.finding.id, f"{type(error).__name__}: {error}")
            return
        self.finished.emit(self.finding.id, report)

    def _progress(self, index, result):
        self.progress.emit(self.finding.id, index, result)


class WorkerPool(QObject):
    """Keeps QThreads alive until they finish and stops them on exit."""

    def __init__(self, parent):
        super().__init__(parent)
        self.running = []

    def start(self, worker):
        thread = QThread(self.parent())
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.finished.connect(thread.quit)
        worker.failed.connect(thread.quit)
        thread.finished.connect(worker.deleteLater)
        thread.finished.connect(self._on_thread_finished)
        self.running.append((thread, worker))
        thread.start()
        return thread

    @Slot()
    def _on_thread_finished(self):
        thread = self.sender()
        self.running = [(t, w) for t, w in self.running if t is not thread]
        if thread is not None:
            thread.deleteLater()

    def busy(self):
        return bool(self.running)

    def shutdown(self, timeout_ms=20000):
        for thread, _worker in list(self.running):
            thread.quit()
            thread.wait(timeout_ms)

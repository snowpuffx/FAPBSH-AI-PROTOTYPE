"""Recommendation tab: side-by-side original / corrected code."""

from PySide6.QtCore import QPointF, Qt, Signal
from PySide6.QtGui import QColor, QFont, QPainter, QTextCursor, QTextFormat
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QPlainTextEdit,
    QPushButton,
    QTextEdit,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

CHANGED_LINE = "#cfcfcf"


class DiffPane(QPlainTextEdit):
    """Read-only code view that highlights changed lines and paints a
    '−' or '+' marker at the right end of each one."""

    def __init__(self, marker, parent=None):
        super().__init__(parent)
        self.marker = marker
        self.marked = set()
        self.setReadOnly(True)
        self.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
        font = QFont("Consolas", 9)
        font.setStyleHint(QFont.StyleHint.Monospace)
        self.setFont(font)
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.setStyleSheet(
            "QPlainTextEdit { background: #ffffff; color: #1a1a1a; border: none; }"
        )

    def set_content(self, text, marked_lines):
        self.marked = set(marked_lines)
        self.setPlainText(text)
        selections = []
        for line in sorted(self.marked):
            block = self.document().findBlockByNumber(line - 1)
            if not block.isValid():
                continue
            selection = QTextEdit.ExtraSelection()
            selection.format.setBackground(QColor(CHANGED_LINE))
            selection.format.setProperty(QTextFormat.Property.FullWidthSelection, True)
            selection.cursor = QTextCursor(block)
            selections.append(selection)
        self.setExtraSelections(selections)

    def scroll_to_line(self, line):
        block = self.document().findBlockByNumber(max(0, line - 1))
        if block.isValid():
            self.setTextCursor(QTextCursor(block))
            self.centerCursor()

    def paintEvent(self, event):
        super().paintEvent(event)
        if not self.marked:
            return
        painter = QPainter(self.viewport())
        font = QFont(self.font())
        font.setPointSize(13)
        font.setBold(True)
        painter.setFont(font)
        painter.setPen(QColor("#111111"))
        offset = self.contentOffset()
        x = self.viewport().width() - 16
        for line in self.marked:
            block = self.document().findBlockByNumber(line - 1)
            if not block.isValid():
                continue
            geo = self.blockBoundingGeometry(block).translated(offset)
            if geo.bottom() < 0 or geo.top() > self.viewport().height():
                continue
            painter.drawText(
                QPointF(x, geo.top() + geo.height() * 0.82), self.marker
            )
        painter.end()


class CodeBox(QFrame):

    def __init__(self, title, marker, parent=None):
        super().__init__(parent)
        self.setObjectName("codeBox")
        self.setStyleSheet(
            "QFrame#codeBox { background: #ffffff; border: 2px solid #8a8a8a; }"
        )
        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 8, 4, 4)
        layout.setSpacing(4)
        label = QLabel(title)
        label.setStyleSheet("font-weight: bold; font-size: 11pt; padding-left: 4px;")
        layout.addWidget(label)
        self.pane = DiffPane(marker)
        layout.addWidget(self.pane, 1)


class RecommendationTab(QWidget):

    apply_clicked = Signal()
    copy_clicked = Signal()
    ignore_clicked = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.recommendation = None

        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(10)

        self.heading = QLabel("Select a finding to see a recommended fix.")
        self.heading.setWordWrap(True)
        self.heading.setStyleSheet("font-weight: bold;")
        layout.addWidget(self.heading)

        panes = QHBoxLayout()
        panes.setSpacing(12)
        self.original_box = CodeBox("Original code", "−")
        self.corrected_box = CodeBox("Corrected code", "+")
        panes.addWidget(self.original_box)
        panes.addWidget(self.corrected_box)
        layout.addLayout(panes, 1)

        buttons = QHBoxLayout()
        buttons.setSpacing(12)
        self.apply_button = QPushButton("Apply")
        self.apply_button.setObjectName("primaryButton")
        self.copy_button = QPushButton("Copy")
        self.copy_button.setObjectName("outlineButton")
        self.ignore_button = QPushButton("Ignore")
        self.ignore_button.setObjectName("outlineButton")
        for button in (self.apply_button, self.copy_button, self.ignore_button):
            button.setMinimumHeight(38)
            button.setMinimumWidth(100)
            buttons.addWidget(button)
        buttons.addStretch()
        layout.addLayout(buttons)

        self.apply_button.setToolTip("Write the corrected code into the editor (one undoable edit)")
        self.copy_button.setToolTip("Copy the corrected code to the clipboard")
        self.ignore_button.setToolTip("Dismiss this finding for the current session")
        self.apply_button.clicked.connect(self.apply_clicked)
        self.copy_button.clicked.connect(self.copy_clicked)
        self.ignore_button.clicked.connect(self.ignore_clicked)

        self.note = QLabel("")
        self.note.setWordWrap(True)
        self.note.setStyleSheet("color: #4a4a4a;")
        layout.addWidget(self.note)

        self.diff_toggle = QToolButton()
        self.diff_toggle.setText("Show unified diff")
        self.diff_toggle.setCheckable(True)
        self.diff_toggle.setStyleSheet(
            "QToolButton { border: none; color: #333333; text-decoration: underline; }"
        )
        self.diff_toggle.toggled.connect(self._toggle_diff)
        layout.addWidget(self.diff_toggle, 0, Qt.AlignmentFlag.AlignLeft)

        self.diff_view = QPlainTextEdit()
        self.diff_view.setReadOnly(True)
        self.diff_view.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
        mono = QFont("Consolas", 9)
        mono.setStyleHint(QFont.StyleHint.Monospace)
        self.diff_view.setFont(mono)
        self.diff_view.setMaximumHeight(160)
        self.diff_view.setVisible(False)
        layout.addWidget(self.diff_view)

        self.clear()

    def _toggle_diff(self, checked):
        self.diff_view.setVisible(checked)
        self.diff_toggle.setText("Hide unified diff" if checked else "Show unified diff")

    def clear(self, message="Select a finding to see a recommended fix."):
        self.recommendation = None
        self.heading.setText(message)
        self.original_box.pane.set_content("", [])
        self.corrected_box.pane.set_content("", [])
        self.note.setText("")
        self.diff_view.setPlainText("")
        for button in (self.apply_button, self.copy_button, self.ignore_button):
            button.setEnabled(False)

    def set_recommendation(self, recommendation, finding):
        self.recommendation = recommendation
        self.heading.setText(
            f"{finding.cwe} · line {finding.line}: {recommendation.title}"
        )
        self.original_box.pane.set_content(
            recommendation.original, recommendation.removed_lines
        )
        self.corrected_box.pane.set_content(
            recommendation.corrected, recommendation.added_lines
        )
        # Focus the change closest to the finding, not an added import.
        if recommendation.removed_lines:
            target = min(recommendation.removed_lines, key=lambda l: abs(l - finding.line))
        else:
            target = finding.line
        self.original_box.pane.scroll_to_line(target)
        if recommendation.added_lines:
            near = min(recommendation.added_lines, key=lambda l: abs(l - target))
        else:
            near = target
        self.corrected_box.pane.scroll_to_line(near)
        self.note.setText(recommendation.note)
        self.diff_view.setPlainText(recommendation.diff or "(no diff)")
        self.apply_button.setEnabled(recommendation.applicable)
        self.copy_button.setEnabled(recommendation.applicable)
        self.ignore_button.setEnabled(True)

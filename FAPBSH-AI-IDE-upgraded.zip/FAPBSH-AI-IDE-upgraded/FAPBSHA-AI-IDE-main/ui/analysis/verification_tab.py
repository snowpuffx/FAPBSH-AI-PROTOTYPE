"""Verification tab: five check rows, verdict box and notes."""

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from fapbsh.verification.checks import CHECK_NAMES
from ui.analysis.widgets import StatusIcon

BADGE_STYLE = {
    "Passed": "background: #e0e0e0; color: #111111; border: 2px solid #8a8a8a;",
    "Failed": "background: #2b2b2b; color: #ffffff; border: 2px solid #111111;",
    "Unavailable": "background: #ffffff; color: #555555; border: 2px dashed #8a8a8a;",
    "Running": "background: #f4f4f4; color: #333333; border: 2px solid #b0b0b0;",
    "Pending": "background: #f4f4f4; color: #8a8a8a; border: 2px solid #d0d0d0;",
}


class CheckRow(QFrame):

    def __init__(self, title, parent=None):
        super().__init__(parent)
        self.setObjectName("checkRow")
        self.setStyleSheet(
            "QFrame#checkRow { background: #ffffff; border: 2px solid #8a8a8a; }"
        )
        layout = QHBoxLayout(self)
        layout.setContentsMargins(14, 10, 14, 10)
        layout.setSpacing(14)

        self.icon = StatusIcon()
        layout.addWidget(self.icon, 0, Qt.AlignmentFlag.AlignVCenter)

        text = QVBoxLayout()
        text.setSpacing(2)
        self.title = QLabel(title)
        self.title.setStyleSheet("font-size: 11pt;")
        self.detail = QLabel("Not run yet.")
        self.detail.setWordWrap(True)
        self.detail.setStyleSheet("color: #555555; font-size: 9pt;")
        text.addWidget(self.title)
        text.addWidget(self.detail)
        layout.addLayout(text, 1)

        self.badge = QLabel()
        self.badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.badge.setFixedWidth(118)
        self.badge.setMinimumHeight(28)
        layout.addWidget(self.badge, 0, Qt.AlignmentFlag.AlignVCenter)
        self.set_status("Pending", "Not run yet.")

    def set_status(self, status, detail):
        self.icon.set_status(status)
        self.badge.setText("Not run" if status == "Pending" else status)
        self.badge.setStyleSheet(BADGE_STYLE.get(status, BADGE_STYLE["Pending"]) + " font-size: 10pt;")
        self.detail.setText(detail or "")
        self.detail.setToolTip(detail or "")


class VerificationTab(QWidget):

    run_clicked = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        outer.addWidget(scroll)
        body = QWidget()
        scroll.setWidget(body)

        layout = QVBoxLayout(body)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(10)

        header = QHBoxLayout()
        self.subject = QLabel("Select a finding, then open this tab to verify its fix.")
        self.subject.setWordWrap(True)
        self.subject.setStyleSheet("font-weight: bold;")
        header.addWidget(self.subject, 1)
        self.run_button = QPushButton("Re-run")
        self.run_button.setObjectName("outlineButton")
        self.run_button.setToolTip("Run the five verification checks again")
        self.run_button.clicked.connect(self.run_clicked)
        header.addWidget(self.run_button)
        layout.addLayout(header)

        self.rows = []
        for name in CHECK_NAMES:
            row = CheckRow(name)
            self.rows.append(row)
            layout.addWidget(row)

        layout.addSpacing(8)
        self.verdict_box = QFrame()
        self.verdict_box.setObjectName("verdictBox")
        self.verdict_box.setStyleSheet(
            "QFrame#verdictBox { background: #e6e6e6; border: 3px solid #1a1a1a; }"
        )
        verdict_layout = QVBoxLayout(self.verdict_box)
        verdict_layout.setContentsMargins(18, 12, 18, 14)
        verdict_title = QLabel("Verdict")
        verdict_title.setStyleSheet("font-weight: bold; font-size: 11pt;")
        verdict_layout.addWidget(verdict_title)
        row = QHBoxLayout()
        self.verdict = QLabel("—")
        self.verdict.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.verdict.setMinimumWidth(170)
        self.verdict.setMinimumHeight(34)
        self.verdict.setStyleSheet(
            "background: #3a3a3a; color: #ffffff; font-weight: bold; font-size: 12pt; padding: 4px 14px;"
        )
        row.addWidget(self.verdict)
        self.reason = QLabel("")
        self.reason.setWordWrap(True)
        self.reason.setStyleSheet("color: #333333;")
        row.addWidget(self.reason, 1)
        verdict_layout.addLayout(row)
        layout.addWidget(self.verdict_box)

        self.notes = QLabel("")
        self.notes.setWordWrap(True)
        self.notes.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.notes.setStyleSheet("color: #555555; font-size: 9pt;")
        self.notes.setAlignment(Qt.AlignmentFlag.AlignTop)
        layout.addWidget(self.notes)
        layout.addStretch()

        self.reset()

    def reset(self, subject=None, can_run=False):
        if subject:
            self.subject.setText(subject)
        for row in self.rows:
            row.set_status("Pending", "Not run yet.")
        self.verdict.setText("—")
        self.reason.setText("")
        self.notes.setText(
            "Verification runs the corrected code through five independent checks. "
            "A model or classifier opinion is never counted."
        )
        self.run_button.setEnabled(can_run)

    def set_running(self, subject):
        self.subject.setText(subject)
        for row in self.rows:
            row.set_status("Pending", "Waiting…")
        self.verdict.setText("Running")
        self.reason.setText("Checks are running in the background.")
        self.run_button.setEnabled(False)

    def update_check(self, index, result):
        self.rows[index].set_status(result.status, result.detail)

    def set_report(self, report):
        for index, result in enumerate(report.checks):
            self.rows[index].set_status(result.status, result.detail)
        self.verdict.setText(report.verdict)
        self.reason.setText(report.reason)
        self.notes.setText("\n".join("• " + note for note in report.notes))
        self.run_button.setEnabled(True)

    def set_unavailable(self, subject, reason):
        self.subject.setText(subject)
        for row in self.rows:
            row.set_status("Unavailable", "No corrected code to verify.")
        self.verdict.setText("Inconclusive")
        self.reason.setText(reason)
        self.run_button.setEnabled(False)

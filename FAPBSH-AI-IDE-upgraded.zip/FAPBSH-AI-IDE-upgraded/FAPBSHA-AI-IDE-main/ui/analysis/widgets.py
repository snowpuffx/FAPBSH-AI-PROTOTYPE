"""Small painted widgets shared by the analysis panels."""

from PySide6.QtCore import QRectF, QSize, Qt
from PySide6.QtGui import QColor, QFont, QPainter, QPen
from PySide6.QtWidgets import QSizePolicy, QWidget

SEVERITY_SHADES = {
    "Critical": "#111111",
    "High": "#3a3a3a",
    "Medium": "#7d7d7d",
    "Low": "#b3b3b3",
}

STATUS_GLYPHS = {
    "Passed": "✓",
    "Failed": "✗",
    "Unavailable": "–",
    "Running": "…",
    "Pending": "",
}


class Dot(QWidget):
    """A filled circle, used as the severity dot on finding cards."""

    def __init__(self, color="#3a3a3a", diameter=22, parent=None):
        super().__init__(parent)
        self.color = QColor(color)
        self.diameter = diameter
        self.setFixedSize(diameter + 2, diameter + 2)

    def set_color(self, color):
        self.color = QColor(color)
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(self.color)
        painter.drawEllipse(QRectF(1, 1, self.diameter, self.diameter))
        painter.end()


class StatusIcon(QWidget):
    """Round status icon for a verification check row."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.status = "Pending"
        self.setFixedSize(QSize(38, 38))
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)

    def set_status(self, status):
        self.status = status
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = QRectF(2, 2, 34, 34)
        if self.status == "Pending":
            painter.setPen(QPen(QColor("#9a9a9a"), 2))
            painter.setBrush(QColor("#ffffff"))
        elif self.status == "Unavailable":
            painter.setPen(QPen(QColor("#6a6a6a"), 2))
            painter.setBrush(QColor("#d8d8d8"))
        else:
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QColor("#333333"))
        painter.drawEllipse(rect)
        glyph = STATUS_GLYPHS.get(self.status, "")
        if glyph:
            font = QFont(self.font())
            font.setPointSize(13)
            font.setBold(True)
            painter.setFont(font)
            painter.setPen(
                QColor("#333333" if self.status == "Unavailable" else "#ffffff")
            )
            painter.drawText(rect, Qt.AlignmentFlag.AlignCenter, glyph)
        painter.end()

"""Right-hand panel: Findings, Explanation, Recommendation, Verification."""

import html
from pathlib import Path

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QScrollArea,
    QTabWidget,
    QTextBrowser,
    QVBoxLayout,
    QWidget,
)

from fapbsh.explain import explain, recommend
from ui.analysis.recommendation_tab import RecommendationTab
from ui.analysis.verification_tab import VerificationTab
from ui.analysis.widgets import SEVERITY_SHADES, Dot
from ui.analysis.workers import VerificationWorker

CARD_STYLE = """
QFrame#findingCard {
    background: #ffffff;
    border: 2px solid #a0a0a0;
}
QFrame#findingCard[selected="true"] {
    background: #e8e8e8;
    border: 4px solid #1a1a1a;
}
QFrame#findingCard:hover {
    border-color: #555555;
}
"""


class FindingCard(QFrame):

    clicked = Signal(str)

    def __init__(self, finding, parent=None):
        super().__init__(parent)
        self.finding = finding
        self.setObjectName("findingCard")
        self.setProperty("selected", False)
        self.setStyleSheet(CARD_STYLE)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(6)

        top = QHBoxLayout()
        top.setSpacing(10)
        top.addWidget(Dot(SEVERITY_SHADES.get(finding.severity, "#7d7d7d")))
        title = QLabel(finding.name)
        title.setStyleSheet("font-weight: bold; font-size: 10.5pt;")
        title.setWordWrap(True)
        top.addWidget(title, 1)
        tag = QLabel(finding.cwe)
        tag.setStyleSheet(
            "background: #dcdcdc; color: #1a1a1a; border: 1px solid #8a8a8a;"
            " padding: 1px 8px; font-size: 9pt;"
        )
        top.addWidget(tag, 0, Qt.AlignmentFlag.AlignTop)
        layout.addLayout(top)

        description = QLabel(finding.message)
        description.setWordWrap(True)
        description.setStyleSheet("color: #3c3c3c;")
        layout.addWidget(description)

        meta = QLabel(
            f"{finding.severity} · line {finding.line} · "
            f"confidence {int(round(finding.confidence * 100))}%"
        )
        meta.setStyleSheet("color: #6a6a6a; font-size: 9pt;")
        layout.addWidget(meta)

        for child in self.findChildren(QWidget):
            child.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)

    def set_selected(self, selected):
        self.setProperty("selected", selected)
        self.style().unpolish(self)
        self.style().polish(self)
        self.update()

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit(self.finding.id)
        super().mousePressEvent(event)


class FindingsList(QScrollArea):

    selected = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWidgetResizable(True)
        self.cards = {}
        self.container = QWidget()
        self.layout_ = QVBoxLayout(self.container)
        self.layout_.setContentsMargins(14, 14, 14, 14)
        self.layout_.setSpacing(14)
        self.setWidget(self.container)
        self.set_findings([], "Click Analyze to scan the current file.")

    def set_findings(self, findings, empty_text="No findings in this file."):
        while self.layout_.count():
            item = self.layout_.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
        self.cards = {}
        if not findings:
            label = QLabel(empty_text)
            label.setWordWrap(True)
            label.setStyleSheet("color: #5c5c5c; padding: 8px;")
            self.layout_.addWidget(label)
        for finding in findings:
            card = FindingCard(finding)
            card.clicked.connect(self.selected)
            self.cards[finding.id] = card
            self.layout_.addWidget(card)
        self.layout_.addStretch()

    def mark_selected(self, finding_id):
        for card_id, card in self.cards.items():
            card.set_selected(card_id == finding_id)
        card = self.cards.get(finding_id)
        if card is not None:
            self.ensureWidgetVisible(card)


class AnalysisPanel(QTabWidget):

    finding_selected = Signal(object)
    apply_requested = Signal(object, object)  # finding, recommendation
    copy_requested = Signal(object)  # recommendation
    ignore_requested = Signal(object)  # finding

    FINDINGS, EXPLANATION, RECOMMENDATION, VERIFICATION = range(4)

    def __init__(self, workers, parent=None):
        super().__init__(parent)
        self.workers = workers
        self.findings = []
        self.by_id = {}
        self.code = ""
        self.project_dir = None
        self.current = None
        self.recommendations = {}
        self.reports = {}
        self.running = set()
        self.verification_subject = None  # (finding, recommendation, original)

        self.findings_list = FindingsList()
        self.findings_list.selected.connect(self.select)

        self.explanation = QTextBrowser()
        self.explanation.setOpenExternalLinks(False)
        self.explanation.setStyleSheet("QTextBrowser { border: none; padding: 10px; }")

        self.recommendation_tab = RecommendationTab()
        self.recommendation_tab.apply_clicked.connect(self._apply)
        self.recommendation_tab.copy_clicked.connect(self._copy)
        self.recommendation_tab.ignore_clicked.connect(self._ignore)

        self.verification_tab = VerificationTab()
        self.verification_tab.run_clicked.connect(self._rerun_verification)

        self.addTab(self.findings_list, "Findings")
        self.addTab(self.explanation, "Explanation")
        self.addTab(self.recommendation_tab, "Recommendation")
        self.addTab(self.verification_tab, "Verification")
        self.currentChanged.connect(self._tab_changed)
        self._show_explanation(None)

    # ------------------------------------------------------------ results

    def set_results(self, findings, code, project_dir=None, select_first=True,
                    message=None):
        self.findings = list(findings)
        self.by_id = {f.id: f for f in self.findings}
        self.code = code
        self.project_dir = project_dir
        self.recommendations = {}
        self.current = None
        keep = None
        if not select_first and self.verification_subject is not None:
            keep = self.verification_subject[0].id
        else:
            self.verification_subject = None
        self.reports = {k: v for k, v in self.reports.items() if k == keep}
        self.findings_list.set_findings(
            self.findings, message or "No findings in this file."
        )
        if self.findings and select_first:
            self.select(self.findings[0].id)
        else:
            self._show_explanation(None)
            self.recommendation_tab.clear()
            if self.verification_subject is None:
                self.verification_tab.reset(
                    "Select a finding, then open this tab to verify its fix."
                )

    def clear_results(self, message):
        self.set_results([], "", select_first=False, message=message)

    def select(self, finding_id):
        finding = self.by_id.get(finding_id)
        if finding is None:
            return
        self.current = finding
        self.findings_list.mark_selected(finding_id)
        self._show_explanation(finding)
        recommendation = self._recommendation(finding)
        if recommendation is not None:
            self.recommendation_tab.set_recommendation(recommendation, finding)
        self._show_verification_for(finding)
        self.finding_selected.emit(finding)

    def _recommendation(self, finding):
        if finding.id not in self.recommendations:
            try:
                self.recommendations[finding.id] = recommend(finding, self.code)
            except Exception as error:  # noqa: BLE001 - never crash the UI
                self.recommendation_tab.clear(f"Could not build a fix: {error}")
                return None
        return self.recommendations[finding.id]

    # -------------------------------------------------------- explanation

    def _show_explanation(self, finding):
        if finding is None:
            self.explanation.setHtml(
                "<p style='color:#5c5c5c'>Select a finding to see why it is vulnerable.</p>"
            )
            return
        exp = explain(finding, self.code)
        esc = html.escape
        trace = "".join(f"<li>{esc(t)}</li>" for t in exp.trace)
        self.explanation.setHtml(f"""
            <h3 style='margin-bottom:2px'>{esc(finding.name)} ({esc(finding.cwe)})</h3>
            <p style='color:#555'>{esc(finding.severity)} severity ·
               confidence {int(round(finding.confidence * 100))}%</p>
            <h4>Affected location</h4><p>{esc(exp.location)}</p>
            <h4>Vulnerability category</h4><p>{esc(exp.category)}</p>
            <h4>Why it is vulnerable</h4><p>{esc(exp.why)}</p>
            <h4>Security implication</h4><p>{esc(exp.implication)}</p>
            <h4>Data-flow trace</h4><ol>{trace}</ol>
            <h4>Classification</h4><p style='color:#555'>{esc(exp.classification)}</p>
        """)

    # ----------------------------------------------------- recommendation

    def _apply(self):
        if self.current is None:
            return
        rec = self.recommendations.get(self.current.id)
        if rec is not None and rec.applicable:
            self.apply_requested.emit(self.current, rec)

    def _copy(self):
        if self.current is None:
            return
        rec = self.recommendations.get(self.current.id)
        if rec is not None:
            self.copy_requested.emit(rec)

    def _ignore(self):
        if self.current is not None:
            self.ignore_requested.emit(self.current)

    # ------------------------------------------------------- verification

    def _subject_text(self, finding):
        return f"{finding.cwe} {finding.name} · {Path(finding.file).name}, line {finding.line}"

    def _show_verification_for(self, finding):
        rec = self.recommendations.get(finding.id)
        self.verification_subject = None
        if rec is None or not rec.applicable:
            self.verification_tab.set_unavailable(
                self._subject_text(finding),
                "No automatic fix was generated for this finding, so there is nothing to verify.",
            )
            return
        self.verification_subject = (finding, rec, self.code)
        if finding.id in self.reports:
            self.verification_tab.subject.setText(self._subject_text(finding))
            self.verification_tab.set_report(self.reports[finding.id])
        elif finding.id in self.running:
            self.verification_tab.set_running(self._subject_text(finding))
        else:
            self.verification_tab.reset(self._subject_text(finding), can_run=True)
            if self.currentIndex() == self.VERIFICATION:
                self._start_verification()

    def _tab_changed(self, index):
        if index == self.VERIFICATION and self.verification_subject is not None:
            finding = self.verification_subject[0]
            if finding.id not in self.reports and finding.id not in self.running:
                self._start_verification()

    def _rerun_verification(self):
        if self.verification_subject is not None:
            self.reports.pop(self.verification_subject[0].id, None)
            self._start_verification()

    def verify_applied(self, finding, rec, original):
        """Verify a fix that was just applied (keeps showing after re-analysis)."""
        self.verification_subject = (finding, rec, original)
        self.reports.pop(finding.id, None)
        self.setCurrentIndex(self.VERIFICATION)
        self._start_verification()

    def _start_verification(self):
        finding, rec, original = self.verification_subject
        if finding.id in self.running:
            return
        self.running.add(finding.id)
        self.verification_tab.set_running(self._subject_text(finding))
        worker = VerificationWorker(original, rec.corrected, finding, self.project_dir)
        worker.progress.connect(self._on_progress)
        worker.finished.connect(self._on_verified)
        worker.failed.connect(self._on_verify_failed)
        self.workers.start(worker)

    def _is_shown(self, finding_id):
        return (
            self.verification_subject is not None
            and self.verification_subject[0].id == finding_id
        )

    def _on_progress(self, finding_id, index, result):
        if self._is_shown(finding_id):
            self.verification_tab.update_check(index, result)

    def _on_verified(self, finding_id, report):
        self.running.discard(finding_id)
        self.reports[finding_id] = report
        if self._is_shown(finding_id):
            self.verification_tab.set_report(report)

    def _on_verify_failed(self, finding_id, message):
        self.running.discard(finding_id)
        if self._is_shown(finding_id):
            self.verification_tab.verdict.setText("Inconclusive")
            self.verification_tab.reason.setText(f"Verification crashed: {message}")
            self.verification_tab.run_button.setEnabled(True)

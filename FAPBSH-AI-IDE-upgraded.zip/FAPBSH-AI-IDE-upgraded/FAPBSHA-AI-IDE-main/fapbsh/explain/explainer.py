"""Structured, deterministic explanations for findings."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

IMPLICATIONS = {
    "CWE-78": (
        "An attacker can append shell syntax such as '; rm -rf ~' or '$(id)' "
        "and run arbitrary operating-system commands with the privileges of "
        "this program."
    ),
    "CWE-89": (
        "An attacker can change the meaning of the SQL statement (for example "
        "' OR '1'='1) to read, modify or delete data they should not reach, "
        "or bypass authentication."
    ),
    "CWE-22": (
        "An attacker can use '../' sequences or absolute paths to read or "
        "overwrite files outside the intended directory, such as "
        "configuration files or credentials."
    ),
    "CWE-79": (
        "An attacker can inject HTML or JavaScript such as "
        "<script>...</script> that runs in other users' browsers, stealing "
        "sessions or performing actions on their behalf."
    ),
    "CWE-798": (
        "Anyone with access to the source code, a backup or the version "
        "history can read the credential and use it. Rotating it requires a "
        "code change and redeployment."
    ),
}

CATEGORY_TEXT = {
    "CWE-78": "Improper Neutralization of Special Elements used in an OS Command",
    "CWE-89": "Improper Neutralization of Special Elements used in an SQL Command",
    "CWE-22": "Improper Limitation of a Pathname to a Restricted Directory",
    "CWE-79": "Improper Neutralization of Input During Web Page Generation",
    "CWE-798": "Use of Hard-coded Credentials",
}

MISSING_DEFENCE = {
    "CWE-78": "No shlex.quote() is applied and the command is run through a shell, so shell metacharacters in the value are interpreted.",
    "CWE-89": "The value is concatenated into the query text instead of being passed as a bound parameter.",
    "CWE-22": "The resulting path is never canonicalised and checked to stay inside the allowed directory.",
    "CWE-79": "The value is not HTML-escaped (html.escape / markupsafe.escape) before being placed in the response.",
    "CWE-798": "The value should come from the environment or a secret store at run time.",
}


@dataclass
class Explanation:
    finding_id: str
    location: str
    category: str
    why: str
    implication: str
    trace: list = field(default_factory=list)  # list[str]
    classification: str = ""

    def as_text(self):
        parts = [
            f"Affected location: {self.location}",
            f"Vulnerability category: {self.category}",
            f"Why it is vulnerable: {self.why}",
            f"Security implication: {self.implication}",
            "Data-flow trace:",
        ]
        parts.extend(f"  {i}. {t}" for i, t in enumerate(self.trace, 1))
        if self.classification:
            parts.append(f"Classification: {self.classification}")
        return "\n".join(parts)


def explain(finding, code=None):
    lines = code.splitlines() if code else []

    def text_at(line):
        if 1 <= line <= len(lines):
            return lines[line - 1].strip()
        return ""

    location = (
        f"{Path(finding.file).name}, line {finding.line}, column {finding.column}"
        f": {finding.snippet}"
    )
    category = f"{finding.cwe} {finding.name} ({CATEGORY_TEXT.get(finding.cwe, '')})"

    trace = []
    for step in finding.trace:
        code_text = text_at(step.line)
        label = step.role.capitalize()
        detail = step.description or ""
        trace.append(
            f"{label} at line {step.line}: {detail}"
            + (f"  [{code_text}]" if code_text else "")
        )

    if finding.cwe == "CWE-798":
        why = (
            f"The variable '{finding.variable or 'literal'}' holds a credential "
            f"written directly in the source code on line {finding.line}. "
            + _secret_detail(finding)
            + " "
            + MISSING_DEFENCE["CWE-798"]
        )
    else:
        source = finding.trace[0] if finding.trace else None
        sink = finding.trace[-1] if finding.trace else None
        hops = [s for s in finding.trace if s.role == "propagation"]
        path_desc = " → ".join(
            f"line {s.line}" for s in finding.trace
        )
        why = (
            f"The value '{finding.variable}' is derived from "
            f"{_source_kind(finding)} read on line {source.line if source else '?'}"
            + (
                f", passes through {len(hops)} propagation step"
                f"{'s' if len(hops) != 1 else ''}"
                if hops
                else ""
            )
            + f", and reaches {_sink_name(finding)} on line "
            f"{sink.line if sink else finding.line} (path: {path_desc}). "
            + MISSING_DEFENCE.get(finding.cwe, "")
        )

    classification = (
        f"{finding.severity} severity, confidence {int(finding.confidence * 100)}% "
        f"({finding.classifier}). " + " ".join(finding.rationale[1:])
    ).strip()

    return Explanation(
        finding_id=finding.id,
        location=location,
        category=category,
        why=why,
        implication=IMPLICATIONS.get(finding.cwe, ""),
        trace=trace,
        classification=classification,
    )


def _source_kind(finding):
    ev = finding.evidence
    if ev and ev.source_kinds:
        return ev.source_kinds[0]
    return "untrusted input"


def _sink_name(finding):
    ev = finding.evidence
    return ev.sink_name if ev else "a sensitive operation"


def _secret_detail(finding):
    ev = finding.evidence
    if not ev:
        return ""
    flags = ev.flags
    if flags.get("known_format"):
        return f"The literal matches the format of a {flags['known_format']}."
    return (
        f"The literal has length {flags.get('length')} and entropy "
        f"{flags.get('entropy')}, and is not a recognised placeholder."
    )

"""Deterministic secure-code templates per CWE and minimal unified diffs.

Every template works on the original source text with position-based
edits computed from the ``ast``, so untouched lines stay byte-identical
and the diff stays minimal.
"""

from __future__ import annotations

import ast
import difflib
import re
from dataclasses import dataclass, field
from pathlib import Path

SHELL_META = set("|&;<>()$`\\\"'*?[]#~=%!{}\n")
PARAM_STYLE_PERCENT = ("psycopg2", "psycopg", "pymysql", "MySQLdb", "mysql")


@dataclass
class Recommendation:
    finding_id: str
    cwe: str
    title: str
    original: str
    corrected: str
    diff: str
    note: str
    applicable: bool = True
    removed_lines: list = field(default_factory=list)  # 1-based, original
    added_lines: list = field(default_factory=list)  # 1-based, corrected
    strategy: str = ""


# ---------------------------------------------------------------------------
# Text editing helpers
# ---------------------------------------------------------------------------


class SourceText:

    def __init__(self, code):
        self.code = code
        self.lines = code.splitlines(keepends=True)
        self.starts = []
        offset = 0
        for line in self.lines:
            self.starts.append(offset)
            offset += len(line)
        self.starts.append(offset)
        self.edits = []  # (start, end, text)

    def offset(self, line, byte_col):
        if line - 1 >= len(self.lines):
            return len(self.code)
        text = self.lines[line - 1]
        chars = len(text.encode("utf-8")[:byte_col].decode("utf-8", "ignore"))
        return self.starts[line - 1] + chars

    def span(self, node):
        return (
            self.offset(node.lineno, node.col_offset),
            self.offset(node.end_lineno, node.end_col_offset),
        )

    def text(self, node):
        start, end = self.span(node)
        return self.code[start:end]

    def line_start(self, line):
        return self.starts[min(line - 1, len(self.starts) - 1)]

    def replace(self, node, text):
        start, end = self.span(node)
        self.edits.append((start, end, text))

    def insert(self, offset, text):
        self.edits.append((offset, offset, text))

    def apply(self):
        result = self.code
        last_start = None
        for start, end, text in sorted(self.edits, key=lambda e: (e[0], e[1]), reverse=True):
            if last_start is not None and end > last_start:
                raise ValueError("overlapping edits")
            result = result[:start] + text + result[end:]
            last_start = start
        return result


def ensure_import(tree, src, module):
    for node in tree.body:
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name == module and alias.asname is None:
                    return
    last = None
    for node in tree.body:
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            last = node
        elif last is not None:
            break
    if last is not None:
        src.insert(src.line_start(last.end_lineno + 1), f"import {module}\n")
        return
    first = tree.body[0] if tree.body else None
    if (
        first is not None
        and isinstance(first, ast.Expr)
        and isinstance(first.value, ast.Constant)
        and isinstance(first.value.value, str)
    ):
        src.insert(src.line_start(first.end_lineno + 1), f"import {module}\n")
    else:
        src.insert(0, f"import {module}\n")


def py_string(value):
    escaped = value.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")
    return '"' + escaped + '"'


def find_node(tree, cls, line, col, evidence=None):
    """Node of type cls starting at (line, col). Chained calls such as
    conn.execute(q).fetchall() share a start position, so the evidence's
    end position picks the right one."""
    matches = [
        node for node in ast.walk(tree)
        if isinstance(node, cls) and node.lineno == line and node.col_offset == col
    ]
    if evidence is not None:
        for node in matches:
            if (node.end_lineno, node.end_col_offset) == (
                evidence.end_line, evidence.end_column
            ):
                return node
    return matches[-1] if matches else None


def find_stmt(tree, line, col):
    for node in ast.walk(tree):
        if isinstance(node, ast.stmt) and node.lineno == line and node.col_offset == col:
            return node
    return None


def enclosing_function(tree, line):
    best = None
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if node.lineno <= line <= (node.end_lineno or node.lineno):
                if best is None or node.lineno > best.lineno:
                    best = node
    return best or tree


def definition(tree, name, before_line):
    """Last simple `name = value` before `before_line` in the same function."""
    scope = enclosing_function(tree, before_line)
    best = None
    for node in ast.walk(scope):
        if (
            isinstance(node, ast.Assign)
            and len(node.targets) == 1
            and isinstance(node.targets[0], ast.Name)
            and node.targets[0].id == name
            and node.lineno < before_line
        ):
            if best is None or node.lineno > best.lineno:
                best = node
    return best


def parent_map(tree):
    parents = {}
    for node in ast.walk(tree):
        for child in ast.iter_child_nodes(node):
            parents[child] = node
    return parents


def tainted_names(finding, tree=None):
    """Variables that carry the tainted value along the finding's trace."""
    names = set()
    if finding.variable:
        names.add(finding.variable)
    for step in finding.trace:
        names.update(re.findall(r"'(\w+)'", step.description or ""))
    if tree is not None:
        lines = {step.line for step in finding.trace}
        for node in ast.walk(tree):
            if isinstance(node, (ast.Assign, ast.AnnAssign, ast.AugAssign, ast.With)) and node.lineno in lines:
                targets = getattr(node, "targets", None) or [getattr(node, "target", None)]
                for target in targets:
                    if target is not None:
                        names.update(n.id for n in ast.walk(target) if isinstance(n, ast.Name))
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.lineno in lines:
                names.update(a.arg for a in node.args.args)
    return names


def string_pieces(src, node):
    """Flatten an f-string / '+' chain into [('lit', str) | ('expr', node)]."""
    if isinstance(node, ast.JoinedStr):
        pieces = []
        for value in node.values:
            if isinstance(value, ast.Constant):
                pieces.append(("lit", value.value))
            elif isinstance(value, ast.FormattedValue):
                if value.format_spec is not None or value.conversion not in (-1, None):
                    return None
                pieces.append(("expr", value.value))
        return pieces
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
        left = string_pieces(src, node.left)
        right = string_pieces(src, node.right)
        if left is None or right is None:
            return None
        return left + right
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return [("lit", node.value)]
    if isinstance(node, (ast.Name, ast.Attribute, ast.Subscript, ast.Call)):
        return [("expr", node)]
    return None


def format_pieces(node):
    """`"...{}...".format(a, b)` and `"...%s..." % (a, b)` into pieces."""
    if (
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and node.func.attr == "format"
        and isinstance(node.func.value, ast.Constant)
        and isinstance(node.func.value.value, str)
        and not node.keywords
    ):
        parts = re.split(r"\{\}", node.func.value.value)
        if len(parts) - 1 != len(node.args):
            return None
        pieces = []
        for i, part in enumerate(parts):
            pieces.append(("lit", part))
            if i < len(node.args):
                pieces.append(("expr", node.args[i]))
        return pieces
    if (
        isinstance(node, ast.BinOp)
        and isinstance(node.op, ast.Mod)
        and isinstance(node.left, ast.Constant)
        and isinstance(node.left.value, str)
    ):
        args = node.right.elts if isinstance(node.right, ast.Tuple) else [node.right]
        parts = re.split(r"%[sdr]", node.left.value)
        if len(parts) - 1 != len(args):
            return None
        pieces = []
        for i, part in enumerate(parts):
            pieces.append(("lit", part))
            if i < len(args):
                pieces.append(("expr", args[i]))
        return pieces
    return None


def all_pieces(src, node):
    return format_pieces(node) or string_pieces(src, node)


# ---------------------------------------------------------------------------
# Templates
# ---------------------------------------------------------------------------


class TemplateError(Exception):
    pass


def _fix_cwe78(tree, src, finding, parents):
    ev = finding.evidence
    call = find_node(tree, ast.Call, ev.line, ev.column, ev)
    if call is None:
        raise TemplateError("sink call not found")
    name = ast.unparse(call.func)
    cmd_node = call.args[0] if call.args else None
    if cmd_node is None:
        for kw in call.keywords:
            if kw.arg in ("args", "cmd", "command"):
                cmd_node = kw.value
    if cmd_node is None:
        raise TemplateError("command argument not found")

    names = tainted_names(finding, tree)
    def_node = None
    build = cmd_node
    if isinstance(cmd_node, ast.Name):
        def_node = definition(tree, cmd_node.id, call.lineno)
        if def_node is not None:
            build = def_node.value

    pieces = all_pieces(src, build)
    tokens = None
    if pieces and any(kind == "lit" for kind, _ in pieces):
        tokens = _tokenize_command(src, pieces, names)

    imports = ["subprocess"]
    if tokens is not None:
        list_text = "[" + ", ".join(tokens) + "]"
        strategy = "argument list with shell=False"
        if def_node is not None and build is def_node.value:
            src.replace(def_node.value, list_text)
            arg_text = cmd_node.id
        else:
            arg_text = list_text
    elif pieces is not None and any(k == "expr" for k, _ in pieces) and _has_metachar(pieces):
        # Pipelines / redirections need a shell: quote every interpolated value.
        for kind, piece in pieces:
            if kind == "expr":
                src.replace(piece, f"shlex.quote({_as_str(src, piece, names)})")
        ensure_import(tree, src, "shlex")
        return (
            "shlex.quote() on interpolated values (shell kept for pipes/redirection)",
            "The command uses shell features (pipes, redirection or quoting), so the "
            "shell is kept and every interpolated value is quoted with shlex.quote().",
        )
    else:
        arg_text = f"shlex.split({src.text(cmd_node)})"
        imports.append("shlex")
        strategy = "shlex.split() + shell=False"

    parent = parents.get(call)
    if name.endswith("system"):
        suffix = "" if isinstance(parent, ast.Expr) else ".returncode"
        src.replace(call, f"subprocess.run({arg_text}, shell=False, check=False){suffix}")
    elif name.endswith("popen"):
        grand = parents.get(parent)
        if (
            isinstance(parent, ast.Attribute)
            and parent.attr == "read"
            and isinstance(grand, ast.Call)
        ):
            src.replace(
                grand,
                f"subprocess.run({arg_text}, shell=False, capture_output=True, "
                f"text=True, check=False).stdout",
            )
        else:
            src.replace(
                call,
                f"subprocess.Popen({arg_text}, shell=False, stdout=subprocess.PIPE, "
                f"text=True).stdout",
            )
    elif name.endswith(("getoutput", "getstatusoutput")):
        src.replace(
            call,
            f"subprocess.run({arg_text}, shell=False, capture_output=True, "
            f"text=True, check=False).stdout",
        )
    else:  # subprocess.* with shell=True
        if arg_text != (cmd_node.id if isinstance(cmd_node, ast.Name) else None):
            src.replace(cmd_node, arg_text)
        for kw in call.keywords:
            if kw.arg == "shell":
                src.replace(kw.value, "False")
    for module in imports:
        ensure_import(tree, src, module)
    return (
        strategy,
        "Runs the program directly with an argument list and shell=False, so shell "
        "metacharacters in user input are passed as plain text and never interpreted.",
    )


def _has_metachar(pieces):
    return any(kind == "lit" and set(value) & SHELL_META for kind, value in pieces)


def _as_str(src, node, names):
    text = src.text(node)
    if isinstance(node, ast.Name) and node.id in names:
        return text
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "str":
        return text
    return f"str({text})"


def _tokenize_command(src, pieces, names):
    if _has_metachar(pieces):
        return None
    tokens = []
    current = []

    def flush():
        if not current:
            return
        if len(current) == 1:
            kind, value = current[0]
            tokens.append(py_string(value) if kind == "lit" else _as_str(src, value, names))
        else:
            body = ""
            for kind, value in current:
                if kind == "lit":
                    body += value.replace("{", "{{").replace("}", "}}").replace('"', '\\"')
                else:
                    body += "{" + src.text(value) + "}"
            tokens.append('f"' + body + '"')
        current.clear()

    for kind, value in pieces:
        if kind == "expr":
            current.append((kind, value))
            continue
        for i, chunk in enumerate(re.split(r"(\s+)", value)):
            if not chunk:
                continue
            if chunk.isspace():
                flush()
            else:
                current.append(("lit", chunk))
    flush()
    if not tokens:
        return None
    return tokens


def _fix_cwe89(tree, src, finding, parents):
    ev = finding.evidence
    call = find_node(tree, ast.Call, ev.line, ev.column, ev)
    if call is None or not call.args:
        raise TemplateError("execute() call not found")
    if len(call.args) > 1:
        raise TemplateError("query already has a parameters argument")
    query_node = call.args[0]
    build = query_node
    def_node = None
    if isinstance(query_node, ast.Name):
        def_node = definition(tree, query_node.id, call.lineno)
        if def_node is None:
            raise TemplateError("cannot find where the query is built")
        build = def_node.value
    pieces = all_pieces(src, build)
    if not pieces or not any(k == "expr" for k, _ in pieces):
        raise TemplateError("query construction not recognised")

    placeholder = "?"
    for node in ast.walk(tree):
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            mods = [a.name for a in node.names] + ([node.module] if getattr(node, "module", None) else [])
            if any(m and m.split(".")[0] in PARAM_STYLE_PERCENT for m in mods):
                placeholder = "%s"

    sql = ""
    params = []
    for index, (kind, value) in enumerate(pieces):
        if kind == "lit":
            sql += value
            continue
        quote = sql[-1:] if sql[-1:] in ("'", '"') else ""
        nxt = pieces[index + 1] if index + 1 < len(pieces) else None
        if quote and nxt and nxt[0] == "lit" and nxt[1].startswith(quote):
            sql = sql[:-1]
            pieces[index + 1] = ("lit", nxt[1][1:])
        sql += placeholder
        params.append(src.text(value))
    params_text = "(" + ", ".join(params) + ("," if len(params) == 1 else "") + ")"

    if def_node is not None:
        src.replace(def_node.value, py_string(sql))
        src.insert(src.span(query_node)[1], f", {params_text}")
    else:
        src.replace(query_node, f"{py_string(sql)}, {params_text}")
    return (
        "parameterized query",
        f"Moves user data out of the SQL text into bound parameters ({placeholder} "
        "placeholders), so the database driver treats it strictly as data.",
    )


def _fix_cwe79(tree, src, finding, parents):
    ev = finding.evidence
    names = tainted_names(finding, tree)
    target = None
    if ev.flags.get("route_return"):
        for node in ast.walk(tree):
            if isinstance(node, ast.Return) and node.value is not None:
                if node.value.lineno == ev.line and node.value.col_offset == ev.column:
                    target = node.value
    else:
        call = find_node(tree, ast.Call, ev.line, ev.column, ev)
        if call is not None and call.args:
            target = call.args[0]
    if target is None:
        raise TemplateError("HTML sink not found")

    build = target
    if isinstance(target, ast.Name):
        def_node = definition(tree, target.id, ev.line)
        if def_node is not None:
            build = def_node.value

    pieces = all_pieces(src, build)
    wrapped = 0
    if pieces and any(k == "lit" for k, _ in pieces):
        for kind, value in pieces:
            if kind == "expr" and _mentions(value, names):
                src.replace(value, f"html.escape({_as_str(src, value, names)})")
                wrapped += 1
    if not wrapped:
        src.replace(target, f"html.escape({_as_str(src, target, names)})")
    ensure_import(tree, src, "html")
    return (
        "html.escape() on untrusted values",
        "HTML-escapes the untrusted value before it is placed in the page, so "
        "characters like < > \" ' & are shown as text instead of being parsed as markup.",
    )


def _mentions(node, names):
    return any(isinstance(n, ast.Name) and n.id in names for n in ast.walk(node))


def _fix_cwe22(tree, src, finding, parents):
    ev = finding.evidence
    call = find_node(tree, ast.Call, ev.line, ev.column, ev)
    if call is None:
        raise TemplateError("file call not found")
    path_node = None
    path_method = False
    if call.args:
        path_node = call.args[0]
    if isinstance(call.func, ast.Attribute) and ev.sink_name.startswith("Path."):
        path_node = call.func.value
        path_method = True
    if path_node is None:
        raise TemplateError("path argument not found")

    stmt = find_stmt(tree, ev.stmt_line, ev.stmt_col)
    if stmt is None:
        raise TemplateError("statement not found")

    join_call = path_node
    if isinstance(path_node, ast.Name):
        def_node = definition(tree, path_node.id, stmt.lineno)
        if def_node is not None:
            join_call = def_node.value
    base = "os.getcwd()"
    if (
        isinstance(join_call, ast.Call)
        and ast.unparse(join_call.func) in ("os.path.join", "join")
        and join_call.args
    ):
        base = src.text(join_call.args[0])

    path_text = src.text(path_node)
    indent = " " * stmt.col_offset
    block = (
        f"{indent}allowed_dir = os.path.realpath({base})\n"
        f"{indent}safe_path = os.path.realpath({path_text})\n"
        f"{indent}if os.path.commonpath([allowed_dir, safe_path]) != allowed_dir:\n"
        f"{indent}    raise ValueError(\"Requested path is outside the allowed directory\")\n"
    )
    src.insert(src.line_start(stmt.lineno), block)
    if path_method:
        ctor = "Path"
        if isinstance(path_node, ast.Call):
            ctor = src.text(path_node.func)
        src.replace(path_node, f"{ctor}(safe_path)")
    else:
        src.replace(path_node, "safe_path")
    ensure_import(tree, src, "os")
    return (
        "realpath + commonpath containment check",
        "Resolves the requested path (following '..' and symlinks) and refuses it "
        "unless it is still inside the allowed directory.",
    )


def _fix_cwe798(tree, src, finding, parents):
    ev = finding.evidence
    literal = find_node(tree, ast.Constant, ev.line, ev.column, ev)
    if literal is None:
        raise TemplateError("literal not found")
    var = ev.variable or "SECRET_VALUE"
    env_name = re.sub(r"[^A-Za-z0-9]+", "_", var).strip("_").upper() or "SECRET_VALUE"
    src.replace(literal, f'os.environ.get("{env_name}", "")')
    ensure_import(tree, src, "os")
    return (
        "read from environment variable",
        f"Reads the credential from the {env_name} environment variable at run time "
        "instead of storing it in source code. Set it in your shell or deployment "
        "and rotate the exposed value, because it is still in version history.",
    )


TEMPLATES = {
    "CWE-78": ("Use an argument list with shell=False", _fix_cwe78),
    "CWE-89": ("Use a parameterized query", _fix_cwe89),
    "CWE-79": ("Escape output with html.escape()", _fix_cwe79),
    "CWE-22": ("Add a path containment check", _fix_cwe22),
    "CWE-798": ("Load the credential from the environment", _fix_cwe798),
}


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def unified_diff(original, corrected, filename="file.py"):
    name = Path(filename).name
    return "".join(
        difflib.unified_diff(
            original.splitlines(keepends=True),
            corrected.splitlines(keepends=True),
            fromfile=f"a/{name}",
            tofile=f"b/{name}",
            n=3,
        )
    )


def changed_lines(original, corrected):
    a = original.splitlines()
    b = corrected.splitlines()
    removed, added = [], []
    matcher = difflib.SequenceMatcher(None, a, b, autojunk=False)
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag in ("replace", "delete"):
            removed.extend(range(i1 + 1, i2 + 1))
        if tag in ("replace", "insert"):
            added.extend(range(j1 + 1, j2 + 1))
    return removed, added


def recommend(finding, code):
    title, template = TEMPLATES[finding.cwe]
    try:
        tree = ast.parse(code)
        src = SourceText(code)
        strategy, note = template(tree, src, finding, parent_map(tree))
        corrected = src.apply()
        ast.parse(corrected)
    except (TemplateError, SyntaxError, ValueError) as error:
        return Recommendation(
            finding_id=finding.id,
            cwe=finding.cwe,
            title=title,
            original=code,
            corrected=code,
            diff="",
            note=(
                f"No automatic fix could be generated ({error}). "
                + MANUAL_ADVICE[finding.cwe]
            ),
            applicable=False,
        )
    removed, added = changed_lines(code, corrected)
    return Recommendation(
        finding_id=finding.id,
        cwe=finding.cwe,
        title=title,
        original=code,
        corrected=corrected,
        diff=unified_diff(code, corrected, finding.file),
        note=note + " Apply is a single undoable edit (Ctrl+Z).",
        applicable=corrected != code,
        removed_lines=removed,
        added_lines=added,
        strategy=strategy,
    )


MANUAL_ADVICE = {
    "CWE-78": "Pass an argument list to subprocess.run() with shell=False, or quote values with shlex.quote().",
    "CWE-89": "Use placeholders in the SQL text and pass values as the second argument of execute().",
    "CWE-79": "Escape the value with html.escape() or render it through an auto-escaping template.",
    "CWE-22": "Resolve the path with os.path.realpath() and check it with os.path.commonpath() against the allowed directory.",
    "CWE-798": "Read the credential from an environment variable or a secret manager.",
}

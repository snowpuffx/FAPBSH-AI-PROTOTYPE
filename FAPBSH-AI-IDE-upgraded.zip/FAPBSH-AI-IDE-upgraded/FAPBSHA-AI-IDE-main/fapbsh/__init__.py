"""FAPBSH AI analysis core.

Everything inside this package is plain Python (no Qt imports) so it can
be imported and unit-tested without a GUI.
"""

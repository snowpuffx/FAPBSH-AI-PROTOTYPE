"""Data models shared by the analysis, classification, explanation and
verification layers. No Qt imports."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from typing import Optional


# Trace roles
SOURCE = "source"
PROPAGATION = "propagation"
SINK = "sink"

# Evidence kinds (what the detector saw, before classification)
KIND_OS_COMMAND = "os_command"
KIND_SQL_QUERY = "sql_query"
KIND_FILE_PATH = "file_path"
KIND_HTML_OUTPUT = "html_output"
KIND_HARDCODED_SECRET = "hardcoded_secret"


@dataclass(frozen=True)
class TraceStep:
    """One step of a data-flow path."""

    line: int
    role: str  # source | propagation | sink
    description: str = ""
    column: int = 0

    def as_tuple(self):
        return (self.line, self.role)


@dataclass
class Evidence:
    """Raw facts collected by a detector.

    A Classifier turns Evidence into a CWE, a severity and a confidence.
    """

    kind: str
    file: str
    line: int
    column: int
    end_line: int
    end_column: int
    snippet: str
    sink_name: str
    variable: str
    trace: list = field(default_factory=list)  # list[TraceStep]
    source_kinds: list = field(default_factory=list)
    sanitizers_seen: list = field(default_factory=list)
    flags: dict = field(default_factory=dict)
    # Position of the statement that contains the sink (for fix templates)
    stmt_line: int = 0
    stmt_col: int = 0


@dataclass
class Finding:
    """A classified vulnerability finding."""

    id: str
    cwe: str
    name: str
    severity: str
    file: str
    line: int
    column: int
    snippet: str
    confidence: float
    trace: list  # ordered list[TraceStep]
    message: str = ""
    variable: str = ""
    classifier: str = ""
    rationale: list = field(default_factory=list)
    end_line: int = 0
    end_column: int = 0
    evidence: Optional[Evidence] = None

    @property
    def trace_tuples(self):
        """The trace as an ordered list of (line, role) tuples."""
        return [step.as_tuple() for step in self.trace]

    @property
    def source_line(self):
        for step in self.trace:
            if step.role == SOURCE:
                return step.line
        return self.line

    @property
    def sink_line(self):
        for step in reversed(self.trace):
            if step.role == SINK:
                return step.line
        return self.line

    def key(self):
        """Stable identity used for 'Ignore for this session'."""
        return (self.file, self.cwe, self.snippet.strip(), self.variable)


@dataclass
class SuppressedCandidate:
    """A candidate that was deliberately not reported (e.g. a placeholder
    credential). Kept so the UI and tests can show why."""

    line: int
    reason: str
    snippet: str


@dataclass
class AnalysisResult:
    file: str
    findings: list = field(default_factory=list)
    suppressed: list = field(default_factory=list)
    errors: list = field(default_factory=list)

    @property
    def ok(self):
        return not self.errors


def make_finding_id(file, cwe, line, column, variable):
    raw = f"{file}|{cwe}|{line}|{column}|{variable}"
    return "F-" + hashlib.sha1(raw.encode("utf-8")).hexdigest()[:8]

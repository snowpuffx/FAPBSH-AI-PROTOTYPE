"""Intra-procedural taint tracking over the Python ``ast``.

Each function (and the module body) is walked statement by statement while
an environment maps variable names to a :class:`Taint`. A taint remembers
the ordered data-flow path(s) that produced it, which CWEs it has been
sanitized for, and a few flags (``html``, ``normalized``).

Calls to functions defined in the same file are handled with small
summaries (which parameters reach the return value, which parameters reach
a sink), so taint follows function arguments and return values inside one
module. Anything across modules is out of scope.
"""

from __future__ import annotations

import ast
from dataclasses import dataclass, field, replace
from typing import Optional

from fapbsh.analysis import rules
from fapbsh.analysis.models import (
    KIND_FILE_PATH,
    KIND_HTML_OUTPUT,
    KIND_OS_COMMAND,
    KIND_SQL_QUERY,
    PROPAGATION,
    SINK,
    SOURCE,
    Evidence,
    TraceStep,
)

MAX_PATHS = 4
MAX_PASSES = 3

NON_PROPAGATING_CALLS = {
    "print",
    "isinstance",
    "issubclass",
    "hasattr",
    "callable",
    "id",
    "type",
    "os.path.exists",
    "os.path.isfile",
    "os.path.isdir",
    "os.path.islink",
}

# Methods that add their argument into the receiver container.
CONTAINER_MUTATORS = {"append", "extend", "add", "insert", "update", "setdefault"}


# ---------------------------------------------------------------------------
# Taint values
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class FlowPath:
    steps: tuple  # tuple[TraceStep, ...]
    origin: str  # "source" or "param:<name>"
    source_kind: str = ""

    @property
    def is_source(self):
        return self.origin == "source"

    def extend(self, step):
        if self.steps:
            last = self.steps[-1]
            if last.line == step.line and last.role == step.role:
                return self
            if (
                last.line == step.line
                and last.role == SOURCE
                and step.role == PROPAGATION
            ):
                # "x = input()" is the source itself, no extra step needed
                return self
        return replace(self, steps=self.steps + (step,))


@dataclass(frozen=True)
class Taint:
    paths: tuple  # tuple[FlowPath, ...]
    sanitized: frozenset = frozenset()
    normalized: bool = False
    html: bool = False

    @staticmethod
    def source(line, col, description):
        step = TraceStep(line, SOURCE, description, col)
        return Taint((FlowPath((step,), "source", description),))

    @staticmethod
    def param(name, line, col):
        step = TraceStep(line, PROPAGATION, f"parameter '{name}'", col)
        return Taint((FlowPath((step,), "param:" + name),))

    def extend(self, step):
        return replace(self, paths=tuple(p.extend(step) for p in self.paths))

    def with_sanitized(self, cwes):
        return replace(self, sanitized=self.sanitized | frozenset(cwes))

    def with_flags(self, **kwargs):
        return replace(self, **kwargs)

    @property
    def source_paths(self):
        return [p for p in self.paths if p.is_source]

    @property
    def param_paths(self):
        return [p for p in self.paths if not p.is_source]


def combine(*taints) -> Optional[Taint]:
    present = [t for t in taints if t is not None]
    if not present:
        return None
    if len(present) == 1:
        return present[0]
    paths = []
    seen = set()
    # Real sources first so the reported trace starts at real input.
    ordered = sorted(
        (p for t in present for p in t.paths), key=lambda p: not p.is_source
    )
    for path in ordered:
        key = (path.origin, path.steps)
        if key in seen:
            continue
        seen.add(key)
        paths.append(path)
        if len(paths) >= MAX_PATHS:
            break
    sanitized = frozenset.intersection(*(t.sanitized for t in present))
    return Taint(
        tuple(paths),
        sanitized=sanitized,
        normalized=all(t.normalized for t in present),
        html=any(t.html for t in present),
    )


def merge_envs(envs):
    envs = [e for e in envs if e is not None]
    if not envs:
        return None
    merged = {}
    keys = set()
    for env in envs:
        keys.update(env)
    for key in keys:
        values = [env.get(key) for env in envs]
        merged[key] = combine(*values)
    return merged


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def dotted_name(node):
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        base = dotted_name(node.value)
        if base:
            return base + "." + node.attr
    return None


def collect_aliases(tree):
    aliases = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.asname:
                    aliases[alias.asname] = alias.name
                else:
                    head = alias.name.split(".")[0]
                    aliases[head] = head
        elif isinstance(node, ast.ImportFrom) and node.module:
            for alias in node.names:
                aliases[alias.asname or alias.name] = (
                    node.module + "." + alias.name
                )
    return aliases


def terminates(body):
    """True when a block always leaves the current flow."""
    if not body:
        return False
    last = body[-1]
    if isinstance(last, (ast.Raise, ast.Return, ast.Continue, ast.Break)):
        return True
    if isinstance(last, ast.Expr) and isinstance(last.value, ast.Call):
        name = dotted_name(last.value.func) or ""
        if name.split(".")[-1] in {"abort", "exit", "_exit"}:
            return True
    if isinstance(last, ast.If):
        return terminates(last.body) and terminates(last.orelse)
    return False


def has_html_literal(node):
    for child in ast.walk(node):
        if (
            isinstance(child, ast.Constant)
            and isinstance(child.value, str)
            and "<" in child.value
            and ">" in child.value
        ):
            return True
    return False


def describe_value(node):
    if isinstance(node, ast.JoinedStr):
        return "f-string"
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
        return "string concatenation"
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Mod):
        return "% formatting"
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
        if node.func.attr == "format":
            return ".format()"
        if node.func.attr == "join":
            return "join()"
        return f".{node.func.attr}() call"
    if isinstance(node, ast.Call):
        name = dotted_name(node.func)
        return f"{name}() call" if name else "call"
    if isinstance(node, (ast.List, ast.Tuple)):
        return "list/tuple"
    return "assignment"


def target_names(target):
    if isinstance(target, ast.Name):
        return [target.id]
    if isinstance(target, (ast.Tuple, ast.List)):
        names = []
        for elt in target.elts:
            names.extend(target_names(elt))
        return names
    if isinstance(target, ast.Starred):
        return target_names(target.value)
    if isinstance(target, ast.Attribute):
        name = dotted_name(target)
        return [name] if name else []
    if isinstance(target, ast.Subscript):
        return target_names(target.value)
    return []


def first_name(node):
    for child in ast.walk(node):
        if isinstance(child, ast.Name):
            return child.id
    return ""


# ---------------------------------------------------------------------------
# Summaries
# ---------------------------------------------------------------------------


@dataclass
class SinkRecord:
    """A sink reached inside a function from one of its parameters."""

    param: str
    kind: str
    sink_name: str
    node: ast.AST
    stmt: ast.stmt
    steps_after_param: tuple
    sanitized: frozenset
    flags: dict
    variable: str


@dataclass
class Summary:
    params: list = field(default_factory=list)
    returns_params: dict = field(default_factory=dict)  # param -> steps
    returns_source: Optional[Taint] = None
    param_sinks: list = field(default_factory=list)  # list[SinkRecord]

    def signature(self):
        return (
            tuple(sorted(self.returns_params)),
            self.returns_source is not None,
            tuple(sorted((r.param, r.kind, r.node.lineno) for r in self.param_sinks)),
        )


# ---------------------------------------------------------------------------
# Analyzer
# ---------------------------------------------------------------------------


class TaintAnalyzer:

    def __init__(self, tree, source_lines, filename):
        self.tree = tree
        self.lines = source_lines
        self.filename = filename
        self.aliases = collect_aliases(tree)
        self.functions = {}  # key -> (FunctionDef, class_name or None)
        self.summaries = {}
        self.evidence = {}
        self.global_env = {}
        self._collect_functions()

    # ----- setup -----------------------------------------------------

    def _collect_functions(self):
        for node in self.tree.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                self.functions[node.name] = (node, None)
            elif isinstance(node, ast.ClassDef):
                for item in node.body:
                    if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        self.functions[f"{node.name}.{item.name}"] = (
                            item,
                            node.name,
                        )

    def resolve(self, node):
        name = dotted_name(node)
        if not name:
            return None
        head, _, rest = name.partition(".")
        if head in self.aliases:
            full = self.aliases[head]
            return full + ("." + rest if rest else "")
        return name

    def is_route(self, func):
        for deco in func.decorator_list:
            target = deco.func if isinstance(deco, ast.Call) else deco
            if (
                isinstance(target, ast.Attribute)
                and target.attr in rules.ROUTE_DECORATOR_ATTRS
            ):
                return True
        return False

    # ----- driver ----------------------------------------------------

    def run(self):
        for _ in range(MAX_PASSES):
            before = {k: s.signature() for k, s in self.summaries.items()}
            self.evidence = {}
            module_scope = Scope(self, None, None)
            module_scope.exec_block(
                [
                    s
                    for s in self.tree.body
                    if not isinstance(
                        s, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)
                    )
                ]
            )
            self.global_env = module_scope.env
            for key, (func, class_name) in self.functions.items():
                self.summaries[key] = self._analyze_function(func, class_name)
            after = {k: s.signature() for k, s in self.summaries.items()}
            if before == after:
                break
        return list(self.evidence.values())

    def _analyze_function(self, func, class_name):
        scope = Scope(self, func, class_name)
        summary = Summary()
        scope.summary = summary
        route = self.is_route(func)
        args = func.args
        all_args = args.posonlyargs + args.args + args.kwonlyargs
        if args.vararg:
            all_args.append(args.vararg)
        if args.kwarg:
            all_args.append(args.kwarg)
        for arg in all_args:
            if arg.arg in ("self", "cls"):
                continue
            summary.params.append(arg.arg)
            if route:
                scope.env[arg.arg] = Taint.source(
                    func.lineno,
                    func.col_offset,
                    f"URL route parameter '{arg.arg}'",
                )
            else:
                scope.env[arg.arg] = Taint.param(
                    arg.arg, func.lineno, func.col_offset
                )
        scope.is_route = route
        scope.exec_block(func.body)
        return summary

    # ----- evidence --------------------------------------------------

    def line_text(self, line):
        if 1 <= line <= len(self.lines):
            return self.lines[line - 1].rstrip("\n")
        return ""

    def add_evidence(self, kind, sink_name, node, stmt, path, sanitized,
                     flags, variable):
        key = (kind, node.lineno, node.col_offset)
        if key in self.evidence:
            return
        sink_step = TraceStep(
            node.lineno, SINK, f"reaches {sink_name}", node.col_offset
        )
        steps = list(path.steps)
        while (
            len(steps) > 1
            and steps[-1].line == sink_step.line
            and steps[-1].role == PROPAGATION
        ):
            steps.pop()
        steps.append(sink_step)
        self.evidence[key] = Evidence(
            kind=kind,
            file=self.filename,
            line=node.lineno,
            column=node.col_offset,
            end_line=getattr(node, "end_lineno", node.lineno) or node.lineno,
            end_column=getattr(node, "end_col_offset", node.col_offset)
            or node.col_offset,
            snippet=self.line_text(node.lineno).strip(),
            sink_name=sink_name,
            variable=variable,
            trace=steps,
            source_kinds=[path.source_kind] if path.source_kind else [],
            sanitizers_seen=sorted(sanitized),
            flags=dict(flags),
            stmt_line=stmt.lineno if stmt is not None else node.lineno,
            stmt_col=stmt.col_offset if stmt is not None else node.col_offset,
        )


class Scope:
    """Walks one function body (or the module body)."""

    def __init__(self, analyzer, func, class_name):
        self.a = analyzer
        self.func = func
        self.class_name = class_name
        self.env = {}
        self.summary = None
        self.is_route = False
        self.stmt = None

    # ----- environment ----------------------------------------------

    def lookup(self, name):
        if name in self.env:
            return self.env[name]
        if self.func is not None:
            return self.a.global_env.get(name)
        return None

    def bind(self, target, taint, stmt_line, value_node=None):
        for name in target_names(target):
            if taint is None:
                if isinstance(target, ast.Subscript) or "." in name:
                    # d[k] = clean does not clean d
                    continue
                self.env[name] = None
                continue
            how = describe_value(value_node) if value_node is not None else "assignment"
            step = TraceStep(
                stmt_line,
                PROPAGATION,
                f"assigned to '{name}' via {how}",
                getattr(target, "col_offset", 0),
            )
            existing = self.env.get(name) if isinstance(target, ast.Subscript) else None
            self.env[name] = combine(existing, taint.extend(step))

    # ----- statements -----------------------------------------------

    def exec_block(self, body):
        for stmt in body:
            if self.env is None:
                return
            self.exec_stmt(stmt)

    def exec_stmt(self, stmt):
        self.stmt = stmt
        if isinstance(stmt, ast.Assign):
            taint = self.eval(stmt.value)
            for target in stmt.targets:
                self.bind(target, taint, stmt.lineno, stmt.value)
        elif isinstance(stmt, ast.AnnAssign):
            if stmt.value is not None:
                self.bind(stmt.target, self.eval(stmt.value), stmt.lineno, stmt.value)
        elif isinstance(stmt, ast.AugAssign):
            old = None
            name = target_names(stmt.target)
            if name:
                old = self.lookup(name[0])
            value = self.eval(stmt.value)
            taint = combine(old, value)
            if taint is not None and value is not None:
                self.bind(stmt.target, taint, stmt.lineno, stmt.value)
        elif isinstance(stmt, ast.Expr):
            self.eval(stmt.value)
            if terminates([stmt]):
                self.env = None
        elif isinstance(stmt, ast.Return):
            self.exec_return(stmt)
        elif isinstance(stmt, ast.If):
            self.exec_if(stmt)
        elif isinstance(stmt, (ast.For, ast.AsyncFor)):
            iter_taint = self.eval(stmt.iter)
            before = dict(self.env)
            for _ in range(2):
                self.bind(stmt.target, iter_taint, stmt.lineno, stmt.iter)
                self.exec_block(stmt.body)
                if self.env is None:
                    self.env = dict(before)
                    break
            loop_env = self.env
            self.env = merge_envs([before, loop_env])
            self.exec_block(stmt.orelse)
        elif isinstance(stmt, ast.While):
            self.eval(stmt.test)
            before = dict(self.env)
            for _ in range(2):
                self.exec_block(stmt.body)
                if self.env is None:
                    self.env = dict(before)
                    break
            self.env = merge_envs([before, self.env])
            self.exec_block(stmt.orelse)
        elif isinstance(stmt, (ast.With, ast.AsyncWith)):
            for item in stmt.items:
                taint = self.eval(item.context_expr)
                if item.optional_vars is not None:
                    self.bind(
                        item.optional_vars, taint, stmt.lineno, item.context_expr
                    )
            self.exec_block(stmt.body)
        elif isinstance(stmt, ast.Try) or type(stmt).__name__ == "TryStar":
            start = dict(self.env)
            self.exec_block(stmt.body)
            after_body = self.env
            branches = [after_body]
            for handler in stmt.handlers:
                self.env = merge_envs([start, after_body]) or dict(start)
                self.exec_block(handler.body)
                branches.append(self.env)
            self.env = merge_envs(branches)
            if self.env is not None:
                self.exec_block(stmt.orelse)
            if self.env is None:
                self.env = dict(start)
                self.exec_block(stmt.finalbody)
                self.env = None
            else:
                self.exec_block(stmt.finalbody)
        elif isinstance(stmt, ast.Raise):
            if stmt.exc is not None:
                self.eval(stmt.exc)
            self.env = None
        elif isinstance(stmt, (ast.Continue, ast.Break)):
            self.env = None
        elif type(stmt).__name__ == "Match":
            self.eval(stmt.subject)
            start = dict(self.env)
            branches = [dict(start)]
            for case in stmt.cases:
                self.env = dict(start)
                self.exec_block(case.body)
                branches.append(self.env)
            self.env = merge_envs(branches)
        elif isinstance(
            stmt, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)
        ):
            return  # analysed separately (nested defs are out of scope)
        else:
            for child in ast.iter_child_nodes(stmt):
                if isinstance(child, ast.expr):
                    self.eval(child)
        if self.env is not None:
            self.stmt = stmt

    def exec_return(self, stmt):
        if stmt.value is None:
            self.env = None
            return
        taint = self.eval(stmt.value)
        if taint is not None:
            if (
                self.is_route
                and (taint.html or has_html_literal(stmt.value))
                and "CWE-79" not in taint.sanitized
            ):
                self.report(
                    KIND_HTML_OUTPUT,
                    "the HTTP response (return value of a route)",
                    stmt.value,
                    taint,
                    {"route_return": True},
                    variable=first_name(stmt.value),
                )
            if self.summary is not None:
                fname = self.func.name if self.func is not None else "function"
                ret_step = TraceStep(
                    stmt.lineno,
                    PROPAGATION,
                    f"returned from {fname}() via {describe_value(stmt.value)}",
                    stmt.col_offset,
                )
                taint = taint.extend(ret_step)
                for path in taint.paths:
                    if path.is_source:
                        self.summary.returns_source = combine(
                            self.summary.returns_source,
                            Taint((path,), taint.sanitized, taint.normalized, taint.html),
                        )
                    else:
                        param = path.origin.split(":", 1)[1]
                        self.summary.returns_params.setdefault(
                            param, (path.steps[1:], taint.sanitized, taint.html)
                        )
        self.env = None

    def exec_if(self, stmt):
        self.eval(stmt.test)
        contained_names, positive = self.containment_check(stmt.test)
        start = dict(self.env)

        self.env = dict(start)
        if contained_names and positive:
            self.sanitize_paths(contained_names)
        self.exec_block(stmt.body)
        body_env = self.env

        self.env = dict(start)
        if contained_names and not positive:
            self.sanitize_paths(contained_names)
        self.exec_block(stmt.orelse)
        else_env = self.env

        self.env = merge_envs([body_env, else_env])

    def sanitize_paths(self, names):
        for name in names:
            taint = self.lookup(name)
            if taint is not None and taint.normalized:
                self.env[name] = taint.with_sanitized({"CWE-22"})

    def containment_check(self, test):
        """Detect `commonpath([...]) == base`, `p.startswith(base)`,
        `p.is_relative_to(base)` and their negations.

        Returns (names checked, positive polarity).
        """
        positive = True
        node = test
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.Not):
            positive = False
            node = node.operand
        call = None
        if isinstance(node, ast.Compare) and len(node.ops) == 1:
            op = node.ops[0]
            for side in [node.left] + node.comparators:
                if isinstance(side, ast.Call):
                    call = side
            if isinstance(op, (ast.NotEq, ast.IsNot)):
                positive = not positive
            elif not isinstance(op, (ast.Eq, ast.Is)):
                return [], True
        elif isinstance(node, ast.Call):
            call = node
        if call is None:
            return [], True
        name = self.a.resolve(call.func) or ""
        names = []
        if name in rules.CONTAINMENT_FUNCS:
            for arg in call.args:
                for child in ast.walk(arg):
                    if isinstance(child, ast.Name):
                        names.append(child.id)
        elif (
            isinstance(call.func, ast.Attribute)
            and call.func.attr in rules.CONTAINMENT_METHODS
        ):
            receiver = call.func.value
            if isinstance(receiver, ast.Call):  # str(p).startswith(...)
                if receiver.args:
                    receiver = receiver.args[0]
            names.extend(target_names(receiver))
        return names, positive

    # ----- expressions ----------------------------------------------

    def eval(self, node) -> Optional[Taint]:
        if node is None:
            return None
        if isinstance(node, ast.Constant):
            return None
        if isinstance(node, ast.Name):
            return self.lookup(node.id)
        if isinstance(node, ast.Attribute):
            full = self.a.resolve(node)
            if full in rules.SOURCE_ATTRIBUTES:
                return Taint.source(
                    node.lineno, node.col_offset, rules.SOURCE_ATTRIBUTES[full]
                )
            name = dotted_name(node)
            if name and name in self.env:
                return self.env[name]
            return self.eval(node.value)
        if isinstance(node, ast.Subscript):
            self.eval(node.slice)
            return self.eval(node.value)
        if isinstance(node, ast.Call):
            return self.eval_call(node)
        if isinstance(node, ast.JoinedStr):
            parts = [self.eval(v) for v in node.values]
            taint = combine(*parts)
            if taint is not None and has_html_literal(node):
                taint = taint.with_flags(html=True)
            return taint
        if isinstance(node, ast.FormattedValue):
            return self.eval(node.value)
        if isinstance(node, ast.BinOp):
            taint = combine(self.eval(node.left), self.eval(node.right))
            if taint is not None and has_html_literal(node):
                taint = taint.with_flags(html=True)
            return taint
        if isinstance(node, ast.BoolOp):
            return combine(*(self.eval(v) for v in node.values))
        if isinstance(node, ast.IfExp):
            self.eval(node.test)
            return combine(self.eval(node.body), self.eval(node.orelse))
        if isinstance(node, (ast.List, ast.Tuple, ast.Set)):
            return combine(*(self.eval(e) for e in node.elts))
        if isinstance(node, ast.Dict):
            for k in node.keys:
                self.eval(k)
            return combine(*(self.eval(v) for v in node.values))
        if isinstance(node, ast.Compare):
            self.eval(node.left)
            for comp in node.comparators:
                self.eval(comp)
            return None
        if isinstance(node, ast.Starred):
            return self.eval(node.value)
        if isinstance(node, ast.Await):
            return self.eval(node.value)
        if isinstance(node, ast.NamedExpr):
            taint = self.eval(node.value)
            self.bind(node.target, taint, node.lineno, node.value)
            return taint
        if isinstance(node, (ast.ListComp, ast.SetComp, ast.GeneratorExp, ast.DictComp)):
            saved = dict(self.env)
            for gen in node.generators:
                self.bind(gen.target, self.eval(gen.iter), node.lineno, gen.iter)
            if isinstance(node, ast.DictComp):
                result = combine(self.eval(node.key), self.eval(node.value))
            else:
                result = self.eval(node.elt)
            self.env = saved
            return result
        if isinstance(node, ast.Lambda):
            return None
        taints = [
            self.eval(child)
            for child in ast.iter_child_nodes(node)
            if isinstance(child, ast.expr)
        ]
        return combine(*taints)

    def eval_call(self, node):
        func = node.func
        name = self.a.resolve(func) or ""
        method = func.attr if isinstance(func, ast.Attribute) else None
        receiver_taint = None
        if isinstance(func, ast.Attribute):
            receiver_full = self.a.resolve(func.value)
            if receiver_full in rules.SOURCE_ATTRIBUTES:
                receiver_taint = Taint.source(
                    node.lineno,
                    node.col_offset,
                    rules.SOURCE_ATTRIBUTES[receiver_full],
                )
            else:
                receiver_taint = self.eval(func.value)
        arg_taints = [self.eval(a) for a in node.args]
        kw_taints = {k.arg: self.eval(k.value) for k in node.keywords}
        all_args = combine(*arg_taints, *kw_taints.values())

        local_key = self.local_function_key(func)

        # --- sinks (checked first; they also see sanitized flags) ---
        self.check_sinks(node, name, method, receiver_taint, arg_taints, kw_taints)

        if local_key is not None:
            return self.apply_summary(node, local_key, arg_taints, kw_taints)

        # --- sanitizers ---
        if name in rules.SANITIZERS:
            cwes = rules.SANITIZERS[name]
            if cwes >= rules.ALL_CWES:
                return None
            return all_args.with_sanitized(cwes) if all_args else None

        # --- path normalisation ---
        if name in rules.PATH_NORMALIZERS:
            return all_args.with_flags(normalized=True) if all_args else None
        if method in rules.PATH_NORMALIZER_METHODS and receiver_taint is not None:
            return receiver_taint.with_flags(normalized=True)

        # --- sources ---
        if name in rules.SOURCE_CALLS:
            return Taint.source(node.lineno, node.col_offset, rules.SOURCE_CALLS[name])
        if receiver_taint is not None and receiver_taint.source_paths and isinstance(
            func, ast.Attribute
        ) and self.a.resolve(func.value) in rules.SOURCE_ATTRIBUTES:
            return receiver_taint
        if name in rules.FILE_OPEN_CALLS:
            return Taint.source(node.lineno, node.col_offset, "file contents (open())")
        if method in rules.PATH_READ_METHODS:
            return Taint.source(
                node.lineno, node.col_offset, f"file contents (.{method}())"
            )

        if name in NON_PROPAGATING_CALLS:
            return None

        # --- containers mutated by tainted data ---
        if method in CONTAINER_MUTATORS and all_args is not None:
            for target in target_names(func.value):
                self.env[target] = combine(self.lookup(target), all_args)
            return None

        if method in rules.SQL_METHODS:
            return None

        # --- generic propagation ---
        taint = combine(receiver_taint, all_args)
        if (
            taint is not None
            and method == "format"
            and has_html_literal(func.value)
        ):
            taint = taint.with_flags(html=True)
        if taint is not None and method in {"format", "join"}:
            if has_html_literal(func.value):
                taint = taint.with_flags(html=True)
        return taint

    def local_function_key(self, func):
        if isinstance(func, ast.Name) and func.id in self.a.functions:
            if func.id in self.env:
                return None
            return func.id
        if (
            isinstance(func, ast.Attribute)
            and isinstance(func.value, ast.Name)
            and func.value.id in ("self", "cls")
            and self.class_name
        ):
            key = f"{self.class_name}.{func.attr}"
            if key in self.a.functions:
                return key
        return None

    def apply_summary(self, node, key, arg_taints, kw_taints):
        summary = self.a.summaries.get(key)
        if summary is None:
            return combine(*arg_taints, *kw_taints.values())
        bound = {}
        for param, taint in zip(summary.params, arg_taints):
            bound[param] = taint
        for kw, taint in kw_taints.items():
            if kw in summary.params:
                bound[kw] = taint
        fname = key.split(".")[-1]
        call_step_tpl = (node.lineno, node.col_offset)

        # Parameters that reach a sink inside the callee
        for record in summary.param_sinks:
            taint = bound.get(record.param)
            if taint is None:
                continue
            cwe = rules.KIND_TO_CWE[record.kind]
            if cwe in taint.sanitized:
                continue
            step = TraceStep(
                call_step_tpl[0],
                PROPAGATION,
                f"passed to {fname}() as '{record.param}'",
                call_step_tpl[1],
            )
            for path in taint.paths:
                new_path = path.extend(step)
                for s in record.steps_after_param:
                    new_path = new_path.extend(s)
                if path.is_source:
                    self.a.add_evidence(
                        record.kind,
                        record.sink_name,
                        record.node,
                        record.stmt,
                        new_path,
                        taint.sanitized | record.sanitized,
                        record.flags,
                        record.variable,
                    )
                elif self.summary is not None:
                    self.summary.param_sinks.append(
                        replace(
                            record,
                            param=path.origin.split(":", 1)[1],
                            steps_after_param=new_path.steps[1:],
                        )
                    )

        # Return value
        result = None
        if summary.returns_source is not None:
            ret_step = TraceStep(
                node.lineno, PROPAGATION, f"returned from {fname}()", node.col_offset
            )
            result = combine(result, summary.returns_source.extend(ret_step))
        for param, (steps, sanitized, html) in summary.returns_params.items():
            taint = bound.get(param)
            if taint is None:
                continue
            step = TraceStep(
                node.lineno,
                PROPAGATION,
                f"passed through {fname}() via '{param}'",
                node.col_offset,
            )
            extended = taint
            for s in steps:
                extended = extended.extend(s)
            extended = extended.extend(step).with_sanitized(sanitized)
            if html:
                extended = extended.with_flags(html=True)
            result = combine(result, extended)
        return result

    # ----- sinks -----------------------------------------------------

    def check_sinks(self, node, name, method, receiver_taint, arg_taints, kw_taints):
        def arg(index, *keywords):
            if len(node.args) > index and not isinstance(node.args[index], ast.Starred):
                return node.args[index], arg_taints[index]
            for kw in node.keywords:
                if kw.arg in keywords:
                    return kw.value, kw_taints.get(kw.arg)
            return None, None

        # CWE-78 OS command injection
        if name in rules.SHELL_SINKS:
            expr, taint = arg(0, "cmd", "command")
            self.maybe_report(KIND_OS_COMMAND, name + "()", node, expr, taint,
                              {"shell": "implicit"})
        elif name in rules.SUBPROCESS_SINKS:
            shell = None
            for kw in node.keywords:
                if kw.arg == "shell":
                    shell = kw.value
            if shell is not None and not (
                isinstance(shell, ast.Constant) and not shell.value
            ):
                expr, taint = arg(0, "args")
                flags = {
                    "shell": "true"
                    if isinstance(shell, ast.Constant) and shell.value is True
                    else "dynamic"
                }
                self.maybe_report(KIND_OS_COMMAND, name + "(shell=True)", node,
                                  expr, taint, flags)

        # CWE-89 SQL injection
        if method in rules.SQL_METHODS or name in rules.SQL_FUNCTIONS:
            expr, taint = arg(0, "sql", "operation", "query")
            has_params = len(node.args) > 1 or any(
                k.arg in ("parameters", "params", "args") for k in node.keywords
            )
            label = (f".{method}()" if method in rules.SQL_METHODS else name + "()")
            self.maybe_report(KIND_SQL_QUERY, label, node, expr, taint,
                              {"has_params": has_params})

        # CWE-22 path traversal
        if name in rules.FILE_SINKS:
            expr, taint = arg(0, "file", "path", "filename", "path_or_file")
            self.maybe_report(KIND_FILE_PATH, name + "()", node, expr, taint, {})
            if name in ("shutil.copy", "shutil.copyfile", "shutil.move"):
                expr, taint = arg(1, "dst")
                self.maybe_report(KIND_FILE_PATH, name + "()", node, expr, taint, {})
        elif (
            method in rules.PATH_SINK_METHODS
            and receiver_taint is not None
            and isinstance(node.func, ast.Attribute)
            and self.is_path_object(node.func.value)
        ):
            self.maybe_report(KIND_FILE_PATH, f"Path.{method}()", node,
                              node.func.value, receiver_taint, {})

        # CWE-79 XSS
        if name in rules.HTML_SINKS:
            expr, taint = arg(0, "response", "source", "content")
            self.maybe_report(KIND_HTML_OUTPUT, name.split(".")[-1] + "()", node,
                              expr, taint, {"route_return": False})

    def is_path_object(self, node):
        if isinstance(node, ast.Call):
            return (self.a.resolve(node.func) or "") in rules.PATH_CONSTRUCTORS
        if isinstance(node, ast.Name):
            return True  # a variable we cannot type; accept when tainted
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Div):
            return True
        return False

    def maybe_report(self, kind, sink_name, node, expr, taint, flags):
        if expr is None or taint is None:
            return
        variable = expr.id if isinstance(expr, ast.Name) else first_name(expr)
        self.report(kind, sink_name, node, taint, flags, variable)

    def report(self, kind, sink_name, node, taint, flags, variable):
        cwe = rules.KIND_TO_CWE[kind]
        if cwe in taint.sanitized:
            return
        flags = dict(flags)
        flags["normalized"] = taint.normalized
        stmt = self.stmt
        for path in taint.paths:
            if path.is_source:
                self.a.add_evidence(kind, sink_name, node, stmt, path,
                                    taint.sanitized, flags, variable)
                break
        if self.summary is not None:
            for path in taint.param_paths:
                param = path.origin.split(":", 1)[1]
                if any(
                    r.param == param and r.node is node for r in self.summary.param_sinks
                ):
                    continue
                self.summary.param_sinks.append(
                    SinkRecord(
                        param=param,
                        kind=kind,
                        sink_name=sink_name,
                        node=node,
                        stmt=stmt,
                        steps_after_param=path.steps[1:],
                        sanitized=taint.sanitized,
                        flags=flags,
                        variable=variable,
                    )
                )

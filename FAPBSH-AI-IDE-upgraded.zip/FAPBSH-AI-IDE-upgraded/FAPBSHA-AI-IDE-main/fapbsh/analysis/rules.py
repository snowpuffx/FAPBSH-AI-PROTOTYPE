"""Source, sink and sanitizer tables for the five supported CWEs.

Names are fully qualified after import-alias resolution, e.g.
``from subprocess import run as r`` makes ``r(...)`` resolve to
``subprocess.run``. A handful of names are also accepted unqualified
(``request.args``, ``make_response`` ...) because web frameworks are often
used without the analyzer being able to see the import.
"""

from fapbsh.analysis.models import (
    KIND_FILE_PATH,
    KIND_HTML_OUTPUT,
    KIND_OS_COMMAND,
    KIND_SQL_QUERY,
)

ALL_CWES = frozenset({"CWE-79", "CWE-78", "CWE-22", "CWE-89", "CWE-798"})

KIND_TO_CWE = {
    KIND_OS_COMMAND: "CWE-78",
    KIND_SQL_QUERY: "CWE-89",
    KIND_FILE_PATH: "CWE-22",
    KIND_HTML_OUTPUT: "CWE-79",
}

# ---------------------------------------------------------------------------
# Sources
# ---------------------------------------------------------------------------

# Calls whose return value is attacker-controlled.
SOURCE_CALLS = {
    "input": "user input (input())",
    "raw_input": "user input (raw_input())",
    "os.getenv": "environment variable (os.getenv)",
    "os.environ.get": "environment variable (os.environ.get)",
    "sys.stdin.read": "standard input (sys.stdin.read)",
    "sys.stdin.readline": "standard input (sys.stdin.readline)",
    "sys.stdin.readlines": "standard input (sys.stdin.readlines)",
}

# Attribute accesses that are attacker-controlled (and anything read from
# them, e.g. request.args.get("q") or sys.argv[1]).
SOURCE_ATTRIBUTES = {
    "sys.argv": "command-line argument (sys.argv)",
    "os.environ": "environment variable (os.environ)",
    "flask.request.args": "HTTP query parameter (request.args)",
    "flask.request.form": "HTTP form field (request.form)",
    "flask.request.values": "HTTP request value (request.values)",
    "request.args": "HTTP query parameter (request.args)",
    "request.form": "HTTP form field (request.form)",
    "request.values": "HTTP request value (request.values)",
}

# Calls that open a file: the handle (and anything read from it) is a
# "file read" source.
FILE_OPEN_CALLS = {"open", "io.open", "codecs.open"}
FILE_READ_METHODS = {"read", "readline", "readlines"}
PATH_READ_METHODS = {"read_text", "read_bytes"}

# ---------------------------------------------------------------------------
# Sinks
# ---------------------------------------------------------------------------

# Always dangerous with a tainted first argument (they use a shell).
SHELL_SINKS = {
    "os.system",
    "os.popen",
    "subprocess.getoutput",
    "subprocess.getstatusoutput",
    "commands.getoutput",
}

# Dangerous only when called with shell=True.
SUBPROCESS_SINKS = {
    "subprocess.run",
    "subprocess.call",
    "subprocess.check_call",
    "subprocess.check_output",
    "subprocess.Popen",
}

SQL_METHODS = {"execute", "executemany", "executescript"}
SQL_FUNCTIONS = {
    "pandas.read_sql",
    "pandas.read_sql_query",
    "sqlalchemy.text",
}

FILE_SINKS = {
    "open": 0,
    "io.open": 0,
    "codecs.open": 0,
    "os.open": 0,
    "os.remove": 0,
    "os.unlink": 0,
    "os.rmdir": 0,
    "os.listdir": 0,
    "shutil.rmtree": 0,
    "shutil.copy": 0,
    "shutil.copyfile": 0,
    "shutil.move": 0,
    "flask.send_file": 0,
    "send_file": 0,
}
PATH_CONSTRUCTORS = {"pathlib.Path", "pathlib.PurePath", "Path"}
PATH_SINK_METHODS = {
    "open",
    "read_text",
    "read_bytes",
    "write_text",
    "write_bytes",
    "unlink",
    "rmdir",
}

HTML_SINKS = {
    "flask.make_response",
    "flask.render_template_string",
    "flask.Markup",
    "markupsafe.Markup",
    "jinja2.Markup",
    "django.http.HttpResponse",
    "django.utils.safestring.mark_safe",
    # unqualified fall-backs
    "make_response",
    "render_template_string",
    "Markup",
    "HttpResponse",
    "mark_safe",
}

# Decorators that mark a function as an HTTP route handler.
ROUTE_DECORATOR_ATTRS = {"route", "get", "post", "put", "delete", "patch"}

# ---------------------------------------------------------------------------
# Sanitizers: callee -> set of CWEs whose taint they remove
# ---------------------------------------------------------------------------

SANITIZERS = {
    "shlex.quote": {"CWE-78"},
    "pipes.quote": {"CWE-78"},
    "html.escape": {"CWE-79"},
    "markupsafe.escape": {"CWE-79"},
    "flask.escape": {"CWE-79"},
    "cgi.escape": {"CWE-79"},
    "bleach.clean": {"CWE-79"},
    "django.utils.html.escape": {"CWE-79"},
    "escape": {"CWE-79"},
    "os.path.basename": {"CWE-22"},
    "werkzeug.utils.secure_filename": {"CWE-22"},
    "secure_filename": {"CWE-22"},
    # Type conversions make the value non-injectable for every category.
    "int": set(ALL_CWES),
    "float": set(ALL_CWES),
    "bool": set(ALL_CWES),
    "len": set(ALL_CWES),
    "abs": set(ALL_CWES),
    "round": set(ALL_CWES),
    "uuid.UUID": set(ALL_CWES),
}

# Calls that canonicalise a path. A canonical path that is then checked
# with a containment test (commonpath / startswith / is_relative_to) is
# treated as sanitized for CWE-22.
PATH_NORMALIZERS = {
    "os.path.realpath",
    "os.path.abspath",
    "os.path.normpath",
}
PATH_NORMALIZER_METHODS = {"resolve", "absolute"}
CONTAINMENT_FUNCS = {"os.path.commonpath", "os.path.commonprefix"}
CONTAINMENT_METHODS = {"startswith", "is_relative_to"}

# Calls whose result keeps the taint of their arguments.
PROPAGATING_PATH_CALLS = {"os.path.join", "posixpath.join", "ntpath.join"}

"""CWE-798 hard-coded credential detection.

A string literal is reported when it is bound to a credential-like name
(assignment, keyword argument, dict key, or comparison) or when it matches
a well-known key format. Obvious placeholders are filtered out and kept as
suppressed candidates so the decision is visible.
"""

from __future__ import annotations

import ast
import math
import re

from fapbsh.analysis.models import (
    KIND_HARDCODED_SECRET,
    SINK,
    SOURCE,
    Evidence,
    SuppressedCandidate,
    TraceStep,
)

SECRET_NAME = re.compile(
    r"(pass(word|wd|phrase)?|pwd|secret|token|api_?key|apikey|access_?key|"
    r"private_?key|auth_?key|client_?secret|credential|db_?pass|conn(ection)?_?str)",
    re.IGNORECASE,
)

# Names that look like credentials but usually are not.
NON_SECRET_NAME = re.compile(
    r"(_url$|_uri$|_path$|_file$|_dir$|_field$|_name$|_label$|_prompt$|_len(gth)?$|"
    r"_header$|_type$|_id$|^token_type$|_regex$|_pattern$|_msg$|_message$|_hint$)",
    re.IGNORECASE,
)

TEST_NAME = re.compile(
    r"(^|_)(test|tests|fake|dummy|mock|sample|example|placeholder)(_|$)",
    re.IGNORECASE,
)

KNOWN_KEY_FORMATS = [
    (re.compile(r"^AKIA[0-9A-Z]{16}$"), "AWS access key ID"),
    (re.compile(r"^gh[pousr]_[A-Za-z0-9]{36,}$"), "GitHub token"),
    (re.compile(r"^xox[baprs]-[A-Za-z0-9-]{10,}$"), "Slack token"),
    (re.compile(r"^sk-[A-Za-z0-9_-]{20,}$"), "API secret key"),
    (re.compile(r"^AIza[0-9A-Za-z_-]{35}$"), "Google API key"),
    (re.compile(r"-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----"), "private key"),
]

PLACEHOLDER_EXACT = {
    "",
    "changeme",
    "change_me",
    "change-me",
    "password",
    "passwd",
    "secret",
    "token",
    "apikey",
    "api_key",
    "example",
    "test",
    "testing",
    "dummy",
    "fake",
    "none",
    "null",
    "todo",
    "tbd",
    "xxx",
    "xxxx",
    "default",
    "redacted",
    "placeholder",
    "your-password",
    "your_password",
}

PLACEHOLDER_PATTERN = re.compile(
    r"(^your[_\- ]|[_\- ]here$|^<.*>$|^\{\{.*\}\}$|^\$\{.*\}$|^%\(.*\)s$|"
    r"example|placeholder|changeme|change_me|replace[_\- ]?me|dummy|^x+$|^\*+$|"
    r"^\.\.\.$|insert[_\- ]|^enter[_\- ]|^my[_\- ]?(api|secret|token|pass))",
    re.IGNORECASE,
)


def shannon_entropy(value):
    if not value:
        return 0.0
    counts = {}
    for ch in value:
        counts[ch] = counts.get(ch, 0) + 1
    length = len(value)
    return -sum((c / length) * math.log2(c / length) for c in counts.values())


def placeholder_reason(name, value):
    """Return why a candidate is a placeholder, or None if it looks real."""
    stripped = value.strip()
    if not stripped:
        return "empty string"
    if stripped.lower() in PLACEHOLDER_EXACT:
        return f"placeholder value '{stripped}'"
    if PLACEHOLDER_PATTERN.search(stripped):
        return f"placeholder pattern in '{stripped}'"
    if len(set(stripped)) == 1:
        return "repeated single character"
    if name and TEST_NAME.search(name):
        return f"test-named variable '{name}'"
    if len(stripped) < 4:
        return "too short to be a credential"
    return None


def known_format(value):
    for pattern, label in KNOWN_KEY_FORMATS:
        if pattern.search(value):
            return label
    return None


def _name_of(node):
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return node.attr
    if isinstance(node, ast.Subscript):
        key = node.slice
        if isinstance(key, ast.Constant) and isinstance(key.value, str):
            return key.value
    return None


def _is_secret_name(name):
    return bool(
        name
        and SECRET_NAME.search(name)
        and not NON_SECRET_NAME.search(name)
    )


class SecretDetector(ast.NodeVisitor):

    def __init__(self, source_lines, filename):
        self.lines = source_lines
        self.filename = filename
        self.evidence = []
        self.suppressed = []
        self._seen = set()
        self._tree = None

    def run(self, tree):
        self._tree = tree
        self.visit(tree)
        return self.evidence, self.suppressed

    # --- visitors --------------------------------------------------

    def visit_Assign(self, node):
        for target in node.targets:
            self._candidate(_name_of(target), node.value, node, binding=target)
        self.generic_visit(node)

    def visit_AnnAssign(self, node):
        if node.value is not None:
            self._candidate(_name_of(node.target), node.value, node,
                            binding=node.target)
        self.generic_visit(node)

    def visit_Call(self, node):
        for kw in node.keywords:
            if kw.arg:
                self._candidate(kw.arg, kw.value, kw, context="keyword")
        self.generic_visit(node)

    def visit_Dict(self, node):
        for key, value in zip(node.keys, node.values):
            if isinstance(key, ast.Constant) and isinstance(key.value, str):
                self._candidate(key.value, value, value, context="dict")
        self.generic_visit(node)

    def visit_Compare(self, node):
        if len(node.comparators) == 1 and isinstance(node.ops[0], (ast.Eq, ast.NotEq)):
            left, right = node.left, node.comparators[0]
            for name_node, value in ((left, right), (right, left)):
                name = _name_of(name_node)
                if name and isinstance(value, ast.Constant):
                    self._candidate(name, value, node, context="comparison")
        self.generic_visit(node)

    def visit_Constant(self, node):
        # Known key formats are reported even without a telling name.
        if isinstance(node.value, str):
            label = known_format(node.value)
            if label:
                self._report(None, node, node, label=label, name_match=False)

    # --- core ------------------------------------------------------

    def _candidate(self, name, value, anchor, binding=None, context="assignment"):
        if not isinstance(value, ast.Constant) or not isinstance(value.value, str):
            return
        label = known_format(value.value)
        if label and not (name and TEST_NAME.search(name)):
            self._report(name, value, anchor, binding=binding, context=context,
                         label=label, name_match=_is_secret_name(name))
            return
        if not _is_secret_name(name):
            return
        reason = placeholder_reason(name, value.value)
        line_text = self._line(value.lineno).strip()
        if reason is None and known_format(value.value) is None:
            # Ordinary words / prompts are not secrets ("Enter password: ")
            if " " in value.value.strip() and len(value.value.split()) > 2:
                reason = "looks like prose, not a credential"
        if reason:
            key = (value.lineno, value.col_offset)
            if key not in self._seen:
                self._seen.add(key)
                self.suppressed.append(
                    SuppressedCandidate(value.lineno, reason, line_text)
                )
            return
        self._report(name, value, anchor, binding=binding, context=context,
                     label=known_format(value.value), name_match=True)

    def _report(self, name, value, anchor, binding=None, context="assignment",
                label=None, name_match=True):
        key = (value.lineno, value.col_offset)
        if key in self._seen:
            return
        self._seen.add(key)
        if label is None and not name_match:
            return
        if binding is None and context == "assignment":
            context = "literal"
        literal = value.value
        steps = [
            TraceStep(
                value.lineno,
                SOURCE,
                f"hard-coded literal assigned to '{name}'" if name
                else f"hard-coded {label}",
                value.col_offset,
            )
        ]
        use_line = self._first_use(name, value.lineno) if binding is not None else None
        if use_line:
            steps.append(TraceStep(use_line, SINK, f"'{name}' used here", 0))
        else:
            steps.append(
                TraceStep(value.lineno, SINK, "credential embedded in source",
                          value.col_offset)
            )
        self.evidence.append(
            Evidence(
                kind=KIND_HARDCODED_SECRET,
                file=self.filename,
                line=value.lineno,
                column=value.col_offset,
                end_line=value.end_lineno or value.lineno,
                end_column=value.end_col_offset or value.col_offset,
                snippet=self._line(value.lineno).strip(),
                sink_name=context,
                variable=name or "",
                trace=steps,
                source_kinds=["string literal"],
                flags={
                    "name_match": name_match,
                    "known_format": label,
                    "entropy": round(shannon_entropy(literal), 2),
                    "length": len(literal),
                    "context": context,
                    "literal": literal,
                },
                stmt_line=getattr(anchor, "lineno", value.lineno),
                stmt_col=getattr(anchor, "col_offset", value.col_offset),
            )
        )

    def _first_use(self, name, after_line):
        if not name:
            return None
        best = None
        for node in ast.walk(self._tree):
            if (
                isinstance(node, (ast.Name, ast.Attribute))
                and isinstance(getattr(node, "ctx", None), ast.Load)
                and _name_of(node) == name
                and node.lineno > after_line
            ):
                if best is None or node.lineno < best:
                    best = node.lineno
        return best

    def _line(self, line):
        if 1 <= line <= len(self.lines):
            return self.lines[line - 1].rstrip("\n")
        return ""

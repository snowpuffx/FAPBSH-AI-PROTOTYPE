"""Public entry points of the analysis engine (no Qt)."""

from __future__ import annotations

import ast
from pathlib import Path

from fapbsh.analysis.models import AnalysisResult, Finding, make_finding_id
from fapbsh.analysis.secrets import SecretDetector
from fapbsh.analysis.taint import TaintAnalyzer

SUMMARY_TEXT = {
    "CWE-78": "Untrusted data '{var}' reaches a shell command ({sink}).",
    "CWE-89": "Untrusted data '{var}' is built into an SQL query ({sink}).",
    "CWE-22": "Untrusted data '{var}' controls a file path ({sink}).",
    "CWE-79": "Untrusted data '{var}' is written into HTML output ({sink}).",
    "CWE-798": "Credential {var} is hard-coded as a string literal.",
}


def _default_classifier():
    from fapbsh.classification.rule_based import RuleBasedClassifier

    return RuleBasedClassifier()


def analyze_source(code, filename="<editor>", classifier=None):
    """Analyze Python source text and return an AnalysisResult."""
    classifier = classifier or _default_classifier()
    result = AnalysisResult(file=filename)
    try:
        tree = ast.parse(code, filename=filename)
    except SyntaxError as error:
        result.errors.append(f"SyntaxError: {error.msg} (line {error.lineno})")
        return result

    lines = code.splitlines()
    evidence = []
    evidence.extend(TaintAnalyzer(tree, lines, filename).run())
    secret_evidence, suppressed = SecretDetector(lines, filename).run(tree)
    evidence.extend(secret_evidence)
    result.suppressed = suppressed

    for ev in evidence:
        label = classifier.classify(ev)
        if label is None:
            continue
        finding = Finding(
            id=make_finding_id(filename, label.cwe, ev.line, ev.column, ev.variable),
            cwe=label.cwe,
            name=label.name,
            severity=label.severity,
            file=filename,
            line=ev.line,
            column=ev.column + 1,
            end_line=ev.end_line,
            end_column=ev.end_column + 1,
            snippet=ev.snippet,
            confidence=label.confidence,
            trace=list(ev.trace),
            message=SUMMARY_TEXT[label.cwe].format(
                var=(
                    f"'{ev.variable}'" if label.cwe == "CWE-798" and ev.variable
                    else ("value" if label.cwe == "CWE-798" else ev.variable or "value")
                ),
                sink=ev.sink_name,
            ),
            variable=ev.variable,
            classifier=getattr(classifier, "name", type(classifier).__name__),
            rationale=list(label.rationale),
            evidence=ev,
        )
        result.findings.append(finding)

    severity_rank = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3}
    result.findings.sort(key=lambda f: (severity_rank.get(f.severity, 9), f.line, f.column))
    return result


def analyze_file(path, classifier=None):
    path = Path(path)
    code = path.read_text(encoding="utf-8")
    return analyze_source(code, str(path), classifier=classifier)

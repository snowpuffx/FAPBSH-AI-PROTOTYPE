"""Classifier interface.

The analysis engine produces :class:`~fapbsh.analysis.models.Evidence`;
a Classifier turns each piece of evidence into a CWE, a severity and a
confidence. The UI never talks to a classifier directly, it only sees the
resulting Findings, so a different classifier (for example one backed by
a local model) can be plugged into ``analyze_source(..., classifier=...)``
without touching any UI code.

A classifier's output is an *opinion*. It is never used as remediation
verification evidence.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional

SEVERITIES = ("Critical", "High", "Medium", "Low")

CWE_NAMES = {
    "CWE-79": "Cross-site Scripting (XSS)",
    "CWE-798": "Hard-coded Credentials",
    "CWE-78": "OS Command Injection",
    "CWE-22": "Path Traversal",
    "CWE-89": "SQL Injection",
}


@dataclass
class Classification:
    cwe: str
    name: str
    severity: str
    confidence: float  # 0.0 - 1.0
    rationale: list = field(default_factory=list)


class Classifier(ABC):
    """Assigns CWE, severity and confidence from analysis evidence."""

    #: Short identifier shown in the Explanation tab.
    name = "classifier"

    @abstractmethod
    def classify(self, evidence) -> Optional[Classification]:
        """Return a Classification, or None to drop the evidence."""
        raise NotImplementedError

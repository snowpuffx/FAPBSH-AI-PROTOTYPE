"""Deterministic, rule-based classifier."""

from __future__ import annotations

from fapbsh.analysis.models import (
    KIND_FILE_PATH,
    KIND_HARDCODED_SECRET,
    KIND_HTML_OUTPUT,
    KIND_OS_COMMAND,
    KIND_SQL_QUERY,
)
from fapbsh.classification.base import CWE_NAMES, Classification, Classifier

KIND_RULES = {
    KIND_OS_COMMAND: ("CWE-78", "Critical"),
    KIND_SQL_QUERY: ("CWE-89", "High"),
    KIND_FILE_PATH: ("CWE-22", "High"),
    KIND_HTML_OUTPUT: ("CWE-79", "Medium"),
    KIND_HARDCODED_SECRET: ("CWE-798", "High"),
}

DIRECT_USER_INPUT = ("user input", "HTTP", "command-line", "URL route", "standard input")


def _clamp(value):
    return round(max(0.05, min(0.99, value)), 2)


class RuleBasedClassifier(Classifier):

    name = "rule-based v1"

    def classify(self, evidence):
        rule = KIND_RULES.get(evidence.kind)
        if rule is None:
            return None
        cwe, severity = rule
        rationale = [f"Sink category '{evidence.kind}' maps to {cwe}."]
        if evidence.kind == KIND_HARDCODED_SECRET:
            confidence, severity = self._secret(evidence, rationale)
        else:
            confidence, severity = self._taint(evidence, severity, rationale)
        return Classification(
            cwe=cwe,
            name=CWE_NAMES[cwe],
            severity=severity,
            confidence=_clamp(confidence),
            rationale=rationale,
        )

    # ------------------------------------------------------------------

    def _taint(self, ev, severity, rationale):
        confidence = 0.7
        sources = " ".join(ev.source_kinds)
        if any(marker in sources for marker in DIRECT_USER_INPUT):
            confidence += 0.15
            rationale.append(f"Source is direct external input: {sources}.")
        elif "environment" in sources:
            confidence -= 0.15
            severity = _lower(severity)
            rationale.append("Source is an environment variable (attacker control is less likely).")
        elif "file contents" in sources:
            confidence -= 0.1
            rationale.append("Source is file contents (depends on who controls the file).")

        hops = sum(1 for s in ev.trace if s.role == "propagation")
        if hops > 3:
            confidence -= 0.05 * (hops - 3)
            rationale.append(f"Long propagation chain ({hops} steps) lowers certainty.")

        if ev.sanitizers_seen:
            rationale.append(
                "Sanitizers for other categories were applied: "
                + ", ".join(ev.sanitizers_seen) + "."
            )

        flags = ev.flags
        if ev.kind == KIND_OS_COMMAND:
            if flags.get("shell") == "dynamic":
                confidence -= 0.2
                rationale.append("shell= is not a literal True, so a shell may not be used.")
            else:
                rationale.append("The command is run through a shell.")
        if ev.kind == KIND_SQL_QUERY and flags.get("has_params"):
            confidence -= 0.1
            rationale.append("Parameters are passed, but the query text itself is still tainted.")
        if ev.kind == KIND_FILE_PATH and flags.get("normalized"):
            confidence -= 0.1
            rationale.append("The path is normalised but never checked for containment.")
        if ev.kind == KIND_HTML_OUTPUT and flags.get("route_return"):
            rationale.append("Tainted data is returned inside HTML from a route handler.")
        return confidence, severity

    def _secret(self, ev, rationale):
        flags = ev.flags
        severity = "High"
        if flags.get("known_format"):
            rationale.append(f"Literal matches the format of a {flags['known_format']}.")
            return 0.95, "Critical"
        confidence = 0.6
        entropy = flags.get("entropy", 0)
        length = flags.get("length", 0)
        rationale.append(f"Credential-like name '{ev.variable}' bound to a string literal.")
        if entropy >= 3.5 and length >= 12:
            confidence += 0.25
            rationale.append(f"High-entropy value (entropy {entropy}, length {length}).")
        elif entropy >= 2.5:
            confidence += 0.1
            rationale.append(f"Moderate entropy ({entropy}).")
        else:
            confidence -= 0.1
            severity = "Medium"
            rationale.append(f"Low entropy ({entropy}); could be a weak real password.")
        if flags.get("context") == "comparison":
            rationale.append("The literal is compared against input (hard-coded check).")
        return confidence, severity


def _lower(severity):
    order = ["Critical", "High", "Medium", "Low"]
    index = order.index(severity)
    return order[min(index + 1, len(order) - 1)]

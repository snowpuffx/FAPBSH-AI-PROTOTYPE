"""Runs the five checks in order and computes the verdict.

Verdict rules
-------------
* Not resolved      - syntax fails, or the data-flow re-check or the
                      security test cases still show the vulnerability.
* Partially resolved- the vulnerability is gone by data-flow and payloads,
                      but Bandit/Semgrep or the functional tests fail.
* Inconclusive      - nothing failed, but neither independent check
                      (Bandit/Semgrep, security test cases) could run.
* Resolved          - every available check passed and none failed.

A classifier or model opinion is never one of the checks.
"""

from __future__ import annotations

import shutil
import tempfile
from dataclasses import dataclass, field

from fapbsh.verification import checks
from fapbsh.verification.checks import (
    CHECK_NAMES,
    FAILED,
    PASSED,
    PENDING,
    RUNNING,
    UNAVAILABLE,
    CheckResult,
)

RESOLVED = "Resolved"
PARTIAL = "Partially resolved"
NOT_RESOLVED = "Not resolved"
INCONCLUSIVE = "Inconclusive"


@dataclass
class VerificationReport:
    finding_id: str
    checks: list = field(default_factory=list)
    verdict: str = INCONCLUSIVE
    reason: str = ""
    notes: list = field(default_factory=list)


def compute_verdict(results):
    by_name = {r.name: r.status for r in results}
    syntax, dataflow, tools, security, functional = (
        by_name.get(n, UNAVAILABLE) for n in CHECK_NAMES
    )
    available = [r for r in results if r.status in (PASSED, FAILED)]
    if syntax == FAILED:
        return NOT_RESOLVED, "The corrected code does not compile."
    if dataflow == FAILED:
        return NOT_RESOLVED, "The data-flow re-check still finds the tainted path."
    if security == FAILED:
        return NOT_RESOLVED, "Attack payloads still reach the sink in the corrected code."
    failed = [r.name for r in results if r.status == FAILED]
    if failed:
        return PARTIAL, "Vulnerable path removed, but failed: " + ", ".join(failed) + "."
    if tools == UNAVAILABLE and security == UNAVAILABLE:
        return INCONCLUSIVE, (
            "No independent check (Bandit/Semgrep or security tests) could run, "
            "so the fix cannot be confirmed."
        )
    unavailable = len(results) - len(available)
    reason = f"All {len(available)} available checks passed"
    if unavailable:
        reason += f" ({unavailable} unavailable)"
    return RESOLVED, reason + "."


class Verifier:
    """Runs verification for one finding and its proposed correction."""

    def __init__(self, project_dir=None):
        self.project_dir = project_dir

    def run(self, original, corrected, finding, progress=None):
        report = VerificationReport(finding_id=finding.id)
        results = [CheckResult(name, PENDING) for name in CHECK_NAMES]
        workdir = tempfile.mkdtemp(prefix="fapbsh_verify_")

        def emit(index, result):
            results[index] = result
            if progress is not None:
                progress(index, result)

        try:
            steps = [
                lambda: checks.check_syntax(corrected, finding.file or "<editor>"),
                lambda: checks.check_dataflow(original, corrected, finding),
                lambda: checks.check_tools(original, corrected, finding, workdir),
                lambda: checks.check_security(original, corrected, finding, workdir),
                lambda: checks.check_functional(
                    original, corrected, finding, self.project_dir, workdir
                ),
            ]
            syntax_ok = True
            for index, step in enumerate(steps):
                if not syntax_ok:
                    emit(index, CheckResult(
                        CHECK_NAMES[index], UNAVAILABLE,
                        "Skipped because the corrected code does not compile.",
                    ))
                    continue
                emit(index, CheckResult(CHECK_NAMES[index], RUNNING, "Running…"))
                try:
                    result = step()
                except Exception as error:  # noqa: BLE001 - surface, never pass
                    result = CheckResult(
                        CHECK_NAMES[index], UNAVAILABLE,
                        f"Check crashed: {type(error).__name__}: {error}",
                    )
                emit(index, result)
                if index == 0 and result.status == FAILED:
                    syntax_ok = False
        finally:
            shutil.rmtree(workdir, ignore_errors=True)

        report.checks = results
        report.verdict, report.reason = compute_verdict(results)
        report.notes = [
            "Verification is based only on the checks above; the classifier's "
            "confidence is not counted as evidence.",
        ]
        for result in results:
            if result.status == UNAVAILABLE:
                report.notes.append(f"{result.name}: {result.detail}")
        return report

"""Isolated execution harness for security test cases and smoke runs.

This file is executed as a *separate process*:

    python -I harness.py <target.py> <mode> <payload>

mode is "payload" or "smoke". Dangerous sinks (shell, SQL, file system,
HTML responses) are replaced with recorders BEFORE the target runs, so no
command is executed, no database is touched and no file outside the
target is read. Sources (input(), sys.argv, Flask request data) return the
payload. The result is printed as one JSON line prefixed with MARK.

It deliberately imports nothing from the fapbsh package.
"""

import builtins
import html as _html
import inspect
import io
import json
import os
import pathlib
import runpy
import shutil
import sqlite3
import subprocess
import sys
import types

MARK = "__FAPBSH_RESULT__"

target = os.path.abspath(sys.argv[1])
mode = sys.argv[2]
payload = sys.argv[3] if len(sys.argv) > 3 else ""

events = []
state = {"sources": 0, "blocked": 0, "errors": []}
_real_open = builtins.open
_real_stdout = sys.stdout


def from_target():
    frame = sys._getframe(2)
    while frame is not None:
        if os.path.abspath(frame.f_code.co_filename) == target:
            return True
        frame = frame.f_back
    return False


def target_line():
    frame = sys._getframe(1)
    while frame is not None:
        if os.path.abspath(frame.f_code.co_filename) == target:
            return frame.f_lineno
        frame = frame.f_back
    return None


def record(kind, value, **extra):
    item = {"kind": kind, "value": value, "line": target_line()}
    item.update(extra)
    events.append(item)


# ---------------------------------------------------------------- sources

def fake_input(prompt=""):
    if mode == "smoke":
        raise EOFError("no stdin during smoke run")
    state["sources"] += 1
    return payload


builtins.input = fake_input
sys.argv = [target] + ([payload] * 3 if mode == "payload" else [])
sys.stdin = io.StringIO(payload if mode == "payload" else "")


class PayloadDict(dict):

    def _hit(self):
        if mode == "payload":
            state["sources"] += 1
        return payload

    def get(self, key, default=None, type=None):
        return self._hit()

    def __getitem__(self, key):
        return self._hit()

    def getlist(self, key):
        return [self._hit()]

    def __contains__(self, key):
        return True


class AbortRequest(Exception):
    pass


# ---------------------------------------------------------------- sinks

class FakeCompleted:

    def __init__(self, args, text):
        self.args = args
        self.returncode = 0
        self.stdout = "" if text else b""
        self.stderr = "" if text else b""

    def check_returncode(self):
        return None


class FakePopen(FakeCompleted):

    def __init__(self, args, *a, **kw):
        _record_cmd(args, kw.get("shell", False))
        text = kw.get("text") or kw.get("universal_newlines")
        super().__init__(args, text)
        self.stdout = io.StringIO("") if text else io.BytesIO(b"")
        self.stderr = io.StringIO("") if text else io.BytesIO(b"")
        self.stdin = io.StringIO()
        self.pid = 0

    def communicate(self, *a, **kw):
        return ("", "")

    def wait(self, *a, **kw):
        return 0

    def poll(self):
        return 0

    def kill(self):
        return None

    terminate = kill

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


def _record_cmd(args, shell):
    if isinstance(args, (list, tuple)):
        value = [str(a) for a in args]
    else:
        value = str(args)
    record("cmd", value, shell=bool(shell))


def fake_run(args=None, *a, **kw):
    _record_cmd(args, kw.get("shell", False))
    return FakeCompleted(args, kw.get("text") or kw.get("universal_newlines"))


def fake_check_output(args=None, *a, **kw):
    _record_cmd(args, kw.get("shell", False))
    return "" if (kw.get("text") or kw.get("universal_newlines")) else b""


def fake_call(args=None, *a, **kw):
    _record_cmd(args, kw.get("shell", False))
    return 0


def fake_system(cmd):
    _record_cmd(cmd, True)
    return 0


def fake_popen(cmd, *a, **kw):
    _record_cmd(cmd, True)
    return io.StringIO("")


def fake_getoutput(cmd, *a, **kw):
    _record_cmd(cmd, True)
    return ""


def fake_getstatusoutput(cmd, *a, **kw):
    _record_cmd(cmd, True)
    return (0, "")


os.system = fake_system
os.popen = fake_popen
subprocess.run = fake_run
subprocess.call = fake_call
subprocess.check_call = fake_call
subprocess.check_output = fake_check_output
subprocess.Popen = FakePopen
subprocess.getoutput = fake_getoutput
subprocess.getstatusoutput = fake_getstatusoutput


class FakeCursor:

    rowcount = 0
    lastrowid = 0
    description = None

    def execute(self, query, params=None):
        record("sql", str(query), params=repr(params))
        return self

    def executemany(self, query, seq=()):
        record("sql", str(query), params="many")
        return self

    def executescript(self, script):
        record("sql", str(script), params=None)
        return self

    def fetchall(self):
        return []

    def fetchone(self):
        return None

    def fetchmany(self, *a):
        return []

    def close(self):
        return None

    def __iter__(self):
        return iter(())

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


class FakeConnection(FakeCursor):

    def cursor(self, *a, **kw):
        return FakeCursor()

    def commit(self):
        return None

    def rollback(self):
        return None


def fake_connect(*a, **kw):
    return FakeConnection()


sqlite3.connect = fake_connect
for db_module in ("psycopg2", "psycopg", "pymysql", "MySQLdb", "mysql.connector"):
    stub = types.ModuleType(db_module)
    stub.connect = fake_connect
    stub.Error = Exception
    sys.modules[db_module] = stub
sys.modules["mysql"] = types.ModuleType("mysql")
sys.modules["mysql"].connector = sys.modules["mysql.connector"]


def _record_path(path):
    try:
        resolved = os.path.realpath(os.fspath(path))
    except (TypeError, ValueError):
        resolved = str(path)
    record("file", str(path), resolved=resolved)


def fake_open(file, mode_="r", *a, **kw):
    if isinstance(file, int) or not from_target():
        return _real_open(file, mode_, *a, **kw)
    _record_path(file)
    if "b" in mode_:
        return io.BytesIO(b"")
    return io.StringIO("")


builtins.open = fake_open
io.open = fake_open


def _path_recorder(result):
    def method(self, *a, **kw):
        _record_path(self)
        return result() if callable(result) else result
    return method


pathlib.Path.open = _path_recorder(lambda: io.StringIO(""))
pathlib.Path.read_text = _path_recorder("")
pathlib.Path.read_bytes = _path_recorder(b"")
pathlib.Path.write_text = _path_recorder(0)
pathlib.Path.write_bytes = _path_recorder(0)
pathlib.Path.unlink = _path_recorder(None)
for name in ("remove", "unlink", "rmdir", "listdir"):
    setattr(os, name, lambda path, *a, **kw: (_record_path(path), [])[1])
shutil.rmtree = lambda path, *a, **kw: _record_path(path)
shutil.copy = shutil.copyfile = shutil.move = (
    lambda src, dst, *a, **kw: (_record_path(src), _record_path(dst), dst)[2]
)


# ---------------------------------------------------------------- web stubs

class Markup(str):

    def __new__(cls, value=""):
        record("html", str(value))
        return super().__new__(cls, value)


def escape(value):
    return str.__new__(Markup, _html.escape(str(value)))


ROUTES = []


class Anything:
    """Stand-in for framework objects the harness does not model
    (app.logger, app.config helpers, extensions...)."""

    def __getattr__(self, name):
        return self

    def __call__(self, *a, **kw):
        if len(a) == 1 and callable(a[0]) and not kw:
            return a[0]  # behave like a decorator
        return self

    def __iter__(self):
        return iter(())

    def __bool__(self):
        return False


class FakeFlask:

    def __init__(self, *a, **kw):
        self.config = {}

    def route(self, *a, **kw):
        def decorator(func):
            ROUTES.append(func)
            return func
        return decorator

    get = post = put = delete = patch = route

    def run(self, *a, **kw):
        return None

    def __getattr__(self, name):
        return Anything()


def make_response(body="", *a, **kw):
    record("html", str(body))
    return body


def render_template_string(source, **context):
    record("html", str(source))
    return source


def abort(*a, **kw):
    raise AbortRequest(str(a))


def send_file(path, *a, **kw):
    _record_path(path)
    return ""


flask = types.ModuleType("flask")
flask.Flask = FakeFlask
flask.request = types.SimpleNamespace(
    args=PayloadDict(), form=PayloadDict(), values=PayloadDict(),
    cookies=PayloadDict(), headers=PayloadDict(), method="GET",
)
flask.make_response = make_response
flask.render_template_string = render_template_string
flask.render_template = lambda name, **ctx: ""
flask.abort = abort
flask.send_file = send_file
flask.escape = escape
flask.Markup = Markup
flask.jsonify = lambda *a, **kw: json.dumps(a or kw, default=str)
flask.redirect = lambda location, *a, **kw: location
flask.url_for = lambda *a, **kw: "/"
flask.__getattr__ = lambda name: Anything()
sys.modules["flask"] = flask

markupsafe = types.ModuleType("markupsafe")
markupsafe.Markup = Markup
markupsafe.escape = escape
sys.modules["markupsafe"] = markupsafe

werkzeug = types.ModuleType("werkzeug")
werkzeug_utils = types.ModuleType("werkzeug.utils")
werkzeug_utils.secure_filename = lambda name: os.path.basename(str(name)).replace("..", "")
werkzeug.utils = werkzeug_utils
sys.modules["werkzeug"] = werkzeug
sys.modules["werkzeug.utils"] = werkzeug_utils


# ---------------------------------------------------------------- run

BLOCKING = (AbortRequest, ValueError, PermissionError)


def _call(func):
    try:
        sig = inspect.signature(func)
    except (TypeError, ValueError):
        return
    args = []
    for param in sig.parameters.values():
        if param.kind in (param.VAR_POSITIONAL, param.VAR_KEYWORD):
            continue
        if param.default is not param.empty:
            continue
        lowered = param.name.lower()
        if lowered in ("self", "cls"):
            return
        if lowered in ("conn", "connection", "db", "cursor", "cur", "con"):
            args.append(FakeConnection())
        else:
            if mode == "payload":
                state["sources"] += 1
            args.append(payload)
    try:
        result = func(*args)
        if func in ROUTES and result is not None:
            lines = [line for _, _, line in func.__code__.co_lines() if line]
            record("html", str(result),
                   func_range=[func.__code__.co_firstlineno, max(lines or [0])])
    except BLOCKING as error:
        state["blocked"] += 1
        state["errors"].append(f"{func.__name__}: blocked ({type(error).__name__})")
    except SystemExit:
        pass
    except Exception as error:  # noqa: BLE001 - report everything
        state["errors"].append(f"{func.__name__}: {type(error).__name__}: {error}")


def main():
    sys.stdout = io.StringIO()  # silence the program's own prints
    status = "ok"
    try:
        os.chdir(os.path.dirname(target))
        run_name = "__main__" if mode == "payload" else "__fapbsh_smoke__"
        namespace = runpy.run_path(target, run_name=run_name)
        if mode == "payload":
            for value in list(namespace.values()):
                if (
                    inspect.isfunction(value)
                    and os.path.abspath(value.__code__.co_filename) == target
                ):
                    _call(value)
    except BLOCKING as error:
        state["blocked"] += 1
        state["errors"].append(f"module: blocked ({type(error).__name__})")
    except SystemExit:
        pass
    except BaseException as error:  # noqa: BLE001
        status = "error"
        state["errors"].append(f"module: {type(error).__name__}: {error}")
    sys.stdout = _real_stdout
    print(MARK + json.dumps({
        "status": status,
        "events": events,
        "sources": state["sources"],
        "blocked": state["blocked"],
        "errors": state["errors"][:20],
    }, default=str))


if __name__ == "__main__":
    main()

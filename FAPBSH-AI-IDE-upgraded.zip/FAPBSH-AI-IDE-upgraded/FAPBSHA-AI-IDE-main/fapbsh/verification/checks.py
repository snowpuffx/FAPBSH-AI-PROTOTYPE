"""The five remediation-verification checks.

Each check returns a CheckResult with one of the statuses Passed, Failed or
Unavailable. A missing tool is always "Unavailable", never "Passed".
"""

from __future__ import annotations

import json
import os
import shlex
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

from fapbsh.analysis.engine import analyze_source

PASSED = "Passed"
FAILED = "Failed"
UNAVAILABLE = "Unavailable"
RUNNING = "Running"
PENDING = "Pending"

HERE = Path(__file__).resolve().parent
HARNESS = HERE / "harness.py"
SEMGREP_RULES = HERE / "semgrep_rules.yml"
MARK = "__FAPBSH_RESULT__"

TOOL_TIMEOUT = 120
HARNESS_TIMEOUT = 15
TEST_TIMEOUT = 180

PAYLOADS = {
    "CWE-78": ["; ls", "&& whoami", "| id", "$(id)"],
    "CWE-89": ["' OR '1'='1", "1; DROP TABLE users--"],
    "CWE-22": ["../../../../../../../../etc/passwd", "/etc/passwd"],
    "CWE-79": ["<script>alert(1)</script>", "\"><img src=x onerror=alert(1)>"],
}

EVENT_KIND = {"CWE-78": "cmd", "CWE-89": "sql", "CWE-22": "file", "CWE-79": "html"}

# Tool CWE ids that count for each of our categories
TOOL_CWES = {
    "CWE-78": {78},
    "CWE-89": {89},
    "CWE-22": {22, 23, 36},
    "CWE-79": {79, 80},
    "CWE-798": {798, 259, 321},
}
# Informational Bandit tests that only flag an import or a safe call
BANDIT_IGNORE = {"B404", "B403", "B410", "B603", "B607"}

CHECK_NAMES = [
    "Syntax validation",
    "Data-flow re-check",
    "Bandit and Semgrep CE scan",
    "Security test cases",
    "Functional tests",
]


@dataclass
class CheckResult:
    name: str
    status: str
    detail: str = ""
    log: list = field(default_factory=list)


def relevant_lines(original, corrected, finding):
    """Lines that belong to this finding: its trace lines in the original,
    and their counterparts plus every added line in the corrected code."""
    import difflib

    a, b = original.splitlines(), corrected.splitlines()
    mapping, added = {}, set()
    matcher = difflib.SequenceMatcher(None, a, b, autojunk=False)
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            for k in range(i2 - i1):
                mapping[i1 + k + 1] = j1 + k + 1
        if tag in ("replace", "insert"):
            added.update(range(j1 + 1, j2 + 1))
    orig_lines = {step.line for step in finding.trace} | {finding.line}
    corr_lines = {mapping[l] for l in orig_lines if l in mapping} | added
    return orig_lines, corr_lines


def _event_relevant(event, lines):
    line = event.get("line")
    if line is not None:
        return line in lines
    start, end = (event.get("func_range") or [0, -1])
    return any(start <= l <= end for l in lines)


def _python():
    return sys.executable


def _tool(name):
    found = shutil.which(name)
    if found:
        return found
    candidate = Path(sys.executable).parent / name
    if candidate.exists():
        return str(candidate)
    candidate = Path(sys.executable).parent / (name + ".exe")
    if candidate.exists():
        return str(candidate)
    return None


# ---------------------------------------------------------------------------
# 1. Syntax
# ---------------------------------------------------------------------------


def check_syntax(corrected, filename):
    try:
        compile(corrected, filename, "exec")
    except SyntaxError as error:
        return CheckResult(
            CHECK_NAMES[0], FAILED,
            f"SyntaxError on line {error.lineno}: {error.msg}",
        )
    return CheckResult(CHECK_NAMES[0], PASSED, "ast.parse and compile() succeeded.")


# ---------------------------------------------------------------------------
# 2. Data-flow re-check
# ---------------------------------------------------------------------------


def check_dataflow(original, corrected, finding):
    before = analyze_source(original, finding.file).findings
    after_result = analyze_source(corrected, finding.file)
    if after_result.errors:
        return CheckResult(CHECK_NAMES[1], FAILED, "; ".join(after_result.errors))
    after = after_result.findings
    same_before = sum(1 for f in before if f.cwe == finding.cwe)
    same_after = sum(1 for f in after if f.cwe == finding.cwe)
    others_before = {}
    for f in before:
        others_before[f.cwe] = others_before.get(f.cwe, 0) + 1
    new_issues = []
    counts_after = {}
    for f in after:
        counts_after[f.cwe] = counts_after.get(f.cwe, 0) + 1
    for cwe, count in counts_after.items():
        if cwe != finding.cwe and count > others_before.get(cwe, 0):
            new_issues.append(cwe)
    if same_after >= same_before:
        return CheckResult(
            CHECK_NAMES[1], FAILED,
            f"{finding.cwe} findings: {same_before} before, {same_after} after; "
            "the tainted path is still present.",
        )
    if new_issues:
        return CheckResult(
            CHECK_NAMES[1], FAILED,
            "The fix introduced new findings: " + ", ".join(sorted(new_issues)),
        )
    return CheckResult(
        CHECK_NAMES[1], PASSED,
        f"{finding.cwe} findings: {same_before} before, {same_after} after; "
        "no new findings.",
    )


# ---------------------------------------------------------------------------
# 3. Bandit and Semgrep
# ---------------------------------------------------------------------------


def _run_bandit(path):
    exe = _tool("bandit")
    if exe is None:
        return None, "Bandit not installed"
    try:
        proc = subprocess.run(
            [exe, "-f", "json", "-q", str(path)],
            capture_output=True, text=True, timeout=TOOL_TIMEOUT,
        )
        data = json.loads(proc.stdout or "{}")
    except (OSError, subprocess.TimeoutExpired, json.JSONDecodeError) as error:
        return None, f"Bandit failed to run ({type(error).__name__})"
    issues = []
    for item in data.get("results", []):
        if item.get("test_id") in BANDIT_IGNORE:
            continue
        cwe = (item.get("issue_cwe") or {}).get("id")
        issues.append((cwe, item.get("line_number"), item.get("test_id")))
    return issues, None


def _run_semgrep(path):
    exe = _tool("semgrep")
    if exe is None:
        return None, "Semgrep not installed"
    env = dict(os.environ)
    env.setdefault("SEMGREP_SEND_METRICS", "off")
    env.setdefault("SEMGREP_ENABLE_VERSION_CHECK", "0")
    try:
        proc = subprocess.run(
            [exe, "scan", "--config", str(SEMGREP_RULES), "--json",
             "--metrics=off", "--disable-version-check", "--quiet", str(path)],
            capture_output=True, text=True, timeout=TOOL_TIMEOUT, env=env,
        )
        data = json.loads(proc.stdout or "{}")
    except (OSError, subprocess.TimeoutExpired, json.JSONDecodeError) as error:
        return None, f"Semgrep failed to run ({type(error).__name__})"
    issues = []
    for item in data.get("results", []):
        cwe_text = str(item.get("extra", {}).get("metadata", {}).get("cwe", ""))
        try:
            cwe = int(cwe_text.split("-")[1])
        except (IndexError, ValueError):
            cwe = None
        issues.append((cwe, item.get("start", {}).get("line"), item.get("check_id")))
    return issues, None


def check_tools(original, corrected, finding, workdir):
    wanted = TOOL_CWES[finding.cwe]
    name = Path(finding.file).name if finding.file else "target.py"
    orig_path = Path(workdir) / "original" / name
    corr_path = Path(workdir) / "corrected" / name
    orig_path.parent.mkdir(parents=True, exist_ok=True)
    corr_path.parent.mkdir(parents=True, exist_ok=True)
    orig_path.write_text(original, encoding="utf-8")
    corr_path.write_text(corrected, encoding="utf-8")

    orig_lines, corr_lines = relevant_lines(original, corrected, finding)
    parts, failures, unavailable, log = [], [], [], []
    weak = True
    for label, runner in (("Bandit", _run_bandit), ("Semgrep", _run_semgrep)):
        before, err = runner(orig_path)
        after, err2 = (None, err) if before is None else runner(corr_path)
        if before is None or after is None:
            unavailable.append(f"{label}: {err or err2}")
            continue
        n_before = sum(1 for c, line, _ in before if c in wanted and line in orig_lines)
        n_after = sum(1 for c, line, _ in after if c in wanted and line in corr_lines)
        log.append(f"{label} original: {before}")
        log.append(f"{label} corrected: {after}")
        parts.append(f"{label} {n_before}→{n_after}")
        if n_before:
            weak = False
        if n_after:
            failures.append(
                f"{label} still reports {n_after} {finding.cwe} issue(s) on the fixed lines"
            )
    if not parts:
        return CheckResult(
            CHECK_NAMES[2], UNAVAILABLE, "; ".join(unavailable), log
        )
    detail = f"{finding.cwe} issues on the affected lines: " + ", ".join(parts)
    if unavailable:
        detail += " (" + "; ".join(unavailable) + ")"
    if failures:
        return CheckResult(CHECK_NAMES[2], FAILED, "; ".join(failures) + ". " + detail, log)
    if weak:
        detail += ". Note: the tools did not flag the original line either."
    return CheckResult(CHECK_NAMES[2], PASSED, detail, log)


# ---------------------------------------------------------------------------
# 4. Security test cases
# ---------------------------------------------------------------------------


def run_harness(code, filename, mode, payload, workdir):
    folder = Path(tempfile.mkdtemp(prefix="run_", dir=workdir))
    target = folder / (Path(filename).name if filename else "target.py")
    target.write_text(code, encoding="utf-8")
    env = {
        "PATH": os.environ.get("PATH", ""),
        "PYTHONIOENCODING": "utf-8",
        "SYSTEMROOT": os.environ.get("SYSTEMROOT", ""),
    }
    try:
        proc = subprocess.run(
            [_python(), "-I", str(HARNESS), str(target), mode, payload],
            capture_output=True, text=True, timeout=HARNESS_TIMEOUT,
            cwd=str(folder), env=env, stdin=subprocess.DEVNULL,
        )
    except subprocess.TimeoutExpired:
        return {"status": "timeout", "events": [], "sources": 0, "blocked": 0,
                "errors": ["timed out"]}
    for line in proc.stdout.splitlines():
        if line.startswith(MARK):
            return json.loads(line[len(MARK):])
    return {"status": "crash", "events": [], "sources": 0, "blocked": 0,
            "errors": [proc.stderr.strip()[-300:]]}


def _unsafe(cwe, event, payload):
    value = event.get("value")
    if cwe == "CWE-78":
        if not event.get("shell"):
            return False
        text = value if isinstance(value, str) else " ".join(value)
        return payload in text and shlex.quote(payload) not in text
    if cwe == "CWE-89":
        return payload in str(value)
    if cwe == "CWE-22":
        resolved = str(event.get("resolved", "")).replace("\\", "/")
        return resolved.endswith("/etc/passwd")
    if cwe == "CWE-79":
        return payload in str(value)
    return False


def _exploit_count(code, finding, workdir, lines):
    cwe = finding.cwe
    kind = EVENT_KIND[cwe]
    exploited, reached, sources, blocked, notes = 0, 0, 0, 0, []
    for payload in PAYLOADS[cwe]:
        result = run_harness(code, finding.file, "payload", payload, workdir)
        sources += result.get("sources", 0)
        blocked += result.get("blocked", 0)
        events = [
            e for e in result.get("events", [])
            if e.get("kind") == kind and _event_relevant(e, lines)
        ]
        if events:
            reached += 1
        if any(_unsafe(cwe, e, payload) for e in events):
            exploited += 1
        notes.extend(result.get("errors", [])[:3])
    return exploited, reached, sources, blocked, notes


def check_security(original, corrected, finding, workdir):
    name = CHECK_NAMES[3]
    if finding.cwe == "CWE-798":
        literal = (finding.evidence.flags.get("literal") if finding.evidence else "") or ""
        if literal and literal in corrected:
            return CheckResult(name, FAILED, "The secret literal is still present in the corrected code.")
        smoke = run_harness(corrected, finding.file, "smoke", "", workdir)
        if smoke.get("status") != "ok":
            return CheckResult(
                name, FAILED,
                "Secret removed, but the module fails to load without the environment "
                "variable: " + "; ".join(smoke.get("errors", []))[:200],
            )
        return CheckResult(
            name, PASSED,
            "Secret literal is gone and the module loads with the environment variable unset.",
        )

    payloads = PAYLOADS[finding.cwe]
    orig_lines, corr_lines = relevant_lines(original, corrected, finding)
    o_exp, o_reached, _, _, _ = _exploit_count(original, finding, workdir, orig_lines)
    c_exp, c_reached, c_sources, c_blocked, notes = _exploit_count(
        corrected, finding, workdir, corr_lines
    )
    total = len(payloads)
    log = [f"original: {o_exp}/{total} payloads exploited", *notes]
    if c_exp:
        return CheckResult(
            name, FAILED,
            f"{c_exp}/{total} payloads still reach the sink unsafely "
            f"(original: {o_exp}/{total}).", log,
        )
    if o_exp == 0:
        return CheckResult(
            name, UNAVAILABLE,
            f"Payloads could not exploit the original code in the harness either "
            f"(reached sink {o_reached}/{total}), so this test cannot tell the "
            "difference.", log,
        )
    if c_sources == 0 and c_reached == 0 and c_blocked == 0:
        return CheckResult(
            name, UNAVAILABLE,
            "The corrected code never read the payload, so it could not be exercised.", log,
        )
    return CheckResult(
        name, PASSED,
        f"0/{total} payloads exploitable (original: {o_exp}/{total}); "
        f"{c_blocked} blocked by checks, {c_reached} reached the sink safely.", log,
    )


# ---------------------------------------------------------------------------
# 5. Functional tests
# ---------------------------------------------------------------------------

SKIP_DIRS = {".git", "venv", ".venv", "env", "__pycache__", "node_modules",
             "site-packages", ".tox", "build", "dist"}


def find_tests(project_dir):
    if not project_dir or not Path(project_dir).is_dir():
        return []
    found = []
    for root, dirs, files in os.walk(project_dir):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not d.startswith(".")]
        if root.count(os.sep) - str(project_dir).count(os.sep) > 4:
            dirs[:] = []
        for name in files:
            if name.endswith(".py") and (name.startswith("test_") or name.endswith("_test.py")):
                found.append(Path(root) / name)
        if len(found) > 200:
            break
    return found


def _copy_project(project_dir, workdir, label):
    dest = Path(workdir) / label

    def ignore(directory, names):
        return [n for n in names if n in SKIP_DIRS or n.startswith(".")]

    shutil.copytree(project_dir, dest, ignore=ignore)
    return dest


def _run_tests(folder):
    has_pytest = subprocess.run(
        [_python(), "-c", "import pytest"], capture_output=True
    ).returncode == 0
    if has_pytest:
        cmd = [_python(), "-m", "pytest", "-q", "-x", "-p", "no:cacheprovider"]
        runner = "pytest"
    else:
        cmd = [_python(), "-m", "unittest", "discover", "-q"]
        runner = "unittest"
    env = dict(os.environ)
    env["FAPBSH_VERIFYING"] = "1"
    try:
        proc = subprocess.run(cmd, cwd=str(folder), capture_output=True, text=True,
                              timeout=TEST_TIMEOUT, env=env, stdin=subprocess.DEVNULL)
    except subprocess.TimeoutExpired:
        return runner, None, "timed out"
    tail = (proc.stdout + proc.stderr).strip().splitlines()
    return runner, proc.returncode, tail[-1] if tail else ""


def check_functional(original, corrected, finding, project_dir, workdir):
    name = CHECK_NAMES[4]
    file_path = Path(finding.file) if finding.file else None
    # Never recurse: a test suite started by verification does not start another.
    tests = [] if os.environ.get("FAPBSH_VERIFYING") else find_tests(project_dir)
    in_project = (
        file_path is not None
        and project_dir
        and file_path.is_absolute()
        and str(file_path.resolve()).startswith(str(Path(project_dir).resolve()))
    )
    if tests and in_project:
        rel = file_path.resolve().relative_to(Path(project_dir).resolve())
        copy = _copy_project(project_dir, workdir, "project_corrected")
        (copy / rel).write_text(corrected, encoding="utf-8")
        runner, code, summary = _run_tests(copy)
        if code == 0:
            return CheckResult(name, PASSED, f"{runner}: {summary}")
        if code is None:
            return CheckResult(name, FAILED, f"{runner} timed out after {TEST_TIMEOUT}s")
        if not (runner == "pytest" and code == 5):
            orig_copy = _copy_project(project_dir, workdir, "project_original")
            (orig_copy / rel).write_text(original, encoding="utf-8")
            _, orig_code, _ = _run_tests(orig_copy)
            if orig_code not in (0, None):
                return CheckResult(
                    name, UNAVAILABLE,
                    f"{runner} already fails on the original code ({summary}).",
                )
            return CheckResult(name, FAILED, f"{runner}: {summary}")

    smoke = run_harness(corrected, finding.file, "smoke", "", workdir)
    if smoke.get("status") == "ok":
        return CheckResult(
            name, PASSED,
            "No test suite found; smoke import of the corrected file succeeded.",
        )
    orig = run_harness(original, finding.file, "smoke", "", workdir)
    errors = "; ".join(smoke.get("errors", []))[:200]
    if orig.get("status") != "ok":
        return CheckResult(
            name, UNAVAILABLE,
            f"No test suite found and the original file cannot be imported here either ({errors}).",
        )
    return CheckResult(name, FAILED, f"Smoke import failed: {errors}")
